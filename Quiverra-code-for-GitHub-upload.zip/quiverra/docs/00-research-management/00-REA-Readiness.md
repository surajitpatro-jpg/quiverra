# 00 — REA Readiness & Environment Verification

**Date:** 2026-11-09
**Phase:** 0 (Environment and Research Readiness)
**Status:** Complete — REA usable in CLI mode with a per-session Node bootstrap; MCP mode unavailable in this environment.

---

## 1. Environment capability matrix (verified by execution)

Every row below was tested with a real command on 2026-11-09. Nothing here is assumed.

| Capability | Status | Evidence / notes |
|---|---|---|
| Create & maintain project files/folders | ✅ Yes | Persistent mount `/mnt/agents` (1 TB). User-visible output at `/mnt/agents/output/`. |
| Generate & edit source code | ✅ Yes | Full file write/edit tooling. |
| Run terminal commands | ✅ Yes | Linux x86_64 (Debian 12 base), shell per call is non-persistent; `/tmp` persists within a session turn only. |
| Install dependencies | ✅ Yes | npm registry reachable (HTTP 200 verified). pip installs work. |
| Node.js runtime | ⚠️ Node 20.20.2 default | Sufficient for the app stack; **insufficient for REA** (needs ≥22.23.4). Node 22/24 can be bootstrapped per session from nodejs.org (reachable, verified). |
| Execute tests | ✅ Yes | Node/Python test runners run normally. |
| Run a development server | ⚠️ Partial | Runs within a single command call only; no persistent long-lived processes between calls. Preview of deliverable sites is handled by the platform's version/preview system instead. |
| Browser access for research | ✅ Yes | Chromium 151.0.7922.108 installed; Playwright available; plus platform web search/fetch tools. |
| Access GitHub repositories (read) | ⚠️ Partial | `git clone` / `git ls-remote` to github.com are **blocked** (connection fails). `raw.githubusercontent.com` ✅ and `codeload.github.com` ✅ (repo tarballs) work. `api.github.com` works but is rate-limited unauthenticated. |
| Commit & push code to GitHub | ❌ No | Git protocol to github.com blocked and no user credentials available. **Mitigation:** this workspace is the source of truth; the user mirrors it to GitHub. |
| Connect external MCP tools | ⚠️ Partial | Plugin-provided MCP tools only. REA's `setup` flow registers MCP with Claude Code / Codex / Cursor / Gemini CLI / Grok Build — **Kimi web is not a supported MCP host**, so REA cannot be attached as an MCP server here. |
| Use REA | ✅ CLI mode | See §2. Validated live: REA 6.8.0 CLI runs under a bootstrapped Node 22. |
| Preserve project state across sessions | ✅ Yes | Files under `/mnt/agents/output/` persist; plus project memory notes. In-flight processes do not persist. |
| Docker | ❌ No | `docker` not installed and cannot be. Deployment images must be built on the user's side (documented in Deployment guide, Phase 4/7). |

## 2. REA compatibility investigation (verified)

### 2.1 What REA is now

Source: official repository `morluto/rea` (fetched 2026-11-09) and rea.tools.

- REA is an MCP + CLI toolkit for reverse engineering: native binaries, JavaScript/Electron apps, .NET assemblies, **websites**, APKs, firmware, captures, and more.
- Distributed via npm as `rea-agents` (current version validated: **6.8.0**).
- **Runtime requirement (hard):** Node.js `^22.23.4 || ^24.22.1 || >=26.12.1`.
- License: MIT. Explicitly scoped to lawful research, education, interoperability, and analysis of software you are authorised to examine — consistent with this project's research rules.

### 2.2 Validation actually performed

| Test | Result |
|---|---|
| `npx rea-agents@latest --version` under sandbox Node 20.20.2 | Package installs with `EBADENGINE` warnings; unreliable/slow. **Not viable on default Node.** |
| Bootstrap Node 22.21.1 from nodejs.org into `/tmp` | ✅ Works (~30 MB download, per-session). |
| `rea --version` under Node 22.21.1 | ✅ Prints `6.8.0`. |
| `rea --help` | ✅ Full command list returned. Relevant to this project: `analyze-web-bundle`, `capture-web-screenshot`, `capture-browser-scenario`, `export-web-scripts`, `compare-web-captures`, `discover-webmcp-tools`, `doctor`. |
| `rea doctor` | Runs and reports honestly: `healthy: false` because Node 22.21.1 < 22.23.4, and no native analysis engines (Hopper/Ghidra/IDA/JADX/Kuna) configured. **Native engines are irrelevant to our website-research use case.** Host check: healthy (debian 12). |
| MCP registration (`npx rea-agents setup`) | ❌ Not applicable — Kimi web is not among the supported agent hosts. REA here is **CLI-only**, invoked through the terminal. |

### 2.3 Conclusion

**REA can be used in this environment in CLI mode**, with two operational rules:

1. Each working session that needs REA must first bootstrap Node ≥22.23.4 (recommended: Node 24.22.1+) into `/tmp` and prepend it to `PATH`. Cost: ~1–3 minutes per session. (Validated with 22.21.1; `doctor` requires ≥22.23.4, so future sessions should fetch the newest 22.x or 24.x.)
2. REA usage is limited to **lawful, publicly accessible targets**: public marketing pages and publicly reachable web assets of competitor products. No authentication bypass, no extraction of private source, credentials, or protected assets.

**Website analysis commands validated as present:** `analyze-web-bundle` (capture + statically analyse a page bundle), `capture-web-screenshot`, `capture-browser-scenario`, `export-web-scripts`. These require a Chrome-family browser — Chromium 151 is installed.

### 2.4 Fallback research workflow (used alongside REA)

Where REA CLI is impractical, the equivalent workflow is:

1. Platform web search + direct page fetch for official docs, pricing, changelogs.
2. Playwright/Chromium for rendered-page inspection and screenshots of public pages.
3. `codeload.github.com` tarballs for open-source repos.
4. All findings recorded in `Evidence-Index.md` with confidence classification (Verified / Partially verified / Hypothesis / Unknown).

## 3. Limitations that affect delivery (reported, not worked around silently)

1. **No GitHub push from this environment.** The workspace at `/mnt/agents/output/creative-platform/` is the source of truth; the user mirrors it to GitHub. The directory is structured to be dropped into a repo unchanged.
2. **No Docker.** Hostinger VPS deployment (Phase 7) can be fully designed and statically validated here (Dockerfiles, compose, Caddy/nginx configs), but image builds and the final deploy must run on the user's machine/VPS.
3. **No persistent processes.** Dev servers and workers can't stay alive between tool calls; verification strategy relies on builds, tests, and the platform preview system rather than long-lived local servers.
4. **REA is CLI-only here** and needs the per-session Node bootstrap.
5. **No AI provider keys are configured.** Provider research (Phase 4 tech research) will be documentation-based; live provider calls require the user's keys, which must only ever live server-side as environment variables.

## 4. Recommended execution workflow (adopted)

1. Research and documentation live in this workspace, Markdown, Mermaid diagrams, evidence files under `evidence/`.
2. REA CLI used for public website inspection where it adds evidence value; Playwright/web-fetch otherwise.
3. Every finding logged in `Evidence-Index.md` with ID, source, date, confidence, limitations.
4. Phase gates respected: no application code before the blueprint and architecture are reviewed (Phase 6 entry condition).
5. User mirrors workspace to GitHub at each phase boundary.
