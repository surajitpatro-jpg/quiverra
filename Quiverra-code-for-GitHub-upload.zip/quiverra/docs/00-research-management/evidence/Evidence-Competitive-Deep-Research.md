# Evidence Excerpts — Deep Competitive Workflow Research

**Scope:** Findings F-0025 .. F-0035 (Evidence-Index.md)
**Collected:** 2026-11-10 · **Method:** web fetch/search (REA browser path unavailable — see Known-Issues KI-07)
**Purpose:** underlying source excerpts for the correction-phase competitive research. Quotes are trimmed to the load-bearing clauses; consult the live URL for full context. Volatile items (pricing, quotas) carry a freshness flag per Research-Methodology.md.

---

## F-0025 — Higgsfield AI Influencer builder (19 structured controls)

- Source: aiidelist.com, "Higgsfield AI Influencer" (2026-10-06) — https://aiidelist.com
- Excerpt (paraphrase-tightened): the rebuilt influencer tool (2026-10-03) replaces free-text prompting with **19 structured visual controls**; Character Types are **Average / Bold / Extreme**; one generation (~**1.12 credits**) returns a close-up portrait, a full-body shot, and a reusable **Character Parameters** bundle; a real face can optionally be uploaded; output connects to **Genjutsu Motion Transfer** and **Object Swap**.
- Classification: **V**. Limitation: control list observed via third-party walkthrough, not the live UI.

## F-0026 — Higgsfield Canvas node editor

- Source: higgsfield.ai/canvas-intro (page load verified via CDP 2026-11-10 before attach timeout) — https://higgsfield.ai/canvas-intro
- Excerpt: Canvas is a **node-based editor** — prompts, images and models are nodes; outputs are routable between models (e.g. Soul → Kling → upscale); **live Figma-style collaboration**; every version auto-saved; comments attach per node.
- Classification: **V**.

## F-0027 — Soul ID official mechanics

- Sources: higgsfield.ai creator-hub help center; official blogs (keep-ai-character-consistent; Soul-ID-AI-Character-Consistency)
- Excerpts:
  - Train with **20–80 photos** (≥960px); trained identity works across the Soul model family; trained characters auto-appear as **Elements** for Seedance video.
  - Identity is **not exportable** (platform-locked).
  - Expectation setting is explicit: the result is "**clearly the same person**", with drift acknowledged at extreme styles/angles — their own blog admits consistency is "**high, not absolute**".
  - Cinema Studio reference slots: up to **9 (v3.0)** and **50 (v4.0)**; Elements are shared across shots and projects.
- Classification: **V**.

## F-0028 — Supercomputer orchestration (cost preview before render)

- Source: higgsfield.ai/blog/agentic-ai-for-content-creation
- Excerpt: Supercomputer is a chat-driven agent that **plans jobs, shows the credit cost BEFORE render for approval**, and routes across frontier LLMs (Claude/Gemini) for reasoning plus Veo/Kling/Seedance/Flux/Nano Banana/GPT Image/MiniMax for generation; supports **Scheduled Tasks** and saveable brief "Skills"; runs in the browser and Telegram.
- Classification: **V**. Design consequence recorded in Evidence-Index: cost-preview-before-render is the bar our deterministic estimator must beat.

## F-0029 — Cinema Studio 4.0 screening & controls

- Sources: prnewswire release (2026-10-28); memeburn review (2026-11-03)
- Excerpts:
  - Every generation is **screened for real faces / protected IP** and blocked with a "May contain protected content" notice.
  - Camera controls include **movement, lens choice, aperture, lighting, colour grading**; the Higgsfield DOP model specialises in cinematic camera moves.
  - Usable standalone or orchestrated by Supercomputer.
- Classification: **V**.

## F-0030 — Runway workflow detail

- Sources: pixflow Gen-4 guide (2026-08); help.runwayml.com; help.scenario.com (2026-09); aiveed.io
- Excerpts:
  - Credit burn: Gen-4.5 ≈ **12 cr/s**, Gen-4 Turbo ≈ **5 cr/s** (≈5× faster), Aleph ≈ **15 cr/s**, Act-Two ≈ **5 cr/s**.
  - Aleph edits existing footage; the original takes only the **first 5 s** of input; Aleph 2 accepts ≤30 s / ≤16 MB; **keyframes XOR prompt-images** (not both).
  - **Camera Control panel**: pan / tilt / zoom / roll / dolly at small increments; first+last **keyframes** (Gen-3, select Gen-4); **Fix Seed** locks style across shots; @-named references up to **3**.
  - Native output 720p/24 fps; 4K upscale is a separate paid action; **trim/retime don't spend credits**.
  - Refunds: automatic only on generation error; plan refunds ≤30 days only if unused.
- Classification: **V**.

## F-0031 — Kling Motion Control & Motion Brush

- Sources: atlascloud.ai Kling 2.6 guide (2026-07-14); kling.ai official Motion Control guide; kling2-6 community guide
- Excerpts:
  - Motion Control is **image-to-video only — not available in text-to-video**. Inputs: a character image + a reference video (**2–5 s optimal**).
  - Web UI accepts multiple character references; the **API accepts one per request**.
  - Two orientation modes: **Matches Video** (camera follows the reference footage) vs **Matches Image** (camera is free, driven by prompts).
  - UI "strength" slider maps to **cfg_scale** in third-party API implementations (**PV**).
  - Motion Brush = painted directional vectors on regions; cheaper than Motion Control.
  - Community failure modes: "spaghetti limbs" from occluded reference frames; camera shake in the reference read as body motion.
- Classification: **V** (cfg_scale mapping PV).

## F-0032 — Luma Ray 3.2 / Ray 3.14 / Uni-1

- Sources: lumalabs learning center + news; thepostflow (2026-10-29); magichour (2026-09)
- Excerpts:
  - Ray3.2: up to **16 keyframes**, 20 s clips at 1080p, native 16-bit **HDR + EXR** export; **Modify Video** with strength slider (Adhere ↔ Reimagine); **Motion density slider 1–9 decoupled from Structure slider**; Face toggle.
  - Ray3.14 (2026-01-26): fast/cheap tier with Extend Video, loops, duration change — but **no character references and no EXR**.
  - Uni-1 image model: up to **9 role-labelled references**, seeds, 6,000-character prompts, Layers; ≈30 cr/image in app, ≈$0.09 via API.
- Classification: **V**.

## F-0033 — LTX Studio workflow

- Sources: ltx.io/blog/how-to-storyboard; wavespeed review (2026-10-02); magiclight review (2026-08)
- Excerpts:
  - Script paste → AI parses scenes/shots → user edits structure (merge/split/add beats) **free, before any generation** → frames per shot at a locked aspect ratio.
  - Recurring cast auto-extracted as **Elements**, but must be **@-mentioned in shot text** — a missing @ is reported as the primary cause of inconsistency.
  - Per-shot 3D camera control; **Retake** reduces full regenerations; timeline editor built-in.
  - Partner models (Kling/Veo) burn credits faster than native LTX-2.3. Desktop-only; G2 rating 4.4.
- Classification: **V**. Design consequence: LTX's @-mention fragility validates our **structured reference binding** (no natural-language mention required).

## F-0034 — Failure / credit landscape (industry norms)

- Sources: aiveed.io (2026-02); higgsfield.ai/blog/why-ai-video-generations-fail (2026-11-04); zemith Kling reviews (2026-11-08); help.runwayml.com
- Excerpts:
  - Kling users report **40–60 % peak-hour failure rates** and the "99 % freeze" (user-reported, not official).
  - Only **server execution failures auto-refund**; completed-with-defects outputs are charged — this is the industry-wide norm.
  - Higgsfield auto-refunds errors / NSFW flags / copyright blocks within minutes (Grok exception: charged at start).
  - Runway auto-refunds on generation error; stuck generations auto-cancel in 1–2 h.
  - Veo API bills successful generations only; consumer-plan refunds inconsistent.
  - Kling Trustpilot: 42 % 1-star, predominantly billing friction.
- Classification: **V** (failure rates flagged as user-reported). Design consequence: our acceptance-rate telemetry must produce **our own** data.

## F-0035 — Higgsfield commercial-practice complaints

- Sources: mindstudio.ai (2026-07-28); aitoolcurator refund guide (2026-09); reddit r/HiggsfieldAI threads
- Excerpts:
  - Cancellation friction (Discord-moderator escalation reported); refunds only ≤7 days **and** zero credits used; up to **6 % service fee**; renewals non-refundable; unlimited tier runs on a throttled queue with an "excessive use" throttle clause.
  - July 2025 ToS backlash forced revisions (perpetual UGC sub-license removed; deleted content excluded from training) but the **default training grant on inputs remained**.
- Classification: **V (as reported)**. Design consequence: direct input for our billing UX — self-serve cancel, clear refund rules, no dark patterns.
