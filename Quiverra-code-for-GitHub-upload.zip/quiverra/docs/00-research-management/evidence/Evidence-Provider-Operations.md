# Evidence Excerpts — Provider Operational Contracts

**Scope:** Findings F-0036 .. F-0041 (Evidence-Index.md); consolidates F-0017..F-0024 where operationally relevant
**Collected:** 2026-11-10 · **Method:** web fetch/search (official docs preferred; third-party corroboration noted per row)
**Purpose:** underlying source excerpts for worker-gen / router / quota-manager design. Freshness rule applies to all pricing.

---

## F-0036 — fal.ai operational contract

- Sources: fal.ai docs — FAQ, concurrency-limits, reliability pages (read Oct–Nov 2026)
- Excerpts:
  - Account concurrency: **2 at signup, self-serve up to 40**, set by trailing-4-week paid invoice volume.
  - Only **IN_PROGRESS** requests count against concurrency; **IN_QUEUE is unlimited**.
  - `subscribe()` recommended (server-side requeue, no max-retry ceiling) vs `run()` (SDK retries HTTP 429 ×10 with exponential backoff).
  - HTTP 429 carries type `concurrent_requests_limit` and header `X-Fal-needs-retry: 1`.
  - Automatic retries on 503/504/connection errors; **5xx never billed**; **HTTP 422 MAY be billed** (GPU time already spent) → validate inputs client-side before submit.
  - Credits expire **365 days** (free credits/coupons: 1 week – 1 year). Cold starts **not billed** on Model APIs.
- Classification: **V**. Design consequence: worker-gen uses `subscribe` + webhook; pre-submit validation to avoid billed 422s.

## F-0037 — Replicate operational contract

- Sources: replicate.com/docs rate-limits; fast.io (2026-10-24); wavespeed (2026-10-02)
- Excerpts:
  - Prediction creation limited to **600 req/min**; other endpoints 3,000 req/min; HTTP 429 resets in ~30 s.
  - Defensive throttling as balance approaches $0 — guidance is keep balance >$20 with auto-reload.
  - Granted-credit-no-card accounts limited to **1 rps / 6 rpm**.
  - Failed runs on **public/official models unbilled**; failed runs on **private deployments billed** for instance time.
  - **Prediction data and files are deleted after 1 hour by default** → outputs must be copied to R2 immediately on completion.
  - Model **version hashes pin exact implementations** (registry `provider_model_version` stores the hash).
- Classification: **V**. Design consequence: 1-hour retention mandates immediate R2 ingestion in worker-gen (already in Flow C; now a hard contract).

## F-0038 — Kling direct API + aggregator price spread

- Sources: wireflow (2026-10-10); shhots (2026-08-09); kling.ai/dev/pricing; dev.runwayml.com (2026-10-26)
- Excerpts:
  - Direct API is prepaid **unit packages**: $0.14/unit list; trial 100 units $9.80 (30-day validity); 5,000 units $700 (180-day); 30 k+ units $0.126/unit.
  - Concurrency **5–20 simultaneous tasks** depending on package.
  - Kling 3.0 ladder 0.6–1.2 units/s (web credit ladder ÷10); 4K mode 3 units/s.
  - **Kling 4.0 not yet on the official API** (preview pricing posted) but live via **Runway Dev** as `kling_4` ($0.157/s 720p, $0.235/s 1080p; input video billed extra).
  - **Replicate charges exactly 2× fal for identical Kling v3**: $0.168/s vs $0.084/s. Atlas Cloud promo $0.071/s.
- Classification: **V**. Design consequence: aggregator price spread is real — the cost table must live in the registry as data, and fal ≪ Replicate for Kling routing.

## F-0039 — Gemini API limits architecture

- Sources: fast.io (2026-09-16); laozhang guide (2026-10-05); usagebox (2026-09)
- Excerpts:
  - Limits are **per project, not per API key**; dimensions RPM / TPM / RPD (+ IPM for image, TPD for some models).
  - Google publishes **no static limits table** — live values are visible in AI Studio only; RPD resets midnight Pacific.
  - **Image models have no free quota.**
  - Paid tiers T1/T2/T3 with monthly billing caps $250 / $2,000 / $20,000+ and rolling 10-minute spend limits $10 / $50 / $200.
  - **The $300 Cloud welcome credit is NOT usable for the Gemini API since March 2026**; new accounts must Prepay ($5 minimum).
  - **Failed 400/500 requests still consume quota**; HTTP 402 = prepay balance empty; Batch API = 50 % price with separate limits.
- Classification: **V**. Design consequence: the quota manager must treat Gemini limits as **fetched-at-runtime data, not constants**; failed calls burn quota → validate before send.

## F-0040 — ElevenLabs concurrency & metering

- Sources: elevenlabs.io/docs models page (2026-11-06); elevenlabs blog on rate limiting (2026-06); stork.ai (2026-11-01)
- Excerpts:
  - Concurrency per plan × model family — Multilingual v2: Free 2, Starter 3, Creator 5, Pro 10, Scale/Business 15; **Flash: double those**; STT elevated (8–60).
  - Over-limit requests queue (~+50 ms) then HTTP 429; responses expose headers `current-concurrent-requests` / `maximum-concurrent-requests`.
  - Per-request character caps: eleven_v3 5,000; Multilingual v2 10,000; Flash v2.5 40,000.
  - **WebSocket metering counts only active generation time**; Text-to-Dialogue WS metered as sessions (Free 14 → Scale 105).
  - Turbo deprecated → Flash. Heuristic: concurrency 5 ≈ 100 simultaneous broadcast streams.
- Classification: **V**. Rate conflict with F-0023 ($0.04 vs $0.05 per 1 k chars Flash) persists — official docs now indicate $0.04 Flash / $0.08 v4; PV flag kept until integration-time verification.

## F-0041 — Self-hosted path (future registry rows)

- Sources: ltx.io OSS guide (2026-07); thundercompute (2026-10); quantacloud (2026-09); runpod.io/pricing (2026-11); spheron (2026-04)
- Excerpts:
  - Open-weight video: **Wan 2.2 (Apache 2.0)** — 5B runs on 24 GB, A14B needs 80 GB for 720p; **LTX-2.5** — 32 GB FP8 minimum, A100/H100 recommended, native audio, license free <$10 M ARR; **HunyuanVideo 1.5** — 14 GB with offloading, Tencent license <100 M MAU.
  - Wan 2.5/2.6 and FLUX 3 Video are **API-only, no public weights**.
  - GPU rental: RunPod pods A100 $1.19–1.79/h, H100 $2.89–3.99/h, RTX A6000 $0.33–0.59/h; Serverless A100 $2.72, H100 ≈$4.55–4.79/active-hour + cold-start billing; storage $0.07/GB/mo; serverless↔pod break-even ≈**66 % utilisation**.
  - Measured self-host economics ≈ **$0.002/s (LTX-class) vs $0.05+/s API**.
- Classification: **V**. Design consequence: architecture accepts self-hosted endpoints as registry rows (`provider: self`) with the same capability schema — no design change, planned from the start (ADR-0009).

---

## Consolidated operational rules for worker-gen (derived)

| Rule | Source | Consequence |
|---|---|---|
| Use `subscribe()` + webhook on fal; `run()` only for trivial calls | F-0036 | Worker-gen adapter design |
| Pre-validate all inputs before submit | F-0036, F-0039 | Billed 422s (fal) and quota-burning 400s (Gemini) are avoidable costs |
| Ingest Replicate outputs to R2 within minutes of completion | F-0037 | 1-hour deletion is a hard data-loss window |
| Treat Gemini limits as runtime-fetched, per-project data | F-0039 | No static constants in the quota manager |
| Honour ElevenLabs response headers for live concurrency | F-0040 | Self-tuning concurrency instead of static config |
| Route Kling via fal, not Replicate, unless fal is down | F-0038 | 2× price for identical output |
| Self-hosted endpoints are registry rows, not special cases | F-0041 | Same capability/honesty schema, `provider: self` |

---

## F-0042 — fal data retention & ZDR

- Source: fal.ai/docs/documentation/model-apis/media-expiration (read 2026-11-10)
- Excerpts:
  - "Request inputs and outputs are stored in the platform for **90 days** by default. This powers the request history in your dashboard."
  - Per-request prevention: header `X-Fal-Store-IO: 0` on the subscribe/run call; account-team default also available; per-request headers take precedence.
  - CDN files are separate: `X-Fal-Object-Lifecycle-Preference` controls uploaded/generated file retention.
  - "Zero Data Retention (ZDR) … is not enabled by default … ZDR is not a single setting" — account team configures request-history disable + CDN expiration default; application logging is controlled by the model deployment owner.
  - Delete Request Payloads API: deletes payloads + CDN output files for a completed request (400 if still in progress); input CDN files are NOT deleted (may be shared).
- Classification: **V**.

## F-0043 — Replicate data retention (official)

- Source: replicate.com/docs/topics/predictions/data-retention
- Excerpt: "For predictions created through the API, all input parameters, output values, output files, and logs are automatically removed after an hour, by default. … Data for predictions created through the web interface is kept indefinitely." Manual delete via dashboard removes prediction + outputs + files.
- Classification: **V**.

## F-0044 — Gemini data-use split (free vs paid)

- Sources: Google AI for Developers terms (ai.google.dev/gemini-api/terms); Google AI forum staff answers; meetily.ai "Gemini Zero Data Retention" (2026-09-26)
- Excerpts:
  - "When you use Paid Services … Google doesn't use your prompts (including associated system instructions, cached content, and files such as images, videos, or documents) or responses to improve our products … For Paid Services, Google logs prompts and responses for a limited period of time, solely for the purpose of detecting violations of the Prohibited Use Policy and any required legal or regulatory disclosures." (Google staff quoting the terms)
  - Free tier: content used to improve products; human reviewers may process; terms warn against submitting sensitive/confidential/personal data.
  - "Customers in the European Economic Area, Switzerland, and the UK get the paid-tier policy applied to all services including free tiers."
  - Grounding with Google Search keeps logs ~30 days (Developer API); guaranteed ZDR only via Vertex AI configuration steps.
  - "When you activate a Cloud Billing account, all use of Gemini API and Google AI Studio is a 'Paid Service' with respect to how Google Uses Your Data, even when using Services that are offered free of charge."
- Classification: **V**.

## F-0045 — ElevenLabs data use & retention

- Sources: elevenlabs.io/privacy-policy (2026-10-09); elevenlabs.io/docs zero-retention-mode; elevenlabs.io/dpa (2026-04-08); verifywise.ai AI Trust Index (2026-10-09); shieldra.ai vendor profile (2026-07-29)
- Excerpts:
  - "ElevenLabs uses certain data you provide to us to improve the quality of our audio models for everyone… By default, we don't train on any data from our Enterprise customers." Opt-out: profile → Terms and privacy → Data use → disable "Improve the models for everyone"; "The opt-out only applies to and affects use of your personal information for training after you opt-out."
  - Zero Retention Mode: enterprise; per-request `enable_logging=false` on `/v1/text-to-speech/`, `/v1/text-to-dialogue/`, `/v1/speech-to-speech/`, `/v1/speech-to-text/`, and music generation endpoints; "Traffic through the web UI is never covered."
  - "ElevenLabs has agreements in place with each third-party LLM provider which expressly prohibit such providers from training their models on customer content, whether or not Zero Retention Mode is enabled."
  - DPA §9.2: enterprise customer content deleted within 30 days of termination; self-serve content may be deleted after 180 days of inactivity.
  - Third-party audit (verifywise, grade C 50/100): "its terms take a perpetual, irrevocable, sub-licensable licence over user content" and "promises not to keep data it generates about a voice for longer than three years".
  - Compliance posture per vendor: SOC 2 Type II, ISO 27001, PCI DSS Level 1, CSA STAR L1.
- Classification: **V**.
