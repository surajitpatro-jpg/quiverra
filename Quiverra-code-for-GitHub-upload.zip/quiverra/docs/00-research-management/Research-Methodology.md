# Research Methodology

**Version:** 1.0 · **Date:** 2026-11-09

## Evidence classification

Every significant finding is recorded with one of four confidence levels:

| Level | Meaning |
|---|---|
| **Verified** | Directly supported by accessible evidence (official docs, official pricing pages, direct product observation, executed tooling). |
| **Partially verified** | Some behaviour is observable, but the full mechanism is unknown. |
| **Hypothesis** | Technically plausible explanation requiring validation. |
| **Unknown** | Insufficient evidence. |

Assumptions about a competitor's internal architecture are never presented as verified facts.

## Finding record schema

Each finding in `Evidence-Index.md` carries:

- Finding ID (`F-####`)
- Feature / mechanism
- Observed behaviour
- Evidence source (URL, tool, artifact path)
- Research date
- Confidence level
- Limitations
- Follow-up required

## Source hierarchy

1. Official product documentation, pricing pages, API docs, changelogs (highest weight)
2. Direct observation of the public product (REA CLI / browser inspection of public pages)
3. Official engineering blogs, launch posts, founder statements
4. Reputable secondary coverage (dated; marked secondary)
5. Community reports (lowest weight; always marked)

## Tooling

- **REA CLI 6.8.0** (Node ≥22.23.4 bootstrap) — public website bundle analysis, screenshots, browser scenarios. CLI-only in this environment.
- **Playwright / Chromium 151** — rendered public pages, screenshots.
- **Web search/fetch** — official documentation and current pricing/limits.
- **codeload.github.com / raw.githubusercontent.com** — open-source repo reading (git clone is blocked in this environment).

## Legal and ethical boundaries

- Publicly accessible pages and legitimate technical observation only.
- No bypassing authentication, paywalls, rate limits, or security controls.
- No extraction of private source code, credentials, confidential interfaces, or protected assets.
- No copying of competitor branding or protected visual assets into our product.
- REA's own responsible-use disclaimer applies to all REA usage.

## Freshness rule

All market, pricing, quota and capability claims must be re-verified against official sources at the time they are used for a decision, because this market changes weekly. The research date on each finding is mandatory.
