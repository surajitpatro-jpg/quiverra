# Research Progress

**Last updated:** 2026-11-10

## Phase status board

| Phase | Status | Notes |
|---|---|---|
| 0 — Environment & research readiness | ✅ Complete | 2026-11-09. See `00-REA-Readiness.md`. |
| 1 — Competitive product investigation | ✅ Complete (2026-11-09) | Higgsfield, Runway, Kling, Luma, Pika, LTX Studio + 7 pre-production tools benchmarked. 4 docs delivered in `01-competitive-research/` |
| 2 — Proprietary system research | ✅ Complete (2026-11-09) | All 7 system specifications delivered in `02-proprietary-systems/` |
| 3 — Gap & innovation strategy | ✅ Complete (2026-11-09) | 4 strategy docs + Product Mechanism Blueprint + 4 Mermaid diagrams delivered |
| 4 — Technical architecture | ✅ Complete (2026-11-10) | 7 architecture docs in `03-system-architecture/` + capability matrix & cost analysis in `04-technical-research/`; provider evidence F-0017…F-0024 |
| 5 — Product requirements & MVP | ⬜ Not started | |
| 6 — Implementation | ⬜ Blocked | Entry condition: blueprint + architecture reviewed |
| 7 — Testing & deployment | ⬜ Not started | |

## Phase 0 log (2026-11-09)

- Verified environment capabilities by execution (filesystem, git, node, npm, network, Chromium, Docker). Results in `00-REA-Readiness.md` §1.
- Investigated REA: fetched official repo + rea.tools; validated REA CLI 6.8.0 under bootstrapped Node 22; ran `rea doctor`. Conclusion: CLI mode viable, MCP mode not applicable in this environment.
- Identified and documented delivery limitations (KI-01…KI-06).
- Established project directory structure per brief §12.
- Created management files: Research-Methodology, Evidence-Index, Architecture-Decisions, Known-Issues.

## Phase 1 log (2026-11-09)

- Investigated Higgsfield in depth: product surfaces (web, Canvas, Supercomputer, Cinema Studio 4.0, Marketing/Ads Studio, Ad Multiplier, Genjutsu, Shorts Studio, MCP/CLI/API), model catalog, Soul ID mechanics + documented limits, continuity techniques, pricing/credit mechanics. → `Higgsfield-Product-Map.md`
- Benchmarked Runway, Kling, Luma, Pika, LTX Studio and the pre-production layer (Boords, Katalist, Storyflow, Studiovity, ScreenWeaver, Morphic, Frameliq). → `Competitive-Benchmark.md`
- Mapped all competitors against our seven systems. → `Feature-Comparison.md`
- Identified 9 evidence-based gaps with feasibility/value/defensibility ratings and P0–P2 priorities. → `Competitive-Gap-Analysis.md`
- 13 new evidence records (F-0004…F-0016) with confidence classifications.
- REA deep-dive on higgsfield.ai attempted: CLI validated (doctor, CDP target listing) but `analyze-web-bundle` hit a CLI contract issue; documented as KI-07 with fallback (fetch tools used instead).
- **Key finding:** every competitor competes on generation; none owns production intelligence (structured brief→plan, continuity state, cost governance). This validates the project's differentiation thesis.

## Phase 1 verified vs uncertain

**Verified:** pricing/credit mechanics of all six primary competitors (dated Oct–Nov 2026 sources); Soul ID mechanics and limits; market consolidation post-Sora-shutdown; existence and shape of agentic surfaces (Supercomputer, Runway Agent, Luma Agents).

**Uncertain / follow-up:** Higgsfield Starter price conflict ($15/200cr vs $19/270cr); Kling 4K mode availability; competitor internals (architectures) remain Unknown by design; all pricing requires re-verification before commercial decisions.

## Phase 2 log (2026-11-09)

- Delivered P0 system specifications, each with purpose, evidence-backed user problems, functional requirements, workflows, data structures, dependencies, API contracts, model requirements, technical approach, failure handling, acceptance criteria and ≥3 competitor improvements:
  - `Creative-Director-Engine.md` — staged brief→interpretation→concepts→plan pipeline; deterministic cost estimation; Creative Decision Graph; impact analysis via artefact DAG.
  - `Scene-Continuity-Engine.md` — versioned scene state; shot continuity contracts; deterministic rule engine (rules as data) + confidence-scored VLM evaluation; pre-flight conflict detection; selective regeneration.
  - `Storyboard-Shot-Planner.md` — shot-as-data model; board/table/timeline projections; version comparison; approval gates as policy; selective regeneration; pro exports (CSV/PDF/animatic/EDL).
- Design decisions logged as ADR-0004…0007.

## Phase 2 log (2026-11-09, second session)

- User created the GitHub repository **platformai** (2026-11-09); **superseded 2026-11-10 by `surajitpatro-jpg/quiverra`** — now the permanent home (README + ADR-0001 update).
- Delivered the remaining four system specifications:
  - `Workflow-Intelligence.md` — compiled (not drawn) dependency-DAG workflows; idempotent content-hash tasks; parallel execution with provider backpressure; budget caps; gates; partial subgraph regeneration; event-sourced run log (ADR-0008).
  - `Character-Intelligence-Engine.md` — structured identity (wardrobe sets, expressions, gestures, movement, voice); reference sheets with input quality gates; versioning/approval/permissions; honest per-model capability map; provider-independent by design (anti-lock-in).
  - `Cinema-Intelligence-Engine.md` — canonical cinematography vocabulary; per-(control × model) classification (native / prompt-approximated / reference-conditioned / unsupported) with benchmark evidence; deterministic instruction compiler + honesty report (ADR-0009).
  - `Brand-Marketing-Intelligence.md` — persistent brand profiles (voice, messaging rules, restrictions, catalogue); ingestion assist (draft-only); plan-stage violation flagging; deterministic-first compliance evaluation; multi-format variants; campaign memory.
- **Phase 2 complete: all seven system specifications delivered.** Design decisions logged as ADR-0008…0009.

## Phase 4 log (2026-11-10)

- Verified the live provider landscape before writing any architecture (freshness rule): LLM side — Gemini (free tier Flash-only post-April 2026, quota numbers conflicting between sources ⇒ PV), Groq (all models free, per-model limits), Cloudflare Workers AI (10K Neurons/day), OpenRouter (rotating `:free` roster, 20 RPM, 50→1,000 RPD). Generation side — fal.ai (prepaid per-output, no charge on 5xx/queue, pricing API), Replicate (no permanent free tier; **Cloudflare acquisition closed 2025-12-01**), ElevenLabs (free tier non-commercial ⇒ internal-only routing), Veo 3.1 rate card + **Gemini Omni Flash as Google's recommended video default** and **Sora 2 API shutdown 2026-09-24**. 8 new evidence records (F-0017…F-0024).
- Delivered architecture documents in `03-system-architecture/`: Overall-Architecture, Database-Architecture (full DDL, invariants, indexing), API-Architecture (route map + cross-route guarantees), Orchestration-Engine (router selection algorithm, free-quota manager, append-only credit ledger, deterministic estimator, adapter interface), Workflow-Execution (queues, retries, gates, budgeting, disaster behaviour), Security (trust boundaries, secrets, confidential-workspace routing, DPDP posture), Deployment (VPS compose topology, CI/CD post-mirroring, backup/DR with restore-drill doctrine).
- Delivered technical research in `04-technical-research/`: Model-Capability-Matrix (registry seed data with honesty classifications per control × model) and API-Cost-Analysis (unit costs per finished clip/image/minute, retry-rate honesty, free-tier capacity budget, aggregator-vs-direct breakpoints, cost risk register).
- New decisions: **ADR-0010** (Drizzle data layer), **ADR-0011** (modular monolith + queue-isolated workers). Also appended the missing ADR-0008/0009 records (previously only referenced in specs).
- **Key structural finding:** free capacity exists only on the intelligence side; media generation is always paid ⇒ intelligence is given away visibly, generation is metered transparently, and the two ledgers never blend. This is now encoded in the router's spend policies and the ledger design.

## Correction-phase log (2026-11-10)

User review approved the direction ("AI Creative Production Operating System, not an aggregator") and ordered corrections + Phase 5 before any implementation. Executed:

- **Deeper competitive research** (F-0025..F-0035): Higgsfield AI-Influencer builder (19 structured controls), Canvas node editor, Soul ID official mechanics, Supercomputer cost-preview pattern, Cinema Studio 4.0 screening; Runway workflow detail (camera panel, keyframes, Fix Seed, Aleph limits, refund rules); Kling Motion Control (I2V-only, orientation modes, cfg_scale PV) vs Motion Brush; Luma Ray3.2 (16 keyframes, Motion/Structure sliders) vs Ray3.14 (no char refs, no EXR); LTX workflow incl. @-mention fragility (validates our structured bindings); industry failure/refund norms (completed-defective always charged); Higgsfield commercial complaints (design input for our billing UX). Underlying excerpts: `evidence/Evidence-Competitive-Deep-Research.md`.
- **Provider operational contracts + privacy terms** (F-0036..F-0045): fal (subscribe vs run, concurrency 2→40, 5xx unbilled/422 billable, 365-day credits, 90-day payload retention + `X-Fal-Store-IO: 0` + ZDR), Replicate (600/min, **1-hour file deletion**, defensive throttling, acquisition), Kling direct (unit packages, concurrency 5–20; **Replicate = 2× fal for identical Kling**), Gemini (per-project runtime-fetched limits, tiers/caps, **$300 credit unusable**, failed calls burn quota, paid-vs-free training split), ElevenLabs (per-plan×family concurrency table, WS metering, **default-on training for self-serve + prospective opt-out**, ZRM enterprise), self-hosted path economics (Wan 2.2/LTX-2.5/HunyuanVideo ≈$0.002/s). Underlying excerpts: `evidence/Evidence-Provider-Operations.md`.
- **Provider research documents ×4** delivered: `Provider-Research-Intelligence.md`, `Provider-Research-Image.md`, `Provider-Research-Video.md`, `Provider-Research-Audio.md` — each covering API availability, capabilities, pricing, free quotas, commercial terms, privacy, rate limits, reference-image support, video controls, concurrency, failure behaviour.
- **Seven system specs → v0.2**: appended "Implementation Deep-Dive" to each — exact technical mechanics, data requirements, models used, and honestly stated limitations (per-system focus areas from the review).
- **Architecture corrections**: `Credit-Ledger.md` (proper double-entry: transactions, balanced debit/credit postings, chart of accounts, reservation sub-accounts, recipe-validated write door — ADR-0012); `Asset-Storage.md` (workspace-namespaced R2, workspace-only dedup, no cross-tenant sharing — ADR-0013); `Quota-Reservations.md` (atomic Redis Lua reservations, leases, window-aligned TTLs, fail-closed — ADR-0014); `api/openapi.yaml` (formal contract, validated — ADR-0015); Database-Architecture v2 (correction register, full RLS policies, migration discipline, constraint/index additions); Workflow-Execution §10 (per-provider completion contracts, webhook rules, sweeper, crash re-attach, recovery drills).
- **KI-07 resolved/updated:** REA CLI contract understood (`--view` requires `--detail summary` + `--evidence_output`); standing blocker is environment CDP page-attach timeout (retried 20s/60s/90s); evidence path = web fetch/search per ADR-0003.

## Phase 5 log (2026-11-10)

Delivered the complete planning set in `06-product-planning/`: `Product-Requirements.md` (positioning, personas, differentiators, NFRs, success metrics), `MVP-Scope.md` (the user's 10-stage pipeline with per-stage exit gates + explicit exclusions + architecture-readiness proof), `Development-Roadmap.md` (solo-founder 14–18 week plan; workstreams classified agent-buildable vs agent-assisted vs substantial engineering vs manual; M1–M6 verifiable gates), `Testing-Strategy.md` (pyramid incl. money-path property tests and `test_no_silent_paid_fallback`), `User-Journeys.md` (5 journeys incl. free-quota-exhaustion and confidential-workspace privacy routing), `Feature-Acceptance-Criteria.md` (per-stage ACs mapped to test layers), `Infrastructure-Cost-Estimates.md` (fixed ≈$15–55/mo dev, providers ≈$20–30/mo dev, pilot ≈$870/mo at 50 workspaces, pre-decided scale triggers).

## Next steps

1. **Gate review (user):** the correction + Phase 5 package. Decisions requiring approval are listed in the session's final report (reproduced in Implementation-Progress.md): MVP scope sign-off, roadmap acceptance, provider account setup (class D tasks), paid-LLM contingency, pricing/credit parameters, confidential-workspace default.
2. Phase 6 implementation begins only after approval (user constraint), starting W0–W1 per `Development-Roadmap.md`.

## Gate log (2026-11-10, evening) — APPROVED with directions

The user approved the correction + Phase 5 package with six decisions, recorded as **ADR-0016..0021** and propagated through Security v1.1, Deployment v1.1 (§9 data-residency register), Credit-Ledger §8, Development-Roadmap v1.1, PRD v1.1, MVP-Scope v1.1, Implementation-Progress §4:

1. **MVP scope + roadmap approved** (ADR-0016) — 10-stage pipeline; extensible architecture; no overcomplication.
2. **Staged provider onboarding** (ADR-0017) — initial set: Gemini, Groq, fal.ai, Cloudflare R2; Replicate/ElevenLabs/specialist video deferred until the roadmap requires them; ElevenLabs data-use opt-out applied **and verified** before any content (prospective-only setting, F-0045); credentials never in frontend/repos/docs.
3. **Paid-LLM ceiling ₹0** (ADR-0018) — free-only; insufficiency triggers a quality/latency/cost benchmark for approval; never automatic paid fallback.
4. **Commercial parameters deferred** (ADR-0019) — all configurable (`commercial_config`, versioned); measure actual costs first; payments and credit purchases stay disabled pending commercial/refund/expiry/legal review.
5. **Confidential-by-default** (ADR-0020) — privacy ON for all workspaces; router-level provider restriction (not mere disclaimer) where data policies can't be met; disclosure UX before external submission; no training on customer content.
6. **Supabase Mumbai (ap-south-1)** (ADR-0021) — residency register in Deployment §9; no claim that region choice alone confers DPDP compliance.

Roadmap consequence: W5 rescoped to staged adapters (fal → Gemini → Groq; 2 wk), M2 at wk 6, total 13–17 weeks; ElevenLabs adapter lands at W13 gated on opt-out verification; export ships video+music-bed if VO isn't verified in time.

## Next steps

1. **Phase 6 implementation is unblocked** (ADR-0016): start W0 (repo scaffold + CI) → W1 (DB foundation per Database-Architecture v2 + Credit-Ledger §4 + Asset-Storage §2).
2. Owner actions (class D): create Gemini, Groq, fal.ai, Cloudflare accounts in week 1; ElevenLabs account + opt-out verification before W13; Supabase project in Mumbai region at setup.
3. Mirror workspace → GitHub `quiverra` at this phase boundary (user-side procedure, README §Source of truth).
