# Product Mechanism Blueprint

**AI Creative Production Operating System — codename "Baap of Higgsfield"**
**Version 1.0 · 2026-11-09 · First major deliverable (per Master Brief §17)**
Synthesises: Phase 1 competitive evidence, Phase 2 system specifications, Phase 3 innovation strategy.

---

## 1. What we are building

A **professional AI Creative Production Operating System**: a platform that takes a user from an unstructured creative brief to a finished, professionally structured production — concepts, script, characters, locations, storyboard, shots, images, video, audio — with proprietary intelligence providing the planning, control, continuity, evaluation and cost governance that third-party generation models do not.

**The one-sentence mechanism:** *Brief in → reviewed, costed production plan → continuity-governed generation → auditable results out.*

**What it is not:** another model aggregator, a prompt library, a chatbot, a node canvas, or a thin wrapper over third-party APIs. Third-party models supply generation; the platform owns everything before, around and after it.

## 2. What we learned from existing platforms (Phase 1, evidence-backed)

Research covered Higgsfield (primary), Runway, Kling, Luma, Pika, LTX Studio, and seven pre-production tools, with 16 classified evidence records (`docs/00-research-management/Evidence-Index.md`).

1. **Everyone competes on generation; nobody owns production intelligence.** Higgsfield (30–35+ models, agentic Supercomputer, live MCP) is the most ambitious aggregator, yet its own continuity guidance is a manual workaround list (F-0006). Runway explicitly "does not remember earlier generations" (F-0010). Luma has no screenplay and weak consistency (F-0012). LTX, the closest to our category, has a thin data model with no continuity state or cost governance (F-0014).
2. **Character identity is face-deep and imprisoned.** Best-in-class Soul ID stores a visual identity only, is platform-locked and quota-capped (F-0005).
3. **Cost opacity is the universal complaint.** No rollover (Higgsfield/Luma/Kling), 90-day pack expiry (Higgsfield), failure billing on Kling's app, silent Unlimited exclusions, ~40% price hikes within 2026 (F-0007, F-0011). No platform estimates a project's cost before spend (F-0016).
4. **Controls are dishonest or shallow.** Camera presets without disclosed mechanisms everywhere; only Kling's Motion Brush offers direct manipulation (F-0011). No platform distinguishes model-native parameters from prompt approximations (F-0016).
5. **Brand work is import-and-pray.** Asset bags (Runway) and per-session site scrapes (Higgsfield); no stored rules, no compliance scoring (F-0016).
6. **The pre-production layer is fragmented.** Approval tools don't generate (Boords); generation tools don't plan; production-management tools lack frontier generation (F-0015).
7. **The market consolidated in 2026** (Sora app shut down April 2026) around a handful of frontier models that everyone resells — meaning model access is not a moat for anyone, including us (F-0009).

Full detail: `docs/01-competitive-research/` (4 documents).

## 3. The seven proprietary systems (Phase 2)

All seven are specified in `docs/02-proprietary-systems/` with requirements, data structures, APIs, failure handling and acceptance criteria.

| # | System | Mechanism | Priority |
|---|---|---|---|
| 1 | **Creative Director Engine** | Brief → staged artefacts (interpretation → concepts → costed plan) with approvals and a Creative Decision Graph | P0 |
| 4 | **Scene & Continuity Engine** | Versioned scene state + shot contracts + deterministic pre-flight rules + advisory VLM evaluation | P0 |
| 5 | **Storyboard & Shot Planner** | Shot-as-data records driving generation; version compare; selective regeneration; approval gates | P0 |
| 7 | **Creative Workflow Intelligence** | Plan compiled into executable dependency DAG; budget caps; checkpoints; partial re-runs | P1 |
| 2 | **Character Intelligence Engine** | Portable structured identity (wardrobe/expressions/movement/voice) compiled per model capability | P1 |
| 3 | **Cinema Intelligence Engine** | Honest control taxonomy (native/approximated/conditioned/unsupported) + instruction compiler | P2 |
| 6 | **Brand & Marketing Intelligence** | Brand rules-as-data; plan-stage violation flagging; compliance reports; campaign memory | P2 |

## 4. How the systems interact (the shared model)

Everything hangs off one **Creative Project Model** — no duplicated state between systems:

```
                ┌────────────────────────────┐
                │   CREATIVE DIRECTOR ENGINE │  brief → interpretation → concepts → plan
                └──────────────┬─────────────┘
                               │ approved plan (+ decisions)
        ┌──────────────────────┼───────────────────────────┐
        ▼                      ▼                           ▼
┌───────────────┐    ┌──────────────────┐        ┌──────────────────┐
│   CHARACTER   │    │  SCENE &         │        │  STORYBOARD &    │
│   ENGINE      │◄──►│  CONTINUITY      │◄──────►│  SHOT PLANNER    │
│  (cast data)  │    │  ENGINE          │        │  (shots as data) │
└───────┬───────┘    │ (states/contracts)│       └────────┬─────────┘
        │            └────────┬─────────┘                 │
        │ references          │ contracts + refs          │ generation jobs
        ▼                     ▼                           ▼
┌─────────────────────────────────────────────────────────────┐
│              WORKFLOW INTELLIGENCE (compiled DAG)           │
│   budget caps · gates · checkpoints · partial re-runs       │
└──────────────────────────┬──────────────────────────────────┘
                           │ all spend + intelligence tasks
                           ▼
┌─────────────────────────────────────────────────────────────┐
│   PROVIDER ROUTER (registry · quotas · fallback · ledger)   │
│   intelligence → free/cheap models · generation → policy    │
└─────────────────────────────────────────────────────────────┘
        ▲                          ▲
        │ brand context            │ cinematography compile
┌───────┴────────┐        ┌────────┴─────────┐
│  BRAND ENGINE  │        │  CINEMA ENGINE   │
│ (rules as data)│        │ (honest controls)│
└────────────────┘        └──────────────────┘
```

Interaction contracts (from the specs):
- **Director → everything:** the approved plan is the only entry to production; its edits trigger DAG impact analysis downstream.
- **Characters/Brand → Continuity:** contracts reference *locked versions* of characters and brand context, so mid-production edits flag dependents instead of corrupting them.
- **Continuity → Orchestration:** reference assembly is a pure function over contracts; generation jobs carry frozen input snapshots (ADR-0007).
- **Cinema → Orchestration:** cinematography records compile per model with a visible honesty report.
- **Workflow → Router:** every task is routed (intelligence vs generation), costed deterministically (ADR-0005), and ledgered; no frontend ever touches a provider.
- **Evaluation → Selective regeneration:** failures route to a review queue; fixes re-run exactly the affected subgraph.

Diagrams: `diagrams/Product-Architecture.mmd`, `Data-Relationships.mmd`, `Creative-Production-Workflow.mmd`, `System-Dependencies.mmd`.

## 5. How we will implement it

### 5.1 Stack (per brief §8, validated in Phase 0/4)
- **Frontend:** Next.js + React + TypeScript + Tailwind + shadcn/ui + Zustand. Project/production-centric IA (Dashboard, Projects, Creative Director, Characters, Brands, Storyboard, Shot Planner, Generation Workspace, Assets, Workflows, Usage, Billing).
- **Backend:** Node.js + TypeScript **modular monolith** — modules per system with explicit contracts; REST APIs (per the specs); no microservices prematurely.
- **Data:** Supabase Postgres (row-level security for org/roles) + Supabase Auth; Cloudflare R2 for assets.
- **Jobs:** Redis + BullMQ durable workers, sized for long-running video generation with retries and failure recovery.
- **AI:** custom provider adapters + Provider Router (registry, quotas, fallback, ledger) — intelligence tasks on free/low-cost models (Gemini/Groq/Cloudflare/OpenRouter class), generation on policy-selected paid models. Provider keys server-side only.
- **Payments:** Razorpay or Cashfree (decision in Phase 4/5), activated only after billing rules are defined.
- **Deployment:** Hostinger VPS + Docker + reverse proxy + HTTPS; Supabase/R2 stay managed; separate dev/staging/prod. (Built and deployed user-side — no Docker in the research environment, KI-02.)

### 5.2 Architecture principles already settled (ADRs)
Artefact pipeline over chat (0004) · deterministic costing (0005) · two-layer continuity, rules + advisory VLM (0006) · shot as source of truth with frozen job snapshots (0007) · compiled workflows with idempotent content-hash tasks and event-sourced runs (0008) · platform knowledge as versioned data — rules, vocabularies, classifications, brand rules (0009).

### 5.3 Delivery order (from Product-Prioritisation)
**P0 (MVP):** Provider Router + ledger → Brief→Plan → Scene state + contracts + rules → Shot-as-data storyboard + selective regeneration → sequential workflow execution → character records → decision capture. **P1:** compiled DAG workflows, VLM evaluation, registry UI, brand profiles, cinema labels. **P2:** compliance reports, variants, benchmark harness, team roles, exports. **Future:** API/MCP, marketplace.

### 5.4 Verification doctrine
Every milestone has acceptance criteria in its spec; tests are actually executed and honestly reported; research claims carry confidence classes; the capability registry is evidence-dated; no feature ships claiming guarantees the underlying model doesn't provide (brief §15).

## 6. Why this wins (Phase 3, condensed)

- **The wedge:** plan-before-pay + pre-flight continuity — two demonstrations that save real money in the first session, against competitors whose answer is "regenerate and pray."
- **The moat:** the compounding data layer (decisions, states, contracts, registry evidence) that intelligence features require and competitors' generation-centric architectures can't retrofit cheaply (see `Proprietary-Mechanisms.md` — PM-1…PM-10).
- **The trust position:** cost governance, honest controls, evaluation with confidence — in a market trained to expect credit traps and magic claims.
- **The commercial path:** free tier showcases planning; paid tiers sell governance, continuity depth, team/agency features — priced from the cost model, never ahead of it (brief §14).

## 7. Status and next artefacts

- ✅ Phase 0: environment + REA readiness · Phase 1: competitive research · Phase 2: seven system specs · Phase 3: innovation strategy
- 📦 This blueprint is the gate document per brief §17: **full application development begins only after this blueprint and the technical architecture are reviewed.**
- ⏭️ Phase 4 next: `Overall-Architecture.md`, `Database-Architecture.md`, `API-Architecture.md`, `Orchestration-Engine.md`, `Workflow-Execution.md`, `Security.md`, `Deployment.md`, `Model-Capability-Matrix.md`, `API-Cost-Analysis.md` (includes live-verified provider free-tier research), then Phase 5 product requirements and MVP scope.
