# Product Prioritisation

**Date:** 2026-11-09 · Inputs: Innovation-Opportunities (verdicts), system specs, gap priorities. Output feeds Phase 5 (`MVP-Scope.md`, `Development-Roadmap.md`).

## Prioritisation framework

Each candidate scored 1–5 on:
- **Pain** — severity of the user problem (evidence-weighted)
- **Differentiation** — distance from competitor capability
- **Dependency** — how much else depends on it (platform leverage)
- **Effort (inverse)** — small-team implementability
- **Revenue** — connection to willingness to pay

Priority = Pain + Differentiation + Dependency + Effort(inv) + Revenue (max 25).

## Scores

| Candidate | Pain | Diff | Dep | Effort | Rev | **Total** |
|---|---|---|---|---|---|---|
| Provider Router + credit ledger (PM-7) | 5 | 4 | 5 | 4 | 5 | **23** |
| Shot-as-data storyboard (PM-5) | 5 | 4 | 5 | 4 | 4 | **22** |
| Brief→Plan pipeline (PM-1) | 4 | 5 | 5 | 4 | 4 | **22** |
| Scene state + contracts + rule engine (PM-2/3) | 5 | 5 | 4 | 3 | 4 | **21** |
| Decision graph & asset provenance (PM-9) | 3 | 4 | 4 | 5 | 3 | **19** |
| Sequential workflow execution (MVP slice of PM-6) | 4 | 3 | 3 | 4 | 4 | **18** |
| Character records + reference sets (PM-10 core) | 4 | 3 | 3 | 4 | 4 | **18** |
| Brand profiles + deterministic checks (PM-9 core) | 3 | 4 | 2 | 4 | 5 | **18** |
| VLM output evaluation (PM-4) | 4 | 4 | 2 | 2 | 4 | **16** |
| Compiled DAG workflows, budget caps, partial re-runs (PM-6 full) | 4 | 5 | 2 | 2 | 4 | **17** |
| Cinema vocabulary + honesty labels (PM-8 partial) | 3 | 4 | 2 | 4 | 3 | **16** |
| Multi-format campaign variants | 3 | 3 | 1 | 3 | 4 | **14** |
| Benchmark harness for control taxonomy (PM-8 full) | 2 | 5 | 1 | 2 | 3 | **13** |
| Team/org collaboration & roles | 3 | 2 | 1 | 3 | 5 | **14** |
| API/MCP surface (IO-10) | 2 | 3 | 1 | 3 | 3 | **12** |
| Animatic/EDL exports | 2 | 3 | 1 | 4 | 2 | **12** |

## Tiers

### P0 — MVP (build first)
1. **Provider Router + credit ledger** (PM-7) — everything spends through it; build first.
2. **Brief→Plan pipeline** (PM-1) with staged approvals + decision capture.
3. **Scene state + contracts + core continuity rules** (PM-2/3) — the signature feature.
4. **Shot-as-data storyboard** (PM-5): records, board/table views, per-shot generation with references, version comparison, selective regeneration (single-shot), approval states (self-approval in MVP).
5. **Sequential workflow execution** (PM-6 slice): plan → ordered job list with progress + failure handling.
6. **Character records + reference sets** (PM-10 core) feeding reference assembly.
7. **Decision graph & provenance** (PM-9) — embedded, nearly free given the above.

*MVP explicitly excludes: VLM automated evaluation, compiled DAG workflows with budget caps, brand compliance reports, cinema benchmark harness, team roles, multi-format variants, API/MCP, payments activation.*

### P1 — Second stage
1. Compiled DAG workflows + budget caps + partial subgraph re-runs (PM-6 full).
2. VLM output evaluation + review queue (PM-4) — after benchmarking establishes trustworthy thresholds.
3. Registry UI + routing policies + cost analytics (PM-7 surface).
4. Brand profiles + deterministic compliance checks (PM-9 core).
5. Cinema vocabulary + honesty labels from documented provider capabilities (PM-8 partial).
6. Character versioning/approval + identity evaluation (PM-10 full).

### P2 — Advanced
1. Brand compliance reports + multi-format campaign variants.
2. Control benchmark harness + published capability matrix (PM-8 full).
3. Team/org roles, client review gates (agency motion).
4. Animatic/EDL exports, call sheets.
5. Voice profiles + clone-provider integration.

### Future
- API/MCP surface (IO-10), marketplace for skills/templates, self-hosted model support, mobile capture apps.

## Sequencing rationale

- **Router first** because every later feature spends through it; retrofitting cost governance is how platforms end up with credit-trap UX we criticise.
- **Plan → storyboard → continuity** is the demo-able spine: brief in, plan out, pre-flight report green, shots generate with visible savings vs regenerate-everything. That's the wedge demo.
- **Evaluation last among core** because trust in our flagship claims depends on benchmarks, not vibes (honesty doctrine).
