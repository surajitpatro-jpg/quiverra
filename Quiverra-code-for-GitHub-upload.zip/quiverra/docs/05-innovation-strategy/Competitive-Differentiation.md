# Competitive Differentiation

**Date:** 2026-11-09 · Inputs: Phase 1 evidence, Phase 2 specs, Innovation-Opportunities.

## Positioning statement

> **For professional creative teams and serious creators** who produce multi-shot, multi-asset creative work, **our platform is the AI Creative Production Operating System** that turns a brief into a governed, continuity-safe, cost-controlled production — **unlike Higgsfield, Runway, Kling and the aggregators**, which sell access to generation models and leave planning, continuity, brand compliance and cost governance to the user.

Category language matters: competitors are *generation platforms*; we are a *production system that generates*. Every competitor claim about models is answerable with "we use those models too — through our router, with a plan, a continuity contract and a cost estimate attached."

## The five differentiation pillars

### P1 — Production intelligence, not model access
Editable, costed, approvable production plans from unstructured briefs; staged approvals; impact analysis. Competitors: chat agents that evaporate (Supercomputer, Runway Agent, Luma Agents) or boards without plans (LTX).
**Proof point:** "Describe the ad. Get a plan, a shot list and a price — before you spend anything."

### P2 — Continuity as engineering, not folklore
Scene state, shot contracts, pre-flight conflict detection, confidence-scored evaluation, audited overrides. Competitors: reference-anchoring tips and post-hoc repair (Higgsfield's own blog is a workaround list).
**Proof point:** "We catch the wardrobe change in shot 8 before it costs you credits."

### P3 — Cost honesty in an industry of credit traps
Itemised pre-production estimates, policy comparison (cost/balanced/quality), budget caps, no silent paid fallback, no-rollover-free ledger of our own. Competitors: no rollover + 90-day expiry (Higgsfield), failure billing on app (Kling), no free plan (Luma).
**Proof point:** "You approve the spend before it happens. Always."

### P4 — Assets that persist and compound
Characters with wardrobe/expressions/voice, brand profiles with rules, campaign memory, decision provenance — all versioned, approvable, portable, provider-independent. Competitors: platform-locked faces (Soul ID), asset bags (Brand Kits), session scrapes (Ads Studio).
**Proof point:** "Your cast, your brand rules, your decisions — still there next project, next campaign."

### P5 — Honesty as product design
Per-model control classifications (native/approximated/conditioned/unsupported), evaluation shown with confidence, capability matrix published. Competitors: preset marketing and black-box orchestrators.
**Proof point:** "We label what the model actually does. Nobody else does."

## Head-to-head differentiation summary

| Competitor | Their centre of gravity | Our counter |
|---|---|---|
| **Higgsfield** | Generation UX + aggregation + agentic convenience (Supercomputer, MCP) | We aggregate too — but under plans, contracts and budgets; their agent is opaque, ours is auditable; their continuity is tips, ours is state |
| **Runway** | Editing/finishing suite (Aleph, ProRes/HDR) | We don't out-edit them; we plan and govern what gets generated, and export to pro pipelines (EDL/animatic) |
| **Kling** | Model vendor: cheap, Motion Brush, voice-bound Elements | We're model-agnostic — Kling-class models are providers inside our router; Motion-Brush-style control is one mechanism in our taxonomy |
| **Luma** | Speed + finishing (Ray, HDR/EXR), agent boards | Same class of models available via router; we add the screenplay, storyboard and continuity they explicitly lack |
| **Pika** | Consumer effects, cheap entry | Different audience; our free tier wins on utility, not effects |
| **LTX Studio** | Closest: script→board→video | Thin data model, no continuity state, no cost governance, desktop-only, vendor-locked feel — we go deeper on every axis |
| **Boords/Katalist/Storyflow/Studiovity** | Slices of pre-production | We absorb their slices (approval, shot lists, breakdowns) and connect them to frontier generation — they can't follow us there |

## Differentiation risks (honest)

1. **Aggregation is not defensible** — our moat is the production data layer (decisions, states, contracts, registry), not model access. We must never market "we have 30 models" as the headline.
2. **Feature absorption:** Higgsfield ships fast (Supercomputer in ~6 weeks, their account). Our defence is depth they haven't started (state, rules, compliance) plus data compounding in user accounts.
3. **Cold-start credibility:** continuity/evaluation claims must be demonstrable in-product with low magic-talk, or we join the overpromisers we criticise. Hence advisory-first design (ADR-0006) and honesty labels everywhere.
4. **Price anchoring against Kling's $8.80:** we don't fight entry price; our free tier showcases planning, paid tiers sell governance and team features.

## Messaging spine (for later marketing work)

- Category: **AI Creative Production OS** (never "AI video generator").
- Enemy: the regenerate-everything tax, credit anxiety, chat-amnesia planning.
- Hero artefacts: the Plan, the Continuity Report, the Cost Estimate, the Compliance Report.
