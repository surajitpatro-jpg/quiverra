# Innovation Opportunities

**Date:** 2026-11-09 · Consolidates Gap Analysis (Phase 1), brief §13 opportunities (A–G), and the seven system specs (Phase 2).
Assessment per brief §13: technical feasibility, commercial value, realistic implementability by a small team.

## Scoring key
Feasibility / Value / Small-team fit: **H** high · **M** medium · **L** low. Verdict: **Build now** (MVP), **Build next** (post-MVP), **Incubate** (needs validation), **Defer**.

---

## IO-1 — Brief→Plan Production OS (Creative Director Engine)
*Source: Gap 1, brief §13-F (Intelligent Production Planning).*
Nobody converts an unstructured brief into an editable, costed, approvable production plan. Chat agents (Supercomputer, Runway Agent) produce generations, not plans; planning tools (Storyflow, Studiovity) don't generate.
- **Feasibility H** — LLM + JSON schemas + staged pipeline; no novel ML.
- **Value H** — it's the spine every other system hangs from; enables the cost story (IO-5).
- **Small-team H** — the heaviest lift is UX, not algorithms.
- **Verdict: Build now (P0).**

## IO-2 — Scene State & Continuity Contracts (Scene & Continuity Engine)
*Source: Gap 2, brief §13-D (Continuity Evaluation).*
Continuity is manual folklore across every competitor (F-0006, F-0010, F-0012). Structured scene state + shot contracts + rule-based pre-flight detection + VLM output evaluation is unowned territory.
- **Feasibility M/H** — state model and rule engine are straightforward; VLM evaluation needs benchmarking to be trustworthy (hence advisory design, ADR-0006).
- **Value H** — the loudest pain in every review we found; direct money-saver (errors caught before spend).
- **Small-team M** — start with deterministic rules + manual review queue; grow VLM evaluation incrementally.
- **Verdict: Build now (P0), VLM evaluation phased.**

## IO-3 — Shot-as-Data Storyboard with Selective Regeneration
*Source: Gap 5, brief §13-E (Selective Regeneration).*
LTX's board is the best available and is still a picture board; nobody offers structured shot records driving generation with dependency-aware single-shot replacement.
- **Feasibility H** — CRUD + graph events + job orchestration.
- **Value H** — turns "regenerate everything" into "replace shot 7"; measurable savings.
- **Small-team H**.
- **Verdict: Build now (P0).**

## IO-4 — Compiled, Dependency-Aware Workflows (Workflow Intelligence)
*Source: Gap 8, brief §13-C/F.*
Competitors: manual sequencing, drawn node graphs (Canvas), or opaque agent runs (Supercomputer). A workflow compiled from the plan — with budget caps, gates, checkpoints and partial re-runs — is a category shift.
- **Feasibility M** — DAG compile + durable job execution (BullMQ); engineering-heavy but known patterns.
- **Value H** for professionals; **M** for casual users (they won't see it).
- **Small-team M** — sequence after P0 systems prove their data models.
- **Verdict: Build next (P1), MVP includes simple sequential execution only.**

## IO-5 — Cost Governance & Provider Router Transparency
*Source: Gap 7/8, brief §7.*
Universal credit anger (no rollover, expiry, silent exclusions, failure billing, price hikes). Pre-production itemised estimates + policy comparison + budget caps + no-silent-paid-fallback + visible capability registry is a trust product in itself.
- **Feasibility H** — deterministic costing (ADR-0005) + adapter layer + ledger.
- **Value H** — also protects *our* margins; prerequisite for any commercial model.
- **Small-team H** — the registry is grunt work, but it's our moat data.
- **Verdict: Build now (P0 infrastructure), full registry UI Build next (P1).**

## IO-6 — Characters as Portable Structured Assets
*Source: Gap 3, brief §13-A (Persistent Creative Memory).*
Soul ID proved demand (and its limits: visual-only, locked, quota-capped). Structured identity (wardrobe/expressions/movement/voice) + versioning + provider-independent compile is deeper and anti-lock-in.
- **Feasibility M/H** — data/workflow layer easy; identity evaluation phased like IO-2.
- **Value H** for agencies/series content; M for one-off creators.
- **Small-team M/H**.
- **Verdict: Build next (P1); MVP ships basic character records + reference sets.**

## IO-7 — Honest Cinematography Layer
*Source: Gap 4, brief §13-G (Professional Creative Controls).*
Per-(control × model) classification (native/approximated/conditioned/unsupported) with benchmark evidence — no competitor discloses mechanism. Focal length/aperture/motivated lighting as compiled semantics.
- **Feasibility M** — compiler is easy; the benchmark harness is the real work and must be maintained per model update.
- **Value M/H** — a professional trust feature and content-marketing gold (publish the matrix).
- **Small-team M** — phased: vocabulary + compiler first, harness second.
- **Verdict: Incubate→Build next (P2 in MVP: vocabulary + honesty labels from documented provider capabilities; benchmarks post-MVP).**

## IO-8 — Brand Intelligence & Compliance
*Source: Gap 6.*
Brand profiles with voice/rules/restrictions, plan-stage violation flagging, deterministic-first compliance reports, campaign memory. Competitors: asset bags (Runway) and session scrapes (Higgsfield).
- **Feasibility M/H** — rules-as-data + deterministic checks easy; VLM style checks phased.
- **Value H** for the paying segment (agencies/teams).
- **Small-team M** — depends on plan pipeline (IO-1) existing first.
- **Verdict: Build next (P2); MVP ships profile storage + palette/copy deterministic checks.**

## IO-9 — Creative Decision Graph & Asset Provenance
*Source: Gap 9, brief §13-B (Creative Decision Graph).*
Record what was chosen/rejected and why; every asset links to its shot, settings, references, evaluation and approvals. Competitors' outputs die in feeds.
- **Feasibility H** — it's a by-product of doing IO-1/2/3 correctly (decision capture + asset linkage).
- **Value M/H** — team auditability; also our long-term data moat.
- **Small-team H** — nearly free if designed in from day one (ADR-0004/0007).
- **Verdict: Build now (P0, embedded in P0 systems).**

## IO-10 — Platform API / Agent Surface (future)
*Source: brief §14; market signal — Higgsfield/Runway both shipped MCP.*
Once our production objects (plans, shots, contracts, workflows) are data, exposing them via API/MCP lets agents and other tools build on us.
- **Feasibility M** — our REST contracts already exist per specs; MCP is a thin layer.
- **Value M now, H later** — ecosystem play.
- **Small-team M** — trivially small once internals are stable.
- **Verdict: Defer to post-PMF.**

---

## Summary map

| IO | Opportunity | F | V | S | Verdict |
|---|---|---|---|---|---|
| IO-1 | Brief→Plan OS | H | H | H | **Build now (P0)** |
| IO-2 | Continuity engine | M/H | H | M | **Build now (P0)** |
| IO-3 | Shot-as-data storyboard | H | H | H | **Build now (P0)** |
| IO-9 | Decision graph & provenance | H | M/H | H | **Build now (P0, embedded)** |
| IO-5 | Cost governance + router | H | H | H | **P0 infra, P1 UI** |
| IO-4 | Compiled workflows | M | H | M | **Build next (P1)** |
| IO-6 | Character assets | M/H | H | M/H | **Build next (P1)** |
| IO-8 | Brand intelligence | M/H | H | M | **Build next (P2)** |
| IO-7 | Cinema honesty layer | M | M/H | M | **P2 partial, incubate benchmarks** |
| IO-10 | API/MCP surface | M | M→H | M | **Defer** |
