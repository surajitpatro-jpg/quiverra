# Proprietary Mechanisms

**Date:** 2026-11-09 · The named, ownable mechanisms that make the platform more than an aggregator. Each: what it is, how it works, why it's hard to copy, status.

---

## PM-1 — The Production Plan Artefact & Creative Decision Graph
**What:** Creative work as staged, versioned, approvable artefacts (interpretation → concepts → plan → scenes → shots), where every select/reject/edit is recorded as a decision node with alternatives and rationale.
**How:** Staged state machine (ADR-0004); JSON-schema-validated LLM outputs; artefact DAG for impact analysis; decision capture on every mutation.
**Why hard to copy:** requires rebuilding the product around artefacts instead of generations — competitors' chat/generation-centric architectures fight it; the graph's value compounds with account history.
**Status:** Specified (Creative-Director-Engine). MVP: core artefacts + decision capture.

## PM-2 — Scene State & Continuity Contracts
**What:** The market's only structured model of what must stay true across shots — characters' wardrobe, props, positions, lighting, screen direction — with entry/exit states per scene and per-shot preservation contracts.
**How:** Versioned scene-state documents; contracts auto-derived from script/plan, user-editable; event-driven re-validation on structural edits.
**Why hard to copy:** a data-model commitment, not a feature; retro-fitting it onto generation feeds means rebuilding asset pipelines. Compounds: more projects → richer state patterns.
**Status:** Specified (Scene-Continuity-Engine). MVP: state + contracts + deterministic rules.

## PM-3 — Pre-Flight Continuity Rule Engine
**What:** Deterministic conflict detection before any generation spend (wardrobe changes, prop disappearance, position jumps, unmotivated lighting, line-crossing), with severity and one-click propagation fixes.
**How:** Rules as versioned data (ADR-0009) evaluated over contracts/states; blocking vs warning; overrides audited.
**Why hard to copy:** needs PM-2 to exist first; the rule library grows with real production usage (data moat).
**Status:** Specified. MVP: ~15 core rules.

## PM-4 — Confidence-Scored Output Evaluation (Advisory VLM Layer)
**What:** Generated assets checked against their contracts and approved references — identity, wardrobe, props, style, brand — with per-check scores, confidence, model identity disclosed, and a human review queue. Explicitly advisory (ADR-0006): never mutates state alone, never presented as guarantee.
**How:** Routed VLM tasks; thresholds as project policy; results feed selective regeneration.
**Why hard to copy:** requires PM-1/2 context to evaluate *against*; competitors can only compare a render to a prompt.
**Status:** Specified. Phased: manual review queue first, VLM checks post-MVP after benchmarking.

## PM-5 — Shot-as-Data with Dependency-Aware Selective Regeneration
**What:** The shot as a first-class record (camera, lighting, contract, dependencies, versions) that drives generation; replacing one shot touches exactly one shot.
**How:** Shot records as source of truth (ADR-0007); frozen input snapshots per job; dependency graph from contracts; version promotion/rollback.
**Why hard to copy:** board tools would need to become databases; generation tools would need to become planners.
**Status:** Specified (Storyboard-Shot-Planner). MVP core.

## PM-6 — Compiled Workflows (Plan → Executable DAG)
**What:** Production execution derived from the plan as a dependency DAG — not drawn by users — with idempotent content-hash tasks, parallel dispatch under provider backpressure, gates, checkpoints, budget caps, partial subgraph re-runs, event-sourced run logs.
**How:** Compiler from plan+storyboard to task graph; durable queue execution (BullMQ); content-hash caching for asset reuse.
**Why hard to copy:** agentic competitors chose opacity (their orchestrator is the product); our transparency *is* the mechanism, and it depends on PM-1/5 data existing.
**Status:** Specified (Workflow-Intelligence). Post-MVP; MVP runs simple sequential execution.

## PM-7 — Provider Router + Dual Ledger (Cost Governance)
**What:** Backend-only routing across providers via a Model Capability Registry; intelligence tasks to free/cheap models, generation to policy-selected models; quotas/health/fallback; and a strict separation of provider spend from customer credits with itemised pre-production estimates (ADR-0005) and no-silent-paid-fallback.
**How:** Adapter layer; deterministic costing stamped with registry version; quota manager with backoff; credit ledger with refund policy.
**Why hard to copy:** the registry is maintained evidence (per-model rates, capabilities, control classifications); aggregators show balances, not governance.
**Status:** Architecture specified in specs; Phase 4 produces the registry seed + cost analysis.

## PM-8 — Honest Control Taxonomy & Instruction Compiler
**What:** Every cinematography control classified per model (native / prompt-approximated / reference-conditioned / unsupported) with dated benchmark evidence; a pure-function compiler turning cinematography records into per-model instructions plus a user-visible honesty report.
**How:** Canonical vocabulary (ADR-0009); benchmark harness for verification; registry-stamped compilations.
**Why hard to copy:** classifications are living evidence — copying the UI without the harness yields the same dishonest presets everyone already has.
**Status:** Specified (Cinema-Intelligence). MVP: vocabulary + documented-capability labels; harness post-MVP.

## PM-9 — Brand Rules-as-Data & Compliance Gate
**What:** Brand voice, messaging rules, restrictions and catalogue as structured records injected into planning (violations flagged free, pre-generation) and enforced via deterministic-first compliance reports (palette/copy = code; style = VLM with confidence).
**How:** Compiled brand context per brand version; frozen snapshots in-flight; audited overrides.
**Why hard to copy:** needs the plan pipeline (PM-1) to flag early and the evaluation layer (PM-4) to score outputs; asset bags can't become this.
**Status:** Specified (Brand-Marketing-Intelligence). P2.

## PM-10 — Characters as Portable Compiled Identity
**What:** Structured character identity (wardrobe sets, expressions, gestures, movement, voice) versioned and approved, compiled per target model's real identity mechanism — provider-independent by design.
**How:** Identity records + reference sheets with input quality gates; capability map per model; compiler emits reference sets + descriptor blocks or trained-identity calls as appropriate.
**Why hard to copy:** directly attacks lock-in economics (Soul ID is a retention feature); depth (beyond-face data) is unglamorous schema work competitors skip.
**Status:** Specified (Character-Intelligence). MVP: records + references; compile/eval phased.

---

## Moat logic (how the mechanisms compound)

PM-1 (decisions) + PM-2 (states) + PM-5 (shots) create the **data layer**. PM-3/4/8/9 are **intelligence layers that only work because the data layer exists**. PM-6/7 are **execution/governance layers** that only work because the intelligence layers exist. A competitor copying any single mechanism gets a feature; the compounding stack is the product.
