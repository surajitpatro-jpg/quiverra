# Feature Comparison — Mapped to Our Seven Systems

**Research date:** 2026-11-09
Ratings: ● strong · ◐ partial · ○ absent. Based on evidence in `Higgsfield-Product-Map.md` and `Competitive-Benchmark.md`; ○ means "no evidence found in public material", not a guarantee of absence.

## Dimension 1 — Creative brief → production plan intelligence

| | Higgsfield | Runway | Kling | Luma | Pika | LTX Studio | Storyboard tools |
|---|---|---|---|---|---|---|---|
| Brief interpretation | ◐ (Supercomputer chat; Project Brief) | ◐ (Runway Agent) | ○ | ◐ (Agents brainstorm) | ○ | ◐ (script/concept input) | ◐ (script import) |
| Structured production plan output | ○ | ○ | ○ | ○ | ○ | ◐ (storyboard) | ◐ (boards, shot lists) |
| Concept/moodboard generation | ◐ (Canvas) | ○ | ○ | ◐ (boards) | ○ | ◐ | ◐ (Milanote-style in some) |
| Cost estimation before production | ○ (per-step only) | ○ | ○ | ○ | ○ | ○ | ○ |
| User approval gates before spend | ◐ (Supercomputer shows cost per plan) | ○ | ○ | ○ | ○ | ○ | ○ |

**Nobody** converts an unstructured brief into a full, editable, costed production plan (script, characters, locations, shot list, camera plan, budget) with approval checkpoints.

## Dimension 2 — Character persistence

| | Higgsfield | Runway | Kling | Luma | Pika | LTX | Katalist/Boords |
|---|---|---|---|---|---|---|---|
| Trained identity | ● Soul ID (25cr, ~5 min) | ○ | ◐ Elements (voice-bound) | ◐ Master Ref Assets | ○ | ◐ Elements | ● locked character models |
| Cross-project reuse | ● (Elements shared) | ○ | ◐ | ◐ | ○ | ◐ (per project) | ◐ |
| Structured identity data (wardrobe, personality, voice…) | ○ (visual only) | ○ | ◐ (visual+voice) | ○ | ○ | ○ | ○ |
| Identity versioning / approval states | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| Honest capability documentation | ● (their blog lists limits) | — | ◐ | ◐ | — | ◐ | ◐ |
| Exportable/portable identity | ○ (platform-locked) | — | ○ | ○ | — | ○ | ○ |

Best-in-class is Soul ID, and even it is a *visual* identity only: no wardrobe/personality/expression/gesture model, no versioning, no approval workflow, and no portability.

## Dimension 3 — Cinematic control

| | Higgsfield | Runway | Kling | Luma | Pika | LTX |
|---|---|---|---|---|---|---|
| Camera move vocabulary | ● presets + Cinema Studio | ◐ | ◐ + **Motion Brush** | ◐ keyframes | ○ effects | ◐ camera controls |
| Lens/optics parameters (focal length, aperture, DoF) | ◐ (Cinema Studio gear-style profiles) | ○ | ○ | ○ | ○ | ○ |
| Shot type taxonomy (EWS→ECU, OTS, POV…) | ◐ | ○ | ◐ multi-shot | ○ | ○ | ◐ |
| Lighting control | ◐ | ◐ | ○ | ◐ HDR | ○ | ◐ style presets |
| Honesty about which controls are real vs prompt-approximated | ○ (not disclosed) | ○ | ○ | ○ | ○ | ○ |

Higgsfield leads on accessible camera language; Kling's Motion Brush is the most *direct* control. **No platform distinguishes genuinely model-supported parameters from prompt approximations** — a documentation and trust gap we can exploit.

## Dimension 4 — Scene & continuity

| | Higgsfield | Runway | Kling | Luma | Pika | LTX |
|---|---|---|---|---|---|---|
| Structured scene state | ○ | ○ | ○ | ○ | ○ | ○ |
| Continuity conflict detection | ○ | ○ | ○ | ○ | ○ | ○ |
| Pre-generation consistency checks | ○ | ○ | ○ | ○ | ○ | ○ |
| Post-hoc repair | ● Genjutsu Object Swap | ◐ Aleph edit | ○ | ◐ Modify Video | ◐ swaps | ○ |
| Frame chaining tools | ● Start/End Frame, Extend 30s | ◐ | ◐ extend (3 min) | ◐ extend | ◐ | ◐ |

**Universal gap.** Every platform treats continuity as reference-anchoring plus post-hoc fixes. None models scene state (wardrobe/props/positions/screen direction/time-of-day) or detects conflicts before generation.

## Dimension 5 — Storyboard & shot planning

| | Higgsfield | Runway | Kling | Luma | Pika | LTX | Dedicated tools |
|---|---|---|---|---|---|---|---|
| Storyboard entity | ○ | ○ | ◐ | ○ | ○ | ● Dynamic Storyboard | ● |
| Per-shot structured data (duration, camera, lighting, deps) | ◐ (AI Director drafts) | ○ | ○ | ○ | ○ | ◐ | ◐ (Storyflow/Studiovity deepest) |
| Reorder/add/delete/regenerate individual shots | ○ | ○ | ○ | ○ | ○ | ◐ | ◐ |
| Shot approval workflow | ○ | ◐ (frame comments, Team) | ○ | ○ | ○ | ○ | ● Boords |
| Version compare per shot | ○ | ○ | ○ | ○ | ○ | ○ | ◐ |
| Shot→generation dependency tracking | ○ | ○ | ○ | ○ | ○ | ◐ | ○ |

LTX is closest to a shot system but its storyboard is a visual board, not a data model; Boords owns approval workflow but has no generation.

## Dimension 6 — Brand & marketing intelligence

| | Higgsfield | Runway | Kling | Luma | Pika | LTX |
|---|---|---|---|---|---|---|
| Persistent brand profile | ◐ Brand Kit (from URL) | ◐ Brand Kits (Pro 1 / Max 3) | ○ | ○ | ○ | ○ |
| Brand rules/messaging/restrictions storage | ○ | ○ | ○ | ○ | ○ | ○ |
| Brand-compliance evaluation of outputs | ○ | ○ | ○ | ○ | ○ | ○ |
| Product catalogue integration | ● Ads Studio (site import, SKU batches) | ◐ Runway Ads | ○ | ○ | ○ | ○ |
| Multi-aspect exports | ◐ | ◐ | ◐ | ◐ reframe | ◐ | ◐ |

Higgsfield's Ads Studio is the strongest marketing workflow, but "brand intelligence" is import-and-reuse, not understanding: no stored voice/tone/rules, no compliance scoring.

## Dimension 7 — Workflow intelligence & orchestration

| | Higgsfield | Runway | Kling | Luma | Pika | LTX |
|---|---|---|---|---|---|---|
| Automatic workflow construction | ● Supercomputer | ◐ Agent | ○ | ◐ Agents | ○ | ◐ Flows |
| Dependency-aware execution | ○ (agent-implicit) | ○ | ○ | ○ | ○ | ○ |
| Selective/partial regeneration | ◐ Genjutsu (post-hoc) | ◐ | ○ | ◐ | ◐ | ◐ |
| Version management | ◐ (Canvas autosave) | ◐ | ○ | ○ | ○ | ◐ |
| Cost/credit governance | ◐ (pre-gen cost display) | ○ | ○ | ○ | ○ | ○ |
| Provider routing transparency | ○ (Orchestrator black box) | ○ | n/a | ○ | ○ | ○ |
| Failure handling / refunds | ● auto-refund failed gens | ◐ | ◐ (API only; app bills failures) | ● refunded | ◐ | ◐ |

## Summary scorecard (our judgement, evidence-bounded)

| Platform | One-line verdict |
|---|---|
| Higgsfield | Best generation UX + agentic convenience; production structure absent |
| Runway | Best editing/finishing suite; no persistence or planning |
| Kling | Best model value + Motion Brush + voice-bound elements; platform layer thin |
| Luma | Best speed/finishing (HDR/EXR); weakest consistency & narrative |
| Pika | Cheapest entry, social effects; not a production tool |
| LTX Studio | Closest to script→board→video; shallow data model, single-vendor feel |
| Boords/Katalist/Storyflow | Own slices of pre-production; no frontier generation |
