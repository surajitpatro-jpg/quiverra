# Competitive Gap Analysis

**Research date:** 2026-11-09
Method: gaps derived strictly from evidence in this folder (see `Evidence-Index.md`). Each gap is rated for feasibility (small team), commercial value, and defensibility.

---

## The one-sentence finding

> Every major platform competes on **generation** (models, presets, price, speed). Nobody owns **production intelligence**: the structured, persistent, cost-aware layer that turns a brief into a governed, continuity-safe production. That layer is our product.

## Gap 1 — No brief→plan→produce operating system

**Evidence.** Higgsfield Supercomputer plans ad-hoc tasks in chat; its artefact is generations. LTX builds storyboards but with thin data. Runway/Luma agents brainstorm but hold no screenplay (Luma explicitly has no script editor). Storyflow/Studiovity plan but don't generate frontier video.

**What users get today:** a chat that makes clips, or a board that makes presentations — never a reviewed, costed, editable production plan that drives generation.

**Our answer (System 1 + 7):** Creative Director Engine producing a structured production plan (concept, script, characters, locations, scenes, shots, camera plan, audio, cost estimate) that the user reviews and edits *before* money is spent, then Workflow Intelligence executes it with approval gates.

**Feasibility:** High (LLM + structured schema + UI). **Value:** High — it's the product's spine. **Defensibility:** Medium-high (data model + continuity integration, not a prompt).

## Gap 2 — Continuity is folklore, not a system

**Evidence.** Higgsfield's own continuity guidance is a list of manual techniques (@refs, Elements, frame chaining, "start a new chain every 2–3 clips because errors accumulate", post-hoc Genjutsu repair). Kling/LTX Elements anchor references but track no state. Runway: "Gen-4.5 does not remember earlier generations."

**Our answer (System 4):** Scene & Continuity Engine — structured scene state (characters, wardrobe, props, positions, lighting, time-of-day, weather, screen direction, geography), dependency tracking between shots, **pre-generation conflict detection** (wardrobe changes, prop disappearance, position jumps, unmotivated lighting changes), continuity evaluation of outputs, and selective regeneration of only the offending shot.

**Feasibility:** Medium (state model + rule engine + VLM-based output evaluation). **Value:** Very high — this is the #1 pain in every review we found. **Defensibility:** High (accumulating scene graph + evaluation data).

## Gap 3 — Character systems are face-deep

**Evidence.** Soul ID: visual identity only, platform-locked, quota-limited, no versioning. Kling Elements: visual + voice. Nothing stores wardrobe, personality, expression ranges, movement characteristics, or approval states.

**Our answer (System 2):** Character Intelligence Engine — a structured character asset (appearance, wardrobe, accessories, personality, expressions, gestures, movement, voice), reference-sheet management, version history, approval states, cross-project reuse with permissions, and honest per-model capability mapping (what reference conditioning each model actually supports).

**Feasibility:** High for the data/workflow layer; Medium for automated identity evaluation (VLM scoring). **Value:** High for agencies/brands/series content. **Defensibility:** Medium-high.

## Gap 4 — Cinematic controls without honesty or depth

**Evidence.** Every platform offers camera presets; none discloses which parameters the underlying model truly honours vs which are prompt wishes. No platform offers lens/optics semantics (focal length, aperture, DoF) with documented behaviour. Kling Motion Brush proves users want *direct* control.

**Our answer (System 3):** Cinema Intelligence Engine — a cinematography control layer where every control is classified: **model-native** (verified to affect output), **prompt-approximated**, or **reference-conditioned**. Shot-type taxonomy (EWS→ECU, OTS, POV, establishing), lighting vocabulary, all compiled into per-model optimised instructions by the router. We publish the capability matrix; competitors don't.

**Feasibility:** High (benchmarking harness + compiler). **Value:** Medium-high (professional trust feature). **Defensibility:** Medium (matrix must be maintained — that's also the moat).

## Gap 5 — Storyboards aren't data

**Evidence.** LTX's Dynamic Storyboard is the best in class, yet it's a visual board with limited structured fields; Boords owns approval workflow but can't generate; Higgsfield's AI Director drafts shots but the artefact is generations.

**Our answer (System 5):** Storyboard & Shot Planner — every shot a structured record (IDs, duration, narrative purpose, character/location/prop references, action, camera position/movement, shot type, lighting, composition, start/end frames, audio, model + settings, dependencies, approval status, versions). Full edit/reorder/add/delete/regenerate-one/compare-versions/approve-reject. Generation is *driven by* the shot list, so regenerating one shot never rebuilds the project.

**Feasibility:** High. **Value:** High. **Defensibility:** Medium (execution quality matters).

## Gap 6 — Brand intelligence is import-and-pray

**Evidence.** Higgsfield Brand Kit "pulls brand details from your site"; Runway Brand Kits are asset bags. No competitor stores messaging rules, tone, restrictions, or scores outputs for compliance.

**Our answer (System 6):** Brand & Marketing Intelligence Engine — persistent brand profiles (colours, typography, voice, tone, messaging rules, restrictions, approved assets, product references, campaign history) injected into every planning and generation step, plus automated **brand-compliance evaluation** of outputs and one-brief multi-format campaign production (aspect-ratio variants from the same plan).

**Feasibility:** Medium-high. **Value:** High for agencies/teams (the paying segment). **Defensibility:** Medium-high (profile data compounds).

## Gap 7 — Cost opacity and credit anxiety

**Evidence.** Universal complaints: credits that don't roll over (Higgsfield, Luma, Kling), 90-day pack expiry (Higgsfield), 24h free-credit expiry (Kling), failed-generation billing on Kling's app, per-model rates that change, Unlimited that silently excludes MCP/CLI/Canvas/Supercomputer (Higgsfield), Kling list prices +40% during 2026. Nobody shows a **project-level cost estimate before production**.

**Our answer (System 7 + Provider Router):** pre-production cost estimation per project/scene/shot; a visible Model Capability Registry with per-model rates; routing that prefers free/cheap intelligence models for planning and reserves paid generation for finals; a customer credit ledger kept rigorously separate from provider quotas; no silent paid fallback.

**Feasibility:** High. **Value:** High (trust + margin control). **Defensibility:** Medium-high (registry + ledger data).

## Gap 8 — Routing is a black box

**Evidence.** Higgsfield's Orchestrator picks models without exposing why; aggregators resell the same 6–8 frontier models; users can't set routing policy (cost-first, quality-first, privacy-first).

**Our answer:** Provider Router with a user-visible capability matrix, explicit routing policies, fallback chains, quota/health monitoring — and later, benchmark-driven routing published as living documentation.

**Feasibility:** High. **Value:** Medium-high. **Defensibility:** Medium (ops excellence).

## Gap 9 — Assets die in chat histories

**Evidence.** Generations land in project feeds; approved assets, versions and their provenance (which shot, which settings, which references) aren't first-class. Boords/Frame.io prove review/approval value; generation platforms ignore it.

**Our answer:** managed asset library where every asset links to its shot, generation settings, references, evaluation and approval state — reusable across projects with permissions.

**Feasibility:** High. **Value:** Medium-high. **Defensibility:** Medium.

## Gap priority (recommendation for Phase 3)

| Priority | Gap | System |
|---|---|---|
| P0 | Brief→plan OS (G1) | Creative Director + Workflow |
| P0 | Continuity engine (G2) | Scene & Continuity |
| P0 | Shot planner as data (G5) | Storyboard & Shot Planner |
| P1 | Cost governance + router (G7, G8) | Provider Router |
| P1 | Character engine (G3) | Character Intelligence |
| P2 | Cinema honesty layer (G4) | Cinema Intelligence |
| P2 | Brand intelligence (G6) | Brand Engine |
| P2 | Asset/provenance library (G9) | Shared model |
