# Competitive Benchmark

**Research date:** 2026-11-09 · Confidence key: V = Verified · PV = Partially verified · H = Hypothesis

## 0. Market context (2026)

- **OpenAI shut down the Sora app in April 2026** (reported by CloudZero, 2026-10-21, and aitoolradar; V as reported). The commercial AI video market consolidated around Kling, Google Veo 3.1, Runway, ByteDance Seedance 2.x, with xAI Grok Imagine in social.
- A second tier of **aggregator/studio platforms** (Higgsfield, Krea, Luma, Pika, Morphic) resells access to the same frontier models under one subscription, differentiating on workflow rather than model ownership.
- A third tier of **pre-production tools** (LTX Studio, Katalist, Boords, Storyflow, Studiovity, ScreenWeaver, Frameliq) handles script→storyboard→shot planning, mostly disconnected from frontier generation.
- **MCP surfaces are becoming table stakes**: Higgsfield MCP and Runway MCP both exist; both spend credits at standard rates.

## 1. Runway

**Position:** professional creative suite + API; strong editing heritage; now agentic ("Agentic creative collaborator"), ads workflow (Runway Ads), App Studio.

| Fact | Detail | Conf. |
|---|---|---|
| Flagship model | Gen-4.5 (text/image-to-video; 12 credits/sec in app; API $0.12/sec); Gen-4 Turbo ($0.05/sec API); Aleph 2.0 video-to-video editing ($0.28/sec API) | V (Runway pricing, API docs, memU) |
| Leaderboard | Gen-4.5 led Artificial Analysis at launch (1,247 Elo); by Oct 2026 Wan 3.0 led; Gen-4.5 out of top 10 | V (memU citing Artificial Analysis) |
| Multi-model | App and API also carry Veo 3.1, Kling 4.0, Seedance 2.5, Nano Banana Pro, third parties | V (runway.com/pricing) |
| Plans | Free 125 one-time credits; Standard $15 ($12 annual, 625cr); Pro $35 ($28, 2,250cr, 1 Brand Kit, 1 voice clone, MCP); Max $95 ($76, 9,500cr, 1-mo rollover, 3 Brand Kits, ProRes/HDR/image-sequence export) | V (runway.com/pricing) |
| Consistency | "Gen-4.5 does not remember earlier generations" — reference frames + fixed prompt templates; Brand Kits inside Runway Agent | V (memU) |
| Team | Team plan $69/seat (2–9), shared pool 6,900cr/seat, shared projects, frame-specific comments, Brand Kits, shared agent skills | V (Higgsfield team comparison, checked 2026-11-04) |
| Extras | Act-Two performance capture (5cr/sec), 4K upscaling (unlimited on Pro+), Topaz upscale | V |

**Takeaway:** Runway is the "editor's suite" — strong post/edit, pro exports (ProRes, HDR), but no persistent characters, no storyboard system, no continuity engine.

## 2. Kling (Kuaishou)

**Position:** model vendor with the cheapest commercial entry and the most generous free tier; production features growing (Elements, multi-shot, native audio, voice binding).

| Fact | Detail | Conf. |
|---|---|---|
| Models | Video 3.0 / 3.0 Omni (Feb 2026), Image 3.0/Omni; O1 Pro API variants; 4.0 exists (Runway sells it at 25% off until Nov 30) | V (AtlasCloud, Runway pricing) |
| Credit rates (official guide) | Video 3.0: 12cr/s 1080p w/ audio, 8cr/s without; 9/6cr/s at 720p; Voice Control +2cr/s; 4K native 30cr/s (per Kling credit guide) | V |
| Consistency | "Element Consistency Control", dual binding of visual identity + vocal tone; Elements (characters/voice-bound assets); improved character coherence but "not perfect" in independent tests | V/PV (official guide; AtlasCloud test) |
| Controls | **Motion Brush** (draw motion paths on frames — no direct equivalent in other majors); multi-shot storyboard controls; 3–15s durations; 720p/1080p/4K; 9:16/1:1/16:9 | V |
| Text rendering | ~8/10 generations keep product text/logos legible (independent test) — e-commerce strength | PV (AtlasCloud) |
| Free tier | 66 daily credits (24h expiry), 720p watermarked, no commercial use, single queue, peak waits 30–47 min | V |
| Plans | Standard $10 list ($8.80 renewal, 660cr), Pro $37 ($32.56, 3,000cr), Premier $92 ($80.96, 8,000cr), Ultra $180 ($159.99, 26,000cr); annual −34%; Element creation quotas 30/50/150/150/500 | V (Kling credit guide, CloudZero) |
| API | Separate prepaid packages $9.80–$7,560; V3-Omni 5s 1080p w/ sound ≈ $0.70; failed gens not billed; resellers from ~$0.075/s | V (CloudZero) |
| Team | Team $122/seat, 10,000cr/seat, admin allocation, Team Workspace | V (Higgsfield comparison) |

**Takeaway:** Kling is a *model* with production aspirations. Motion Brush and voice-bound Elements are genuinely innovative controls. But no brief/plan layer, no cross-model routing, and credit friction (expiry, failed-gen billing on app, price hikes ~40% in 2026).

## 3. Luma Dream Machine

**Position:** own Ray model family + partner models on one meter; agentic board (Luma Agents); pro finishing (HDR/EXR).

| Fact | Detail | Conf. |
|---|---|---|
| Models | Ray3.14 (cheap/fast; 1080p native, 4× faster than Ray3) and Ray3.2 (May 2026; HDR, EXR export, multi-keyframe, reframe, extend); partners: Veo 3.1, Kling 3.0/4.0, Seedance 2.0/2.5, MiniMax H3 | V (screenweaver, aitoolradar) |
| Rates | Ray3.14: 20cr/s 720p, 80cr/s 1080p; Ray3.2: 100cr/5s 720p, 400cr/5s 1080p (10s = 1,200cr); HDR 2×, HDR+EXR 3×; video-to-video 36–144cr/s; reframe 10–120cr/s; upscale 4K 25cr/s | V (pixara citing rate card) |
| Modify Video | Video-to-video with keyframe control + character reference — "workflow no other platform implements as completely" | V (aitoolradar) |
| Consistency | Master Reference Assets keep characters/products/logos stable across variations; but "generating the same scene twice rarely produces identical results" — consistency is the primary weakness | V (screenweaver, aitoolradar) |
| Agents | Luma Agents brainstorm, pick models, generate in parallel on an infinite board; boards hold characters/story arcs/episodes; **no screenplay editor, no script import** | V (screenweaver) |
| Plans | No free plan on pricing page (trial credits on signup); Plus $30/10,000cr; Pro $90/40,000cr; Ultra $300/150,000cr; annual −20%; Team/Enterprise custom (SSO, shared credits); iOS Lite tier $9.99 | V |
| API | Separate billing; Ray3.2 $0.15–$1.20 per 5s SDR by resolution; failed gens refunded; no watermark, commercial OK | V (renderahouse) |

**Takeaway:** Luma = quality + finishing + speed, weakest on consistency and narrative structure. Explicitly "a weaker buy for a film… nothing on the board holds a screenplay."

## 4. Pika

**Position:** relaunched Sept 2026 as an aggregator creative platform ("video, image and sound, 25+ creative apps"); cheapest commercial entry.

| Fact | Detail | Conf. |
|---|---|---|
| Models | Own Pika 2.5 + Seedance 2.5, MiniMax H3, Wan 3.0, Gemini Omni 1.1 Flash; images: GPT Image 2.5, Nano Banana 2.1, Seedream 5 | V (eesel) |
| Signature tools | Pikaframes, Pikascenes, Pikadditions, Pikaswaps, Pikatwists, Pikaffects — effect/transformation apps; Pikaformance up to 30s | V |
| Plans | Basic free 80cr/mo (480p only, no watermark, commercial use listed); Standard $10/700cr; Pro $35/2,300cr; Fancy $95/6,000cr; annual −20–25% | V (therundown, aitrainingjobs) |
| Rates | Pika 2.5: 12cr/5s 480p, 20cr/5s 720p, 40cr/5s 1080p; Seedance 2.5 720p 5s = 122cr; API from ~$0.04/s (720p Pika 2.5) | V |
| Depth | No storyboard, no continuity system, no character training; community reports high dud rates | V/PV |

**Takeaway:** Pika is consumer/social-first effects plus aggregation. Not a production tool; relevant as a pricing/UX reference and an API provider candidate.

## 5. LTX Studio (Lightricks)

**Position:** the closest thing to "AI filmmaking platform": script/concept → storyboard → generation → timeline edit.

| Fact | Detail | Conf. |
|---|---|---|
| Pipeline | Gen Space (T2V/I2V/V2V, keyframes, camera movement, style presets), **Dynamic Storyboard** from script/prompt/image/clip, timeline editor with sound design, pitch decks | V (vidmuse) |
| Elements | Save/reuse consistent characters, objects, locations across scenes — "genuine differentiator" | V |
| Models | LTX-2.5 own on all plans; Kling/Seedance from Standard; Veo on Pro; FLUX.2 Pro, Nano Banana 2, ChatGPT Images 2.0 | V |
| Plans | Free 800 one-time credits (personal use); Lite $15/8,000cr; Standard $35/28,000cr (commercial, AI Storyboards, Pitch Decks, Elements); Pro $125/110,000cr (3 collaborators); Enterprise custom | V (checked 2026-10-14) |
| Limits | Credit-heavy partner model generation; desktop-only; no deep continuity state beyond Elements | V/PV |

**Takeaway:** LTX validates the market for script→board→video, but its planning artefacts are thin (no per-shot structured data model exposed, no continuity rules, no brand system) and generation depends on credits with the same retry economics.

## 6. Pre-production / storyboard layer (secondary competitors)

| Tool | Essence | Pricing (2026) | Conf. |
|---|---|---|---|
| **Katalist** | Script→storyboard with locked character models, camera-angle controls, generative fill, FDX/Celtx/Docs import; video studio w/ voiceover+lip-sync (presentation-grade) | from ~$29/mo; free trial | V (StudioBinder, frameliq) |
| **Boords** | Team review: frame-level client comments/approvals, animatics, saved cast, version history, PDF export; board is the final product (no video gen) | free (5 boards); $26/mo annual | V (storyflow blog) |
| **Storyflow** | Agency script→storyboard/shot list/call sheet on one board; no animatic, no saved cast, no video | $7.99/mo annual (Plus) | V |
| **Studiovity** | Storyboards connected to real production: breakdowns, schedules, budgets, call sheets, cast/crew | n/a (freemium) | PV |
| **ScreenWeaver** | Script-first: real screenwriting editor (PDF/FDX export) → shot breakdown → storyboard → video (Seedance 2.0/2.5) | free writing; Auteur $39.99/mo | V (screenweaver) |
| **Morphic** | Connected canvas; script-to-frames + video in one workspace; character sheets + set references per place | Basic $19/mo, 2,400cr | V (morphic.com) |
| **Frameliq** | Story engine: logline→characters→environments→up to 120 timed beats→multi-model video (Kling/Veo/Sora + BYOK), lip-sync, EDL export | from $19/mo | V (frameliq) |

**Takeaway:** the planning layer exists but is fragmented: review tools without generation (Boords), generation tools without production management (LTX/Morphic), production management without frontier generation (Studiovity). **Nobody unifies brief → structured plan → continuity-governed generation → selective regeneration → brand compliance → cost governance.**

## 7. Capability snapshot across primary competitors

| Capability | Higgsfield | Runway | Kling | Luma | Pika | LTX Studio |
|---|---|---|---|---|---|---|
| Multi-model aggregation | 30–35+ | Yes (own + partners) | Own only | Own + partners | Own + partners | Own + partners |
| Trained character identity | Soul ID | ✗ (refs only) | Elements (voice-bound) | Master Reference Assets | ✗ | Elements |
| Camera/movement controls | Presets + Cinema Studio | Motion tools | **Motion Brush** | Keyframes | Effects apps | Camera controls + keyframes |
| Multi-shot in one generation | 6 shots/12s | ✗ | Multi-shot controls | ✗ | ✗ | Storyboard-driven |
| Script/screenplay editor | ✗ | ✗ | ✗ | ✗ | ✗ | AI script gen (txt import only) |
| Storyboard entity | ✗ (shot drafts only) | ✗ | Partial | ✗ | ✗ | **Dynamic Storyboard** |
| Scene continuity system | Techniques only | ✗ | Elements only | Refs only | ✗ | Elements only |
| Brand kit/intelligence | Brand Kit from URL | Brand Kits | ✗ | ✗ | ✗ | ✗ |
| Agentic orchestration | Supercomputer | Runway Agent | ✗ | Luma Agents | ✗ | Flows |
| Node canvas | Canvas | ✗ | ✗ | Board | ✗ | ✗ |
| MCP / API | MCP+CLI+API | MCP+API | API | API | API | ✗/PV |
| Team pooling/SSO | Team/Scale | Team | Team | Team/Ent | ✗ | Pro/Ent |
| Entry price (commercial) | $19 | $12–15 | $8.80 | $30 | $8–10 | $35 |

## 8. Sources

Runway: runway.com/pricing, docs.dev.runwayml.com, memU.pro (2025-12-01), eesel (2026-01-06), therundown (2026-08-28). Kling: kling.ai credit guide (2026-07-28), CloudZero (2026-10-21), AtlasCloud review (2026-08-17), kingy.ai (2026-05-08), magichour (2026-02-12), invideo (2026-02-25). Luma: kingy.ai (2026-10-22), pixara (2026-10-28), renderahouse (2026-10-27), screenweaver (2026-10-27), aitoolradar (2026-09-23), techpresso (2026-10-13). Pika: eesel (2026-10-27), lumalabs.ai/news (2026-09-15), therundown (2026-08-31), aitrainingjobs (2026-08-19), Medium/trelvek (2026-06-08). LTX: vidmuse (2026-05-26), therundown (2026-08-28), screenweaver, youart (2026-10-27). Storyboard layer: studiobinder (2026-02-05), morphic.com (2026-08-18), storyflow.so (2026-06-11), studiovity, frameliq (2026-07-04), aicraftkit (2026-04-23).
