# Higgsfield Product Map

**Research date:** 2026-11-09 · **Analyst:** Kimi (build environment)
**Confidence key:** V = Verified (official docs/blog/pricing, direct fetch) · PV = Partially verified · H = Hypothesis

---

## 1. Positioning

Higgsfield positions itself as an **"AI-native creative suite"** (homepage title, direct fetch 2026-11-09, V): a single credit-metered platform aggregating 30–35+ frontier third-party models for image, video and audio, plus a growing layer of proprietary tools (Soul ID, Cinema Studio, Canvas, Supercomputer) and marketing/ads workflows.

It is **generation-first**: the core object is the generation (image/clip), wrapped in credits, presets and, increasingly, agentic orchestration. It is not, at heart, a pre-production planning system — planning features (Project Brief, AI Director, storyboard-like multi-shot) exist inside generation surfaces rather than as a standalone production plan the user controls end to end.

Public traction signals: a Higgsfield Global Film Festival with winners showcased on the homepage (V), and community features (public projects with view/like counts, "see all prompts and assets behind each project" — homepage fetch, V).

## 2. Product surfaces

| Surface | What it is | Evidence |
|---|---|---|
| **Web app** (higgsfield.ai) | Main generation UI; the only surface where "Unlimited" model windows apply | V (official blog, help center) |
| **Canvas** | Node-based infinite board: every model is a node; prompt→image→video→edit chains; real-time multi-user ("like Figma"); templates; comments attached to nodes; building is free, credits only on generate | V (higgsfield.ai/canvas-intro, enterprise help center) |
| **Supercomputer** | Agentic chat workspace: plans tasks, picks models (Orchestrator), runs Skills (installable workflows, slash commands, versioned, marketplace), Connectors (Slack, Drive, Notion, Gmail, Figma, 30+), scheduled tasks, Projects (persistent context/memory), "AI employees"; free text chat, credits per generation step with running cost shown | V (higgsfield.ai/supercomputer-intro, "How we built Supercomputer" blog) |
| **Cinema Studio 4.0** | Cinematic generation workspace: AI Cast, Cinematic Locations, multi-shot (up to 6 shots / 12s total / 1080p), emotion control per character, Start & End Frame logic, Forward/Backward Extend (up to 30s), Project Brief read by AI Director, Personal Assistant that breaks a script into shots with camera params pre-filled, Element sharing, live multi-user generation, multi-model support (incl. Seedance 2.5) | V (official blog cinema-studio-4-0, cinema-studio-guide) |
| **Marketing Studio** | Image/video ad generation; Product/Avatar references; Product Link route; Ad Reference (recreate an existing ad's structure with your product); **Brand Kit** ("pulls brand details from your site"); DTC Ads (static ads) | V (enterprise help center) |
| **Ads Studio** | Paste your website → imports brand and products, finds selling angles, writes copy, generates batches by SKU/angle/design; brand and products stay saved | V (enterprise help center) |
| **Ad Multiplier** | Upload a 4–30s ad, describe swaps (person, outfit, location, objects, product); runs on Seedance 2.5; keeps cut/timing/framing/original audio; can remove burned-in captions; usable via Supercomputer or Claude through MCP | V (enterprise help center) |
| **Shorts Studio** | Make or remake trending shorts with your character/voice/style; preset gallery with public view counts | V (homepage fetch) |
| **Genjutsu** | Video editing: Object Swap (fix a drifted face/element in a finished clip using reference photos), Motion Transfer (reuse movement, rebuild scene), Restyle (20+ animation styles); source 4–30s, up to 30 reference photos, 480p–1080p, 30+ presets | V (official blog keep-ai-character-consistent) |
| **MCP server** | `mcp.higgsfield.ai/mcp` — live and auth-gated (401 probed by third party); clients listed: Claude, Claude Code, ChatGPT, Cursor, OpenClaw, Hermes; spends plan credits at standard rates; Unlimited does NOT apply | V (Blotato probe + official blog) |
| **CLI** | Generation from terminal; spends credits | V (official blog) |
| **API** | Separate prepaid USD balance ($5 min top-up), per-successful-generation pricing, video per-second | V (Blotato, official) |

## 3. Model catalog (as of Oct–Nov 2026)

- **Video:** Seedance 2.0 / 2.5, Kling 3.0, Veo 3.1, Wan 2.6 / 2.7, Cinema Studio (own), plus "30+ frontier models" total (V — official pricing blog).
- **Image:** Soul 2.0 and Soul Cinema (own), Nano Banana 2 / Pro, GPT Image 2.0 (V).
- **Audio/voice:** ElevenLabs v4, Seed Audio 1.0, voice cloning, Lipsync Studio, Higgsfield Speak (V — team-plans blog).
- **LLMs inside Supercomputer:** "GPT 6 Astra, Claude Fable 5.1, Claude Opus 5.5, Gemini 4 Argon, Grok 4.7 and more" (V — supercomputer-intro page; model names as marketed).

## 4. Proprietary systems (their differentiation layer)

### 4.1 Soul ID — trained character identity (V)
- Train once from reference photos: **20+ recommended, up to 80 accepted, ≥960px**, training 3–5 min, costs **25 credits (~$1.25)**; runs on Soul 2.0 / Soul Cinema Preview on any paid plan.
- Stores an internalised identity (claimed: "learns the face itself", not single-image matching) reusable across generations via `@character` mentions; appears automatically in Elements.
- 20–50+ style presets (editorial, Y2K, retro…).
- **Documented limitations (their own blog):** garbage-in-garbage-out; "consistency is high, not absolute" — extreme style shifts/angles cause drift; likeness tracks input photos; identity is platform-locked (not exportable as a model file).
- Character generation quotas per plan: Free 1, Starter 6, Plus 33, Ultra 100 per month (V — pricing blog).

### 4.2 Elements (V)
Reusable characters, locations and props referenced with `@` in prompts; shared across shots; pullable from other projects; created manually or automatically from Soul ID. Born from Seedance 2.0's reference capability (V — "How we built Supercomputer").

### 4.3 Cinema Studio camera language (V)
Named camera controls (dolly, orbit, tracking, crane, whip pan, static hold, push-in…) executed "at generation time across every model on Higgsfield". Multi-shot manual mode: per-shot duration, camera movement, slow motion and speed ramp. Up to 3 characters per scene with assigned emotional states; auto-generated speech unless dialogue is explicit.
- Reference counts: Cinema Studio 3.0 up to 9 references, 4.0 up to 50 (V — official blog).

### 4.4 Continuity techniques they publicly teach (V)
1. `@character` reference per generation (anchors within one clip).
2. Elements for cross-clip reuse.
3. Image-to-video from a Soul portrait as start frame ("the image carries the face").
4. Identical character description block in every prompt; in Cinema Studio this block lives in the **Project Brief** read by the AI Director.
5. Last-frame→first-frame chaining (with the caveat "small errors accumulate over long chains — chain 2–3 clips, then start a new chain from a fresh Soul portrait").
6. Post-hoc repair with Genjutsu Object Swap.

**Key observation:** these are *techniques and presets*, not a scene-state system. There is no evidence of structured per-scene state (wardrobe/props/screen direction/time-of-day) with automatic conflict detection. Continuity is the user's responsibility, assisted by references. (PV — based on absence in all official material reviewed.)

### 4.5 Supercomputer orchestration (V)
- **Orchestrator** picks best-fit model per step; user can override.
- **Memory**: "Brief once. It remembers the rest." Project-level persistence of chats, outputs, instructions, skills, connectors, references.
- **Skills**: installable, versioned workflow packages with a marketplace.
- Free Mode: text/reasoning steps cost zero credits; generation steps cost standard rates with running cost displayed and user approval before spend.
- Built in ~6 weeks (their account); runs inside Cinema Studio and Canvas; evaluated with internal evals after major updates.

## 5. Pricing and credit mechanics (verified Oct–Nov 2026)

| Plan | Monthly | Annual/mo | Credits/mo | Notes |
|---|---|---|---|---|
| Free | $0 | — | 0 (interface evaluation; some models free) | No commercial use; 1 parallel job |
| Starter | $19 | $19 | 270 | Seedance Fast/Mini only; no Start&End Frame, Speak, UGC builder |
| Plus | $59 | $47 | 1,200 | Full model lineup; Start & End Frame, Speak, UGC builder |
| Ultra | $129 | $99 | 3,000 (slider to 6k/9k) | Max concurrency (8 video jobs) |
| Team | $79/seat | — | 1,000/seat pooled | 2–9 seats; 16 parallel video jobs |
| Scale | $215/seat | — | 2,500/seat pooled | 5–15 seats; SSO; admin can pause member spend |
| Enterprise | custom | — | custom | SOC 2 support |

(Conflict note: a Higgsfield blog dated 2026-10-24 lists Starter $15/200cr; two independent sources verified live on 2026-10-30 show $19/270cr. Recorded as PV; re-check pricing page before any commercial decision.)

**Mechanics (V):**
- Credits are per model/resolution/duration. Examples: Kling 3.0 ~10cr for 8s 1080p (~$1.00 at $49/1,000); Seedance 2.5 8s 1080p = 72cr (~$3.60); Seedance 2.0 45cr/5s/1080p; Cinema Studio 25cr/5s/720p; Wan 2.7 8cr; Nano Banana Pro ~2cr/image (4cr at 4K).
- Subscription credits **do not roll over**; packs/auto-refill expire after 90 days; spend order: subscription first, then nearest-expiry.
- **Unlimited:** 365-day set (six image models) on Plus/Ultra + rotating 7-day windows on flagship models (e.g., Kling 3.0, Nano Banana 2/Pro); Marketplace sells 1/3/7-day passes ($7–$1,035). Unlimited applies **only on the web app** — MCP/CLI/Canvas/Supercomputer always spend credits.
- Failed generations usually auto-refund.
- Effective cost per finished video quoted at **$0.50–$1.27** depending on plan utilisation (Blotato, V).

## 6. Strengths (from evidence)

1. Widest single-balance model access (30–35+ models, one credit pool).
2. Soul ID: setup-free trained identity — deeper than per-generation reference matching.
3. Camera language as first-class presets, executed across models.
4. Aggressive agentic push (Supercomputer: memory, skills, connectors, scheduling) and MCP surface for external agents.
5. Team features: pooled credits, parallel limits, SSO, spend pause.
6. Marketing/ads verticalisation (Ads Studio, Ad Multiplier, Brand Kit from URL).

## 7. Weaknesses / open flanks (evidence-based)

1. **No structured continuity system.** Continuity = references + chaining techniques; drift repair is post-hoc (Genjutsu). No scene-state model, no automatic conflict detection, no screen-direction/wardrobe/prop tracking. (PV)
2. **No screenplay/script editor and no storyboard entity.** Multi-shot caps at 6 shots/12s inside Cinema Studio; there is no project-long storyboard with per-shot structured data the user owns. Personal Assistant drafts shots, but the artefact is generations, not an editable production plan. (PV)
3. **Credit opacity and expiry pressure.** No rollover; 90-day pack expiry; per-model rates that change; Unlimited restricted to web surface — recurring user complaint themes. (V)
4. **Generation-first, not planning-first.** Cost estimation appears only per-generation-step in Supercomputer; no pre-production cost plan for a whole project before spend. (PV)
5. **Brand intelligence is shallow.** Brand Kit "pulls brand details from your site"; no evidence of brand-rule storage, compliance evaluation, or messaging rules enforced on outputs. (PV)
6. **Identity is platform-locked.** Soul ID can't be exported; character quotas per plan limit cast size. (V)
7. **Model routing is a black box.** Orchestrator picks models; no user-visible capability registry, cost comparison, or routing policy control. (PV)
8. **Short clips.** Flagship models top out at 5–15s; long-form requires chaining with acknowledged error accumulation. (V)

## 8. Implications for our platform (preview — full analysis in `04-Competitive-Gap-Analysis.md`)

The clearest daylight: Higgsfield optimised **generation UX and agentic convenience**, leaving **production structure** (brief→plan→storyboard→continuity→selective regeneration→brand compliance→cost governance) underserved. Our seven systems attack exactly that layer.

## 9. Sources

- higgsfield.ai homepage (direct fetch, 2026-11-09)
- higgsfield.ai blog: pricing-explained (2026-10-24), team-plans-compared (2026-11-04), credits-vs-unlimited (2026-09-15), ai-video-cost-2026 (2026-10-29), keep-ai-character-consistent (2026-06-29), Soul-ID consistency (2026-06-15), cinema-studio-guide (2026-02-17), cinema-studio-4-0 (2026-08-12), how-we-built-supercomputer (2026-09-16)
- higgsfield.ai/soul-cinema, /canvas-intro, /supercomputer-intro (2026-10-03), enterprise help center tools-creative-workflow (2026-11-01)
- Third-party verifications: Krea blog (captured 2026-08-31), Blotato (live-verified 2026-10-30), CropUp prompting guide (2026-07-25), YouTube tutorials (Soul ID workflow, Apr–May 2026)
