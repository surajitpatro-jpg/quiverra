# Architecture Decisions (ADR Log)

Every significant technical decision is recorded here with context and trade-offs.

| ID | Date | Decision | Status |
|---|---|---|---|
| ADR-0001 | 2026-11-09 | Workspace at `/mnt/agents/output/creative-platform/` is the source of truth; user mirrors to GitHub (git push unavailable in build environment) | Accepted |
| ADR-0002 | 2026-11-09 | REA used in CLI-only mode with per-session Node ≥22.23.4 bootstrap; MCP registration not possible in this environment | Accepted |
| ADR-0003 | 2026-11-09 | Website research combines REA CLI (where it adds evidence) with Playwright/Chromium and official-doc fetching | Accepted |
| ADR-0004 | 2026-11-09 | Creative planning is a staged artefact pipeline (interpretation→concepts→plan), not a chat; chat is only a UI layer over versioned artefacts | Accepted |
| ADR-0005 | 2026-11-09 | Cost estimation is deterministic code over the Model Capability Registry (never LLM-estimated), versioned and reproducible | Accepted |
| ADR-0006 | 2026-11-09 | Continuity uses two unblurred layers: deterministic rules (structural, explainable) + confidence-scored VLM evaluation (perceptual, advisory); a VLM result never mutates state on its own | Accepted |
| ADR-0007 | 2026-11-09 | The Shot record is the single source of truth; all views/exports/generation jobs derive from it; generation jobs run on frozen input snapshots | Accepted |
| ADR-0008 | 2026-11-09 | Workflows are compiled from the production plan as dependency DAGs (build artefact), never user-drawn node graphs; tasks are idempotent with content-hash inputs; run state is an event log | Accepted |
| ADR-0009 | 2026-11-09 | Platform knowledge is data, not code: continuity rules, cinematography vocabulary, control classifications and brand rules are versioned records compiled into prompts/instructions at run time | Accepted |

---

## ADR-0004 — Planning as artefact pipeline

**Context.** All agentic competitors (Higgsfield Supercomputer, Runway Agent, Luma Agents) plan in chat; the plan evaporates into generations. Gap 1 shows no competitor offers an editable, costed production plan.
**Decision.** The Creative Director Engine is a staged state machine producing versioned, approvable artefacts; chat interfaces may drive it but are never the store of record.
**Consequences.** Enables approval gates, impact analysis, decision provenance and cross-project reuse; costs more upfront engineering than a chat wrapper.

## ADR-0005 — Deterministic costing

**Context.** Users distrust credit systems (Gap 7: no rollover, silent exclusions, changing rates). An LLM-estimated cost would be unaccountable.
**Decision.** Estimates are computed by code from registry rates (`credits × duration × resolution`), stamped with the registry version; LLMs may only *explain* trade-offs.
**Consequences.** Estimates are reproducible, auditable and testable; requires the registry to be maintained (that's the moat).

## ADR-0006 — Two-layer continuity detection

**Context.** Structural conflicts (wardrobe changes, prop disappearance, screen direction) are deterministic given state; perceptual checks (does this render match the reference?) are probabilistic.
**Decision.** Keep them separate: rules engine with data-defined rules for structure; VLM evaluation with per-check confidence for perception. VLM output is advisory and cannot mutate state without user/rule confirmation.
**Consequences.** Explainable reports, honest confidence display, testable core; requires per-check VLM calls to stay cheap (routing policy).

## ADR-0007 — Shot as single source of truth

**Context.** Storyboard views (board/table/timeline), exports and generation can desynchronise if each keeps its own state — the classic failure of board tools.
**Decision.** One Shot record; all views are projections; generation jobs receive frozen input snapshots so mid-flight edits can't corrupt running jobs.
**Consequences.** Strong consistency guarantees; structural edits must emit events for contract re-derivation (loose coupling with the Continuity Engine).

## ADR-0001 — Source of truth location

**Context.** The brief requires GitHub as the permanent source of truth. The build environment blocks `git clone`/`git ls-remote`/push to github.com (verified 2026-11-09); no user git credentials exist in the environment.

**Decision.** Treat `/mnt/agents/output/creative-platform/` (persistent, user-visible) as the working source of truth, structured exactly like the target repository. The user mirrors it to GitHub at phase boundaries. **Update 2026-11-09:** the user created the GitHub repository **`platformai`**. **Update 2026-11-10:** superseded — the permanent home is **`quiverra`** at `https://github.com/surajitpatro-jpg/quiverra.git`; mirroring procedure is in the README.

**Consequences.** No commit history inside the environment; milestone history is recorded in `Research-Progress.md` and `Implementation-Progress.md` instead. Repository mirroring is a manual step owned by the user.

## ADR-0002 — REA integration mode

**Context.** REA's `npx rea-agents setup` registers MCP servers for Claude Code, Codex, Cursor, Gemini CLI, Grok Build etc. Kimi web is not a supported MCP host. REA 6.8.0 requires Node ≥22.23.4; the environment defaults to Node 20.20.2.

**Decision.** Use REA strictly through its CLI (`analyze-web-bundle`, `capture-web-screenshot`, `capture-browser-scenario`, `export-web-scripts`) after bootstrapping Node ≥22.23.4 into the session. Never claim REA MCP integration exists here.

**Consequences.** REA invocation costs ~1–3 minutes of bootstrap per session. Website analysis remains fully viable.

## ADR-0003 — Research tooling mix

**Context.** REA CLI works but is heavyweight for simple documentation lookups.

**Decision.** Tiered research tooling: official docs/pricing via web fetch first; REA CLI for structural evidence on public product pages; Playwright for rendered inspection and screenshots; codeload tarballs for OSS repos.

**Consequences.** Faster research cycles; every tool's outputs land in `Evidence-Index.md` regardless of which tool produced them.

## ADR-0008 — Compiled, content-hash-pinned workflow DAGs

**Context.** Visual "drawn" workflows rot: nodes drift from their configuration, re-runs duplicate paid work, and partial regeneration is impossible without a dependency graph.

**Decision.** Workflows are compiled (not drawn) into immutable DAGs, content-hashed at compile time. Tasks carry `idempotency_key = hash(run, node, input)`; completed outputs are reused by content hash, so upstream edits re-run only the affected subgraph.

**Consequences.** Partial regeneration is cheap and safe; run logs are replayable; workflow edits never disturb in-flight runs (they create new versions). Requires the scheduler + task schema in Database-Architecture §2.8 and the execution semantics in Workflow-Execution.md.

## ADR-0009 — Platform knowledge as versioned data

**Context.** Provider pricing, free-tier quotas, model rosters and capability classifications change monthly (Sora API shutdown 2026-09-24; Cloudflare–Replicate acquisition; Google repositioning Veo → Gemini Omni Flash — Evidence F-0022, F-0024). Hardcoding any of it guarantees silent rot.

**Decision.** All such knowledge lives in the Model Capability Registry as versioned rows (`valid_from`/`valid_to`, `evidence_id` tracing to the Evidence Index). Code contains no pricing or capability constants. Cinematography controls carry an honesty classification (`native | prompt_approximated | reference_conditioned | unsupported`) per (control × model), compiled into instructions with an honesty report.

**Consequences.** Provider changes are data updates, not deploys; cost estimates pin a registry snapshot and can declare "priced as of …"; conflicting sources resolve to the conservative value with `confidence: PV` (F-0017, F-0023). Maintenance cost: a weekly re-verification loop.

## ADR-0010 — Drizzle as the data layer

**Context.** The stack needs an ORM/migration tool for Supabase Postgres. Options: Prisma (heavier runtime, generated client), Drizzle (SQL-first, lightweight, migration files as SQL), raw SQL (no type safety).

**Decision.** Drizzle: forward-only numbered migrations, parameterised queries only (string-built SQL is a review blocker — Security §5), schema definitions co-located with the modular monolith's domain modules.

**Consequences.** Type-safe queries without a generator step; migrations reviewable as plain SQL; expand-contract discipline for destructive changes. Immutability rules (version tables, ledger) are enforced by DB privileges/triggers, not the ORM.

## ADR-0011 — Modular monolith with queue-isolated workers

**Context.** Microservices would add distributed-systems failure modes the MVP doesn't need; a single process can't isolate long provider-bound generation calls from interactive API traffic.

**Decision.** One deployable API (gateway + seven engines + scheduler) as a modular monolith; provider I/O pushed to two BullMQ worker pools (`q.intel` for LLM/VLM tasks, `q.gen` for media generation) consuming from Redis. Workers are stateless; all state in Postgres.

**Consequences.** Independent scaling of intelligence vs generation throughput; worker crashes lose nothing (idempotent re-queue); the scheduler remains single-writer, avoiding distributed locks in Phase 6. A service splits off only when a measured scaling or team-boundary fact forces it.

## ADR-0012 — Double-entry credit ledger

**Context.** The v1 ledger sketch (append-only entries + holds + derived balance) was called out in review: it lacked proper transactions, balanced debit/credit postings, and a chart of accounts — "conceptual, not production-ready". Money correctness is a launch gate; an ad-hoc ledger cannot reconcile provider costs against user consumption or survive audit.

**Decision.** Proper double-entry bookkeeping (Credit-Ledger.md): every value movement is a `ledger_transactions` row with ≥2 `ledger_postings`; `SUM(debit)=SUM(credit)` within one currency domain enforced by a deferred constraint trigger; two domains (`CREDIT`, `USD_MICRO`) linked by `link_group`; chart of accounts with per-workspace `asset:credits_available/reserved:ws_*` and system accounts; reservations move value available→reserved (never deduct), so server-error failures are non-events; all writes through a single `SECURITY DEFINER` recipe-validated function; balances are derived views, never stored; nightly reconciliation asserts the liability = available + reserved invariant.

**Consequences.** Double-charge and balance drift are impossible by construction (idempotency keys + one write door + RLS deny-all); provider-cost vs revenue margin is a SQL query; the design costs one disciplined schema and a test suite (property/replay/recovery tests in CI). Estimates remain outside the ledger.

## ADR-0013 — Workspace-scoped asset storage, no cross-tenant dedup

**Context.** The v1 design implied global content-hash deduplication. In review: cross-workspace dedup creates exposure (shared blobs across tenants), ownership ambiguity, and painful erasure semantics under DPDP/GDPR.

**Decision.** Isolation unit = workspace (Asset-Storage.md). R2 keys are workspace-namespaced (`ws_<id>/…`, enforced by DB CHECK and by the URL-minting service); dedup unique key is `(workspace_id, content_hash, asset_class)` — storage optimisation inside a tenant only; no blob is ever shared between workspaces; presigned URLs are short-lived, single-purpose, prefix-bound; erasure is a prefix delete with provider-side deletion calls recorded.

**Consequences.** Zero cross-tenant exposure surface by construction; erasure is trivial and complete; storage cost rises slightly (duplicate blobs across tenants) — accepted as the price of correctness. ClamAV gating (`quarantined` status) completes the upload path.

## ADR-0014 — Atomic provider quota reservations

**Context.** Concurrent workers racing check-then-submit can jointly exceed provider ceilings (fal 2→40 concurrency, Replicate 600/min, Kling 5–20 tasks, Gemini per-project RPM/RPD, ElevenLabs per-plan×family — F-0036..F-0040). Overspend against free quotas would also violate the user's hard rule (never silently fall through to paid).

**Decision.** Redis Lua reservation tokens (Quota-Reservations.md): acquire is a single atomic script checking concurrency + per-minute + per-day windows against a versioned `quota:meta` limits snapshot; leases with TTL handle worker crashes (sweeper releases); window keys align to provider truth (Gemini RPD resets midnight Pacific); ElevenLabs response headers feed observed limits back; Gemini-style dynamic limits are fetched data, never constants; stale snapshots fail closed (`LIMITS_STALE`); free-tier exhaustion returns `FREE_EXHAUSTED` and parks the job — there is no code path to silent paid fallback.

**Consequences.** Provider-limit violations become structurally impossible at the platform level; fail-closed behaviour on Redis loss (jobs park, never overspend); quota events are audited in Postgres. Cost: one carefully tested Lua script and a limits-refresh job.

## ADR-0015 — OpenAPI as the API contract source of truth

**Context.** The v1 API-Architecture documented conventions and a route map in prose. Review required a formal contract: prose drifts, and both server handlers and the typed frontend client need one authoritative definition.

**Decision.** `docs/03-system-architecture/api/openapi.yaml` (OpenAPI 3.1) is the source of truth for the MVP API surface. Server route handlers are validated against it in CI (contract tests: every route in the spec exists, every response matches its schema); the frontend consumes a generated typed client; breaking changes require a version bump in the spec and a note in the migration log. Prose documents remain for rationale; the YAML governs behaviour.

**Consequences.** Frontend/backend drift is caught in CI, not in production; the spec doubles as living documentation of the honesty contracts (e.g. `CONTROL_UNSUPPORTED` 422s, `FREE_QUOTA_EXHAUSTED` 409s are contractual, not incidental). Cost: spec maintenance discipline on every route change.

## ADR-0016 — MVP scope ratified (gate decision 1)

**Context.** The correction + Phase 5 package was presented for gate review on 2026-11-10. The user approved: "Proceed with the proposed MVP scope and phased roadmap… Keep the architecture extensible for all seven intelligence systems, but do not overcomplicate the initial release."

**Decision.** The first release is the ten-stage pipeline (Brief → Concepts → Visual Direction → Characters → Script → Storyboard → Shot Planning → Image Generation → Video Generation → Asset Management) exactly as scoped in MVP-Scope.md. The architecture remains extensible for all seven engines, but each engine is built only to its MVP surface; the excluded-features list (brand scoring, auto-repair, scheduling, real-time collaboration, trained identity, self-hosted fleet, payments) is binding until a later gate.

**Consequences.** Roadmap W0–W14 and milestones M1–M6 govern implementation. Scope additions mid-build require explicit user approval — the roadmap's discipline clause (§4.4) is now a decision, not a suggestion.

## ADR-0017 — Staged provider onboarding (gate decision 2)

**Context.** The plan proposed adapter work across fal, Replicate, Gemini, Kling direct, Runway Dev and ElevenLabs. The user directed staged onboarding to control cost, accounts overhead and privacy surface.

**Decision.** Initial provider set: **Gemini** (creative intelligence + multimodal), **Groq** (fast, low-cost intelligence), **fal.ai** (image generation and selected media), **Cloudflare R2** (asset storage). **Deferred until the roadmap requires them:** Replicate, ElevenLabs, specialist video routes (Kling direct, Runway Dev). ElevenLabs additionally carries a hard precondition: the data-use opt-out must be applied **and verified** before any project content is submitted, because the setting is prospective only (F-0045). Credentials are server-side only — never in frontend code, public repositories or documentation.

**Consequences.** W5 rescoped: adapters land in order fal (image) → Gemini (LLM/video) → Groq (LLM); Replicate and ElevenLabs adapters enter the plan only when their functionality is required (Replicate for fallback/diversity; ElevenLabs at the voiceover stage, gated on opt-out verification). Registry rows for deferred providers remain seeded with `status: planned` so the router can never route to them. OpenRouter/Cloudflare Workers AI remain documented fallbacks, not build dependencies.

## ADR-0018 — Paid-LLM contingency: ₹0 initial budget (gate decision 3)

**Context.** The plan flagged that free-tier intelligence might prove insufficient for creative quality and asked for a contingency ceiling.

**Decision.** The platform starts **free-only** with an initial paid-LLM budget ceiling of **₹0**. If free models prove insufficient, the team prepares a benchmark comparing quality, latency and cost, and presents findings plus a recommended monthly budget for user approval. **Paid fallback is never activated automatically** — it requires that explicit approval.

**Consequences.** A platform-level config `intelligence_paid_ceiling_inr = 0` disables `paid_authorised` routing for the LLM class regardless of workspace policy; the quota layer's `FREE_EXHAUSTED` path (pause + notify, ADR-0014) is the only exhaustion behaviour for intelligence. The benchmark, if ever triggered, is a deliverable with evidence records, not an ad-hoc opinion.

## ADR-0019 — Commercial parameters deferred; everything configurable (gate decision 4)

**Context.** The gate asked for credit price, pack sizes, 90-day expiry and margin target. The user deferred finalisation: measure first, decide later.

**Decision.** All commercial parameters — credit price, pack sizes, expiry window, margin target, currency display — are **configuration** (`commercial_config` store, admin-editable, versioned), never hardcoded. The ledger already records the USD basis per issuance transaction, so any future pricing is a config change, not a schema change. **Live payments and customer credit purchases remain disabled** until the commercial model, refund rules, expiry policy and applicable legal requirements have been reviewed and approved (Razorpay/Cashfree stay dormant, as before). Until then the platform runs on internally granted development credits.

**Consequences.** Measurement-first operation: from the first staging run, the ledger + usage reports + reconciliation collect actual provider costs, generation failure/retry rates, storage and infrastructure expenses — the evidence base for the eventual pricing decision. No UI surface presents purchasable credits while payments are dormant.

## ADR-0020 — Confidential by default (gate decision 5)

**Context.** The proposed default was confidential-off (opt-in). The user overrode: "I want privacy to be the default." Early users may upload unreleased products, campaigns, brand guidelines and client material.

**Decision.** Confidential mode is **ON by default** for all workspaces. This means: private projects and assets; no public sharing by default; strict workspace-level data isolation (ADR-0013, RLS FORCE policies); **no use of customer content for our own model training**; only approved provider integrations; **clear disclosure to the user before content is sent to any external AI provider**; and per-provider data-use/retention policies enforced through the registry's `data_policy` field. Critically — and per the user's instruction — we **do not imply confidential mode overrides third-party provider policies**: where a provider cannot meet the required conditions, that provider is **restricted** for confidential projects at the router level (hard filter), not merely disclaimed.

**Consequences.** `workspaces.confidential` defaults TRUE; switching it off is a deliberate per-workspace act with a consequences summary. The router's confidential filter is a correctness property with a dedicated test (AC-X.3). A provider-disclosure UX ("this step sends X to provider Y under policy Z") ships in MVP. Practical effect with the staged provider set (ADR-0017): Gemini routes only via a billing-enabled project (paid-tier data terms, F-0044); Groq's data terms must be verified before confidential routing (open question 3.1); fal calls carry `X-Fal-Store-IO: 0` and support payload deletion (F-0042); ElevenLabs is inadmissible until its opt-out is applied and verified (ADR-0017, F-0045).

## ADR-0021 — Data residency: Supabase Mumbai, with honest limits (gate decision 6)

**Context.** The gate asked for a Supabase region decision consistent with the DPDP posture. The user approved Mumbai and required honest documentation: "Do not claim that choosing Mumbai alone guarantees DPDP compliance."

**Decision.** The Supabase project is created in **Mumbai (AWS ap-south-1)**. A **data-residency register** is maintained (Deployment.md §residency) identifying every service and external provider that may process data outside India — including all AI generation providers (whose processing regions are their own), Cloudflare R2's storage location configuration, email delivery, and any observability egress. The register is a living document reviewed whenever a provider is added.

**Consequences.** Residency claims in all copy are precise: primary data at rest in Mumbai; AI provider processing happens wherever those providers operate and is disclosed per ADR-0020's disclosure UX; no document or UI asserts DPDP compliance — only the measures taken. R2 location is pinned at bucket creation to the extent Cloudflare allows; backups to R2 inherit the register entry.
