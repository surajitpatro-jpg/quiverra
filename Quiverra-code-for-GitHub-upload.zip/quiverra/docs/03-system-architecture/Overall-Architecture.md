# Overall Architecture

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Draft for gate review
**Inputs:** Product-Mechanism-Blueprint.md, ADR-0001..0009, system specs (docs/02-proprietary-systems), Evidence F-0017..F-0024

---

## 1. Architectural intent

The platform is a **production-intelligence system that happens to call generation models** — not a generation UI with bookkeeping. This single decision drives everything below:

1. **The artefact pipeline is the product** (ADR-0004). Every creative act produces a persisted, versioned artefact (Brief, Plan, SceneState, Shot, CharacterVersion, CinematographyRecord, BrandProfile, RenderJob). The database is the system of record; the UI and the agents are views and writers over it.
2. **Cost is deterministic and pre-computed** (ADR-0005). No job starts without a CostEstimate produced from the Model Capability Registry at snapshot time. The estimate is a financial commitment the system must be able to honour or refuse — never a surprise after the fact.
3. **Provider reality changes faster than code** (ADR-0009). Provider pricing, free-tier quotas, model rosters, and capability classifications are **versioned data** (registry rows with `valid_from`), not constants. Evidence F-0017..F-0024 documents why: Sora's API disappeared mid-2026, Cloudflare absorbed Replicate, Google repositioned its video default from Veo to Gemini Omni Flash — all within one quarter.
4. **Free capacity and customer money are separate ledgers** (per master brief). Provider free quotas are an operational resource the router may spend; customer credits are a financial liability the ledger must never confuse with them. The router may never silently spend a paid provider when free capacity is exhausted — it pauses and asks, or spends only against explicit user authorisation.

## 2. System context

```
┌───────────────────────────────────────────────────────────────────────────┐
│                              CLIENTS                                       │
│   Next.js web app (React/TS/Tailwind/shadcn, Zustand)  ·  future: API/MCP │
└──────────────┬────────────────────────────────────────────────────────────┘
               │ HTTPS / JSON (REST), WebSocket (job progress)
┌──────────────▼────────────────────────────────────────────────────────────┐
│                         API GATEWAY / BFF (Node + TS)                      │
│   AuthN (Supabase JWT) · AuthZ (workspace roles) · rate limit · validate   │
├───────────────────────────────────────────────────────────────────────────┤
│                         DOMAIN SERVICES (modular monolith)                 │
│                                                                            │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐              │
│  │ Creative        │ │ Scene &         │ │ Storyboard &    │              │
│  │ Director Engine │ │ Continuity Eng. │ │ Shot Planner    │              │
│  └────────┬────────┘ └────────┬────────┘ └────────┬────────┘              │
│  ┌────────┴────────┐ ┌────────┴────────┐ ┌────────┴────────┐              │
│  │ Character       │ │ Cinema          │ │ Brand & Mktg    │              │
│  │ Intelligence    │ │ Intelligence    │ │ Intelligence    │              │
│  └────────┬────────┘ └────────┬────────┘ └────────┬────────┘              │
│  ┌────────┴───────────────────┴───────────────────┴────────┐              │
│  │         Workflow Intelligence Engine (compiled DAGs)     │              │
│  └────────────────────────┬───────────────────────────────┘              │
├───────────────────────────┼───────────────────────────────────────────────┤
│  ┌────────────────────────▼───────────────────────────────┐              │
│  │      ORCHESTRATION LAYER                                │              │
│  │  Multi-Provider AI Router · Model Capability Registry   │              │
│  │  Free-Quota Manager · Credit Ledger · Cost Estimator    │              │
│  └────────────────────────┬───────────────────────────────┘              │
├───────────────────────────┼───────────────────────────────────────────────┤
│  EXECUTION                │  Redis + BullMQ queues · worker pools          │
│  (intelligence workers: LLM calls · generation workers: media providers)   │
└───────────────────────────┼───────────────────────────────────────────────┘
┌──────────────┬────────────▼───────────┬─────────────────┬────────────────┐
│ Supabase     │ Cloudflare R2          │ Provider APIs   │ Payment        │
│ Postgres+Auth│ (artefact/media blobs) │ (see §4)        │ Razorpay/      │
│ + RLS        │                        │                 │ Cashfree       │
└──────────────┴────────────────────────┴─────────────────┴────────────────┘
```

## 3. Component responsibilities

| Component | Responsibility | Does NOT do |
|---|---|---|
| **Web app** | Artefact-centric UI (boards, tables, timelines, inspector); renders state; captures decisions | Business logic, provider calls, key custody |
| **API gateway / BFF** | Auth, validation, workspace scoping, idempotency keys, WS fan-out | Domain rules |
| **Seven intelligence engines** | Their specs (docs/02) — each owns its artefact types and invariants | Direct provider auth; they request *capabilities*, the router picks *providers* |
| **Workflow Intelligence** | Compile workflow definitions → DAG; schedule tasks; enforce gates, budget caps, retries | Execute provider calls itself (delegates to workers via queues) |
| **AI Router** | Capability request → provider/model selection using registry + free-quota state + routing policy | Know about creative semantics (shots, scenes) |
| **Capability Registry** | Versioned rows: provider, model, modality, capability classifications (per ADR-0009), pricing, free-tier terms, data-policy flags, `valid_from`, evidence ID | Store customer data |
| **Free-Quota Manager** | Track consumption vs. published free quotas (Groq per-model, Cloudflare 10K Neurons/day, OpenRouter 50/1000 RPD, Gemini Flash-only) with conservative safety margins | Sell anything |
| **Credit Ledger** | Append-only double-entry ledger of customer credits: purchases, holds, charges, refunds, expiry | Know provider pricing (uses registry snapshot at estimate time) |
| **Workers** | Stateless executors: intelligence tasks (LLM/VLM calls) and generation tasks (media providers); idempotent via content hash (ADR-0008) | Hold state between retries |

## 4. Provider landscape (verified 2026-11-10, Evidence F-0017..F-0024)

| Provider | Role in this platform | Free capacity | Paid model | Notes / risks |
|---|---|---|---|---|
| **Groq** | Primary free-tier LLM for intelligence tasks | All models free, per-model limits | Raised limits | Per-model table changes; registry re-fetches |
| **Cloudflare Workers AI** | Secondary free LLM + Whisper-class STT | 10K Neurons/day | $5/mo + per-Neuron | Daily-reset burst buffer; Replicate merger may expand catalog (F-0022) |
| **OpenRouter** | Overflow free LLM + paid model access | Rotating `:free` roster, 20 RPM, 50→1000 RPD | Credits | Roster rotation ⇒ registry re-resolution; per-model data-policy flags required |
| **Google Gemini** | LLM (Flash free tier, dev/test grade) + Veo 3.1 / Gemini Omni Flash video | Flash-only free tier (F-0017, PV) | Per-token; video per-second | Omni Flash (~$0.10/s) is Google's recommended video default; Veo for extension/last-frame control |
| **fal.ai** | Primary media generation aggregator (image + video + audio) | None (sandbox only) | Prepaid credits, per-output; no charge on 5xx/queue | One key/SDK across Kling, Veo, Wan, Flux, ElevenLabs etc.; pricing API readable from code |
| **Replicate** | Secondary media aggregator | Limited free runs only | Prepaid credits (1-yr validity) | No permanent free tier; failed public runs unbilled, private billed |
| **ElevenLabs** | Voice/TTS | 10k credits/mo, non-commercial | Plans $6–$990 | Free tier unusable for customer deliverables (license) ⇒ router marks it internal-only |
| **Razorpay / Cashfree** | Customer payments (India) | — | Per-transaction | Not activated until billing/legal/refund rules defined (brief constraint) |

**Consequence for the router:** the only substantial *free* capacity is LLM-class (Groq, Cloudflare, OpenRouter, Gemini Flash). Media generation is effectively always paid ⇒ the Free-Quota Manager optimises intelligence costs; the Credit Ledger governs media spend. This asymmetry must be visible in pricing UX.

## 5. Cross-cutting flows

**Flow A — Brief → Plan (P0).** User submits Brief → Creative Director runs staged pipeline (each stage = an intelligence task via router, preferably free-tier) → produces Plan + CostEstimate (deterministic, from registry snapshot) → user authorises spend → Workflow engine compiles DAG → tasks execute.

**Flow B — Generation task.** Shot (frozen job snapshot, ADR-0007) → router selects provider/model against capability requirements + registry honesty classification (ADR-0006: native vs prompt-approximated) → credit hold placed → worker executes → artefact stored in R2 + metadata in Postgres → hold settled to charge or refund on provider-verified failure (fal: 5xx unbilled, F-0021; Replicate public: failed unbilled, F-0022 — ledger mirrors provider semantics).

**Flow C — Free-quota exhaustion.** Router finds no free capacity and no authorised paid route for an intelligence task → task parks in queue with state `awaiting_authorisation`; user notified with options (authorise paid, wait for quota reset — Cloudflare resets daily, F-0019). Never a silent paid switch (brief constraint).

## 6. Quality attributes & tactics

| Attribute | Target | Tactic |
|---|---|---|
| Correctness of money | Zero unaccounted credits | Append-only ledger; holds before execution; nightly reconciliation vs provider usage APIs |
| Cost predictability | Estimate vs actual within declared tolerance | Registry snapshot pinned to job; drift reported per run |
| Provider churn resilience | New provider onboard = data, not deploy | Registry-driven adapters; capability taxonomy stable |
| Debuggability | Every decision replayable | Frozen job snapshots; CreativeDecision graph persisted; task content hashes |
| Latency (intelligence) | P95 stage ≤ 30s | Prefer Groq for speed; cache identical content-hash tasks |
| Latency (generation) | Bounded by provider | Queue position transparency; provider concurrency tracked (fal: 2→40 by history, F-0021) |

## 7. Deployment shape (summary — detail in Deployment.md)

Single Hostinger VPS, Docker Compose: `web` (Next.js), `api` (monolith), `worker-intel`, `worker-gen`, `redis`. Supabase (managed Postgres+Auth) and Cloudflare R2 external. Caddy/Nginx TLS terminator. No Docker in build sandbox ⇒ images are built and tested on the VPS or CI, never asserted as tested from here (Known-Issues KI-02).

## 8. Boundaries & non-goals (Phase 4)

- No provider SDK in the browser, ever; all keys server-side (brief constraint).
- No microservices split now — modular monolith with queue-isolated workers; split only when a scaling or team-boundary fact forces it.
- No live payments in Phase 6 (Razorpay/Cashfree integration is code-complete but disabled pending legal/billing definitions).
- MCP/API surface for external agents is post-MVP (Higgsfield has it, F-0008; we sequence it after the artefact pipeline proves out).

## 9. Open questions for gate review

1. VPS sizing: single 4-vCPU/16GB node acceptable for MVP given queue-isolated workers? (Recommendation: yes; media work is outbound-API-bound, not CPU-bound.)
2. Supabase region (Mumbai vs Singapore) — latency vs data-residency preference for India-first customers.
3. Whether OpenRouter's free-roster data-policy flags meet customer-confidentiality expectations for brand briefs, or whether confidential briefs must be pinned to Groq/Gemini paid with no-training terms. (Recommendation: registry flag `train_on_prompts`, router excludes flagged models from workspaces marked confidential.)
