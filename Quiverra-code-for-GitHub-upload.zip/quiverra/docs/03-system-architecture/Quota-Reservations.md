# Quota Reservations — Atomic Concurrency & Quota Control

**Version:** 2.0 · **Status:** Corrected design · **ADR:** 0014 · **Date:** 2026-11-10
**Correction driver:** user review — "Implement atomic quota reservations to prevent concurrent workers from exceeding provider limits."

---

## 1. Problem

Multiple worker-gen replicas share provider-side ceilings: fal account concurrency (2→40 by purchase history, only IN_PROGRESS counts, F-0036), Replicate 600 predictions/min (F-0037), Kling 5–20 simultaneous tasks by package (F-0038), Gemini per-project RPM/TPM/RPD fetched at runtime (F-0039), ElevenLabs per-plan×model-family concurrency with live headers (F-0040). Two workers checking-then-submitting concurrently can both pass a check whose limit their combined submissions exceed. The check-and-hold must be **atomic**.

## 2. Design: Redis Lua reservation tokens

Reservations live in Redis (fast, TTL-native) and are **tokens with leases**, not counters alone. Postgres remains the system of record for what *happened* (jobs, ledger); Redis is the control plane for what may happen *right now*.

### 2.1 Key layout

```
quota:conc:{provider}:{scope}            HASH    field=reservation_id, value=units
quota:conc:{provider}:{scope}:total      STRING  reserved units (maintained by same Lua)
quota:win:{provider}:{scope}:{window}    STRING  counter, TTL = window remainder
quota:meta:{provider}:{scope}            HASH    limits snapshot {concurrency, per_min, per_day, fetched_at}
reservation:{id}                         STRING  JSON {job_id, provider, scope, units, created_at}, TTL = lease
```

`scope` is the account-level limit surface: `fal:main` (account concurrency), `replicate:main` (per-min), `gemini:project:<gcp_project>` (per-project limits, F-0039), `elevenlabs:main:multilingual_v2` (per model family, F-0040).

### 2.2 Acquire (single Lua script — atomic)

```lua
-- KEYS: conc_hash, conc_total, win_min, win_day, meta, reservation_key
-- ARGV: reservation_id, units, max_conc, max_per_min, max_per_day, lease_ttl_s, win_ttl_s
local total = tonumber(redis.call('GET', KEYS[2]) or '0')
if total + ARGV.units > ARGV.max_conc then return {err='CONCURRENCY_FULL'} end
if ARGV.max_per_min > 0 then
  local w = tonumber(redis.call('GET', KEYS[3]) or '0')
  if w + ARGV.units > ARGV.max_per_min then return {err='RATE_MIN_FULL'} end
end
if ARGV.max_per_day > 0 then
  local d = tonumber(redis.call('GET', KEYS[4]) or '0')
  if d + ARGV.units > ARGV.max_per_day then return {err='RATE_DAY_FULL'} end
end
redis.call('HSET', KEYS[1], ARGV.reservation_id, ARGV.units)
redis.call('INCRBY', KEYS[2], ARGV.units)
if ARGV.max_per_min > 0 then
  redis.call('INCRBY', KEYS[3], ARGV.units); redis.call('EXPIRE', KEYS[3], ARGV.win_ttl_s, 'NX')
end
if ARGV.max_per_day > 0 then
  redis.call('INCRBY', KEYS[4], ARGV.units); redis.call('EXPIRE', KEYS[4], 86400, 'NX')
end
redis.call('SET', KEYS[6], ARGV.job_payload, 'EX', ARGV.lease_ttl_s)
return {ok='RESERVED'}
```

The worker submits to the provider **only** on `RESERVED`. The reservation ID travels on the job row (`jobs.quota_reservation_id`).

### 2.3 Release / settle / expire

- **Submit succeeded** → reservation converts to "in-flight": kept until provider completion (fal counts IN_PROGRESS against concurrency, so we mirror that exactly).
- **Provider accepted then finished/failed** → Lua release: `HSET` delete + `DECRBY` total + delete reservation key. (Per-minute/day window counters are *not* decremented — they model consumed rate allowance, which completion does not refund.)
- **Worker crash** → lease TTL expires; a sweeper finds `reservation:*` keys whose job is not in `submitted/in_progress` state and releases them. Worst case: the lease (default 10 min) holds capacity briefly — safe, never over-limit.
- **Provider rejects with limit error** (fal 429 `concurrent_requests_limit` + `X-Fal-needs-retry: 1`, F-0036; ElevenLabs queue-then-429, F-0040) → job parks `quota_blocked` with backoff; reservation released so other jobs can use the capacity; retry re-acquires.

### 2.4 Window alignment

- fal concurrency: rolling (IN_PROGRESS set) — modelled by the hash+total above.
- Replicate per-minute: fixed 60 s windows with TTL; 429 resets ~30 s observed (F-0037) so window keys use `floor(now/60)`.
- Gemini RPD: resets **midnight Pacific** (F-0039) — window key includes the Pacific date; TTL computed to that boundary, never a naive 24 h rolling counter.
- ElevenLabs: limits are concurrency-shaped; additionally the adapter reads `current-concurrent-requests`/`maximum-concurrent-requests` response headers (F-0040) and **feeds observed maxima back into `quota:meta`** — self-tuning instead of static config when plans change.

### 2.5 Dynamic limits (Gemini rule)

Limits are **data, not constants** (F-0039): `quota:meta` is refreshed by a scheduled job reading each provider's live limits endpoint/dashboard-scrape equivalent; Gemini limits are entered from AI Studio readings at config time and re-verified weekly (manual step, logged). Every `quota:meta` write is versioned and stamped with `fetched_at`; reservations refuse (`LIMITS_STALE`) if the snapshot is older than its freshness budget (default 30 days for concurrency, 7 days for free-tier quotas) — preferring to pause and notify over silently overspending.

### 2.6 Free-quota enforcement (the user's hard rule, mechanised)

Free-tier quotas are per-provider-window counters seeded from the registry's `free_quota` fields (`groq: rpd_per_model`, `cloudflare: 10000 neurons/day`, `openrouter: 50/day or 1000/day`, `gemini flash: live value`). The router's spend policy check runs **inside the same reservation call**: if the workspace policy is `free_only` and the free window is exhausted, acquire returns `FREE_EXHAUSTED` and the job parks + notifies — there is **no code path** that falls through to a paid model. Paid routing requires the workspace's explicit `paid_authorised` policy recorded in Postgres, checked before reservation, and every paid reservation writes a `quota_events` row for audit.

## 3. Failure modes & guarantees

| Failure | Behaviour | Guarantee |
|---|---|---|
| Two workers race acquire | Lua is atomic in Redis | Never over-limit |
| Worker crashes post-acquire | Lease TTL + sweeper release | Capacity leaked ≤ lease duration, never overspent |
| Redis down | Workers refuse submissions (`quota_unknown`) and jobs park | Fail-closed, never fail-open |
| Redis loses data (AOF replay) | `quota:meta` re-fetched; in-flight reservations rebuilt from Postgres `jobs.status='submitted'` rows on boot | Recovery from system of record |
| Provider raises/lowers limits | `quota:meta` refresh + ElevenLabs header feedback | Self-tuning within freshness budget |

## 4. Test contract (CI)

- Concurrency stress: N parallel acquire attempts against limit L ⇒ exactly ≤L reservations at all times (Redis in CI container).
- Lease-expiry test: killed worker ⇒ capacity returns within TTL, job re-queued once.
- Window test: mocked clock across midnight-Pacific boundary ⇒ RPD window resets exactly at boundary.
- Fail-closed test: Redis unreachable ⇒ zero provider submissions attempted.
