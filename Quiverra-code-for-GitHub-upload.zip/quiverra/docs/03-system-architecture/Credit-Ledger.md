# Credit Ledger — Double-Entry Accounting Design

**Version:** 2.0 · **Status:** Corrected design (supersedes the append-only sketch in Database-Architecture.md v1.0) · **ADR:** 0012 · **Date:** 2026-11-10
**Correction driver:** user review — "Correct the double-entry credit ledger design. It needs proper transactions, debit and credit postings and balanced accounting."

---

## 1. Accounting model

Every movement of value is a **transaction** containing ≥2 **postings**; within a transaction, `SUM(debits) = SUM(credits)` and all postings share one **currency domain**. Nothing mutates in place: corrections are reversing transactions, never updates or deletes.

Two currency domains, never summed together:

- `CREDIT` — platform credits (what users buy, reserve and spend)
- `USD_MICRO` — real money at 10⁻⁶-dollar precision (purchases, provider costs, refunds)

Cross-domain events (e.g. buying credits with dollars) are **separate balanced transactions linked by `link_group`** (UUID). The CREDIT-domain transaction and its USD-domain counterpart each balance internally.

## 2. Chart of accounts (normative)

`ws_*` accounts are created per workspace at provisioning; system accounts are seeded by migration.

### CREDIT domain
| Code | Type | Normal | Purpose |
|---|---|---|---|
| `asset:credits_available:ws_*` | asset | debit | Spendable credits the workspace holds |
| `asset:credits_reserved:ws_*` | asset | debit | Credits held against in-flight generation jobs |
| `liability:credits_issued:sys` | liability | credit | Platform obligation for all outstanding user credits |

### USD_MICRO domain
| Code | Type | Normal | Purpose |
|---|---|---|---|
| `asset:cash:sys` | asset | debit | Money received from users |
| `asset:provider_prepaid:<provider>` | asset | debit | Our prepaid balances at fal / Replicate / Kling / etc. |
| `liability:deferred_revenue_usd:sys` | liability | credit | Cash received for not-yet-consumed credits |
| `revenue:generation:sys` | revenue | credit | Revenue recognised as credits are consumed |
| `revenue:breakage:sys` | revenue | credit | Revenue from expired credits |
| `expense:provider_cost:sys` | expense | debit | What providers actually charged us (per usage reports) |
| `expense:refunds:sys` | expense | debit | Goodwill / policy refunds |
| `equity:adjustments:sys` | equity | — | Manual corrections (paired, with mandatory `reason` + `operator_id`) |

**Invariant derivable at any instant:** `balance(liability:credits_issued) = Σ_ws balance(asset:credits_available:ws_*) + Σ_ws balance(asset:credits_reserved:ws_*)`. Asserted nightly by reconciliation (§6).

## 3. Posting recipes (binding — one per value-moving event)

| # | Event | Domain | Postings |
|---|---|---|---|
| R1 | User buys 2,500 cr for $25 (basis $0.01/cr stored on tx) | USD_MICRO | **Dr** `asset:cash:sys` 25,000,000 · **Cr** `liability:deferred_revenue_usd:sys` 25,000,000 |
| R1′ | 〃 credit issuance (same `link_group`) | CREDIT | **Dr** `asset:credits_available:ws_W` 2500 · **Cr** `liability:credits_issued:sys` 2500 |
| R2 | Reserve 120 cr for a generation batch | CREDIT | **Dr** `asset:credits_reserved:ws_W` 120 · **Cr** `asset:credits_available:ws_W` 120 |
| R3 | Release reservation (job cancelled / server error) | CREDIT | **Dr** `asset:credits_available:ws_W` 120 · **Cr** `asset:credits_reserved:ws_W` 120 |
| R4 | Settle consumption — job completed, actual 118 cr | CREDIT | **Dr** `liability:credits_issued:sys` 118 · **Cr** `asset:credits_reserved:ws_W` 118; surplus 2 cr released via R3 |
| R4′ | 〃 revenue recognition at basis $0.01/cr (same `link_group`) | USD_MICRO | **Dr** `liability:deferred_revenue_usd:sys` 1,180,000 · **Cr** `revenue:generation:sys` 1,180,000 |
| R5 | Goodwill refund 118 cr (completed-but-defective complaint) | CREDIT | **Dr** `asset:credits_available:ws_W` 118 · **Cr** `liability:credits_issued:sys` 118 |
| R5′ | 〃 recognition reversal (same `link_group`) | USD_MICRO | **Dr** `revenue:generation:sys` 1,180,000 · **Cr** `liability:deferred_revenue_usd:sys` 1,180,000 |
| R6 | Credit pack expires (90-day rule), 400 cr | CREDIT | **Dr** `liability:credits_issued:sys` 400 · **Cr** `asset:credits_available:ws_W` 400 |
| R6′ | 〃 breakage recognition (same `link_group`) | USD_MICRO | **Dr** `liability:deferred_revenue_usd:sys` 4,000,000 · **Cr** `revenue:breakage:sys` 4,000,000 |
| R7 | We prepay fal $100 | USD_MICRO | **Dr** `asset:provider_prepaid:fal` 100,000,000 · **Cr** `asset:cash:sys` 100,000,000 |
| R8 | Provider usage report: job cost $0.84 | USD_MICRO | **Dr** `expense:provider_cost:sys` 840,000 · **Cr** `asset:provider_prepaid:fal` 840,000 |
| R9 | Cash refund to user $5 | USD_MICRO | **Dr** `expense:refunds:sys` 5,000,000 · **Cr** `asset:cash:sys` 5,000,000 |
| R10 | Manual adjustment | either | Operator-supplied balanced postings, `kind='adjustment'`, mandatory `reason` + `operator_id` |

Key properties:

- **Server-error failures are non-events in the ledger.** Reservations hold value inside the CREDIT domain without extinguishing the liability; a `server_error` failure class simply releases the reservation (R3). This mirrors provider reality — fal 5xx unbilled (F-0036), Replicate public-model failures unbilled (F-0037) — so our ledger and our costs move together.
- **Completed-but-defective outputs consume normally** (R4), matching the industry norm (F-0034). The product surfaces their cost via acceptance-rate telemetry; goodwill is explicit and attributable (R5), never silent.
- **Estimates never post.** Only reservations, settlements, releases, purchases, expiries and provider costs touch the ledger.

## 4. Schema (normative DDL)

```sql
CREATE TYPE currency_domain AS ENUM ('CREDIT', 'USD_MICRO');
CREATE TYPE posting_direction AS ENUM ('debit', 'credit');

CREATE TABLE ledger_accounts (
  code            text PRIMARY KEY,                 -- 'asset:credits_available:ws_9f3…'
  type            text NOT NULL CHECK (type IN ('asset','liability','revenue','expense','equity')),
  normal_balance  posting_direction NOT NULL,
  domain          currency_domain NOT NULL,
  workspace_id    uuid REFERENCES workspaces(id),   -- NULL for system accounts
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ledger_transactions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  link_group      uuid,                             -- ties cross-domain counterparts
  domain          currency_domain NOT NULL,
  kind            text NOT NULL CHECK (kind IN
                    ('issuance','purchase','reservation','release','settlement',
                     'recognition','goodwill','expiry','breakage','provider_prepay',
                     'provider_cost','refund_cash','adjustment')),
  workspace_id    uuid REFERENCES workspaces(id),
  job_id          uuid REFERENCES jobs(id),
  idempotency_key text NOT NULL UNIQUE,             -- job_id + kind; replays return existing tx
  usd_basis_micro_per_credit bigint,                -- purchase-time basis for recognition
  reason          text,                             -- mandatory when kind='adjustment'
  operator_id     uuid,                             -- mandatory when kind='adjustment'
  created_at      timestamptz NOT NULL DEFAULT now(),
  CHECK (kind <> 'adjustment' OR (reason IS NOT NULL AND operator_id IS NOT NULL))
);

CREATE TABLE ledger_postings (
  id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  transaction_id  uuid NOT NULL REFERENCES ledger_transactions(id),
  account_code    text NOT NULL REFERENCES ledger_accounts(code),
  direction       posting_direction NOT NULL,
  amount          bigint NOT NULL CHECK (amount > 0)  -- always positive; direction carries sign
);
CREATE INDEX idx_postings_account ON ledger_postings(account_code);
CREATE INDEX idx_ledger_tx_workspace ON ledger_transactions(workspace_id, created_at DESC);

-- Balanced-transaction enforcement (deferred to end of DB transaction)
CREATE OR REPLACE FUNCTION ledger_assert_balanced() RETURNS trigger AS $$
DECLARE deb bigint; cred bigint;
BEGIN
  SELECT COALESCE(SUM(amount) FILTER (WHERE direction='debit'), 0),
         COALESCE(SUM(amount) FILTER (WHERE direction='credit'), 0)
    INTO deb, cred
    FROM ledger_postings WHERE transaction_id = NEW.transaction_id;
  IF deb <> cred OR deb = 0 THEN
    RAISE EXCEPTION 'ledger transaction % unbalanced: debit=% credit=%', NEW.transaction_id, deb, cred;
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER ledger_balanced
  AFTER INSERT ON ledger_postings DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION ledger_assert_balanced();

-- Derived balances, never stored (a stored balance could disagree with history)
CREATE VIEW v_workspace_credit_balances AS
  SELECT a.workspace_id,
         SUM(CASE WHEN a.code LIKE 'asset:credits_available:%'
                  THEN CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END ELSE 0 END) AS available,
         SUM(CASE WHEN a.code LIKE 'asset:credits_reserved:%'
                  THEN CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END ELSE 0 END) AS reserved
    FROM ledger_accounts a
    JOIN ledger_postings p ON p.account_code = a.code
   WHERE a.workspace_id IS NOT NULL AND a.domain = 'CREDIT'
   GROUP BY a.workspace_id;
```

## 5. Write path: one door, recipe-validated

Application roles have **no direct INSERT** on `ledger_*` (RLS deny-all, §Database-Architecture RLS section). All writes go through:

```sql
ledger.post(recipe text, workspace uuid, job uuid, amounts jsonb, idempotency_key text, …) RETURNS uuid
```

A `SECURITY DEFINER` function owned by the migration role that: (1) looks up the recipe template (R1..R10), (2) builds the exact postings for that recipe — application code can never construct arbitrary postings, except `adjustment` which demands `reason` + `operator_id`, (3) for R2 (reservation) asserts `available ≥ amount` inside the same DB transaction (`SELECT … FOR UPDATE` on a per-workspace lock row to serialise reservation attempts), (4) inserts with the idempotency key — on conflict returns the existing transaction. Concurrent double-spend of the same credits is therefore impossible even under racing workers (complements the Redis quota layer, ADR-0014, which guards provider-side limits, not ledger correctness).

## 6. Reconciliation

Nightly job asserts, for all time:
1. `balance(liability:credits_issued) = Σ available + Σ reserved` (CREDIT domain).
2. `balance(liability:deferred_revenue_usd) = Σ_ws (available+reserved) × basis` weighted per issuance batch (basis is stored per transaction, so mixed-price packs reconcile exactly).
3. Every R8 (provider cost) matches a `usage_reports` row; every R4 matches a settled job.
4. Drift ≠ 0 pages the operator. Drift is impossible via the application (one door, §5) — so drift means infrastructure tampering and is treated as a security incident.

## 7. Test contract (CI)

- **Property test:** randomised recipe sequences (incl. crashes between reservation and settlement, replayed webhooks, duplicate idempotency keys) always end with balanced transactions, `available ≥ 0`, `reserved ≥ 0`, and zero reconciliation drift.
- **Replay test:** identical `idempotency_key` submitted twice yields exactly one transaction.
- **Recovery test:** worker killed mid-settlement ⇒ sweeper reverses the reservation; ledger shows no consumption; provider cost never posts for `server_error` classes.
- **Recipe test:** each of R1..R10 produces its exact posting template and is rejected if amounts mismatch the recipe arity.

---

## 8. Commercial configurability (ADR-0019 — gate decision 4)

The ledger is pricing-agnostic by construction; final commercial parameters are **deferred** pending measured costs. Binding rules:

1. **Nothing commercial is hardcoded.** Credit price, pack sizes, expiry window, margin target and currency display live in a versioned `commercial_config` store (admin-editable, every change a new version with operator identity and timestamp — config changes are auditable like everything else).
2. **Per-issuance basis, not global constants.** R1/R1′ store `usd_basis_micro_per_credit` on the transaction, so a future price change affects only new issuances; historical balances reconcile exactly forever (§6.2).
3. **Payments dormant.** Live payments and customer credit purchases stay disabled until the commercial model, refund rules, expiry policy and legal requirements are reviewed and approved. Until then, workspaces run on internally granted development credits — issued through the same R1 recipe with `kind='issuance'`, `operator_id` recorded, zero USD counterpart (the USD transaction is simply omitted; the CREDIT-domain transaction balances on its own via the `contra` memorandum pattern documented in §3).
4. **Measurement-first.** From the first staging run, the ledger + `usage_reports` + nightly reconciliation accumulate the actual evidence for the pricing decision: provider costs per asset class, failure/retry rates, effective cost per accepted generation, storage and infrastructure allocation. The eventual pricing proposal must cite this data, not estimates.
5. **No purchasable-credit UI** while payments are dormant; the billing page shows balance, history and usage — no checkout surface exists to accidentally activate.
