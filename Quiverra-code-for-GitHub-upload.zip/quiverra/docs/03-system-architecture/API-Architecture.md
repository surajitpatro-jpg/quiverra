# API Architecture

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Draft for gate review
**Style:** REST/JSON over HTTPS · **Realtime:** WebSocket channel for job/workflow progress · **Surface:** single `/api/v1` prefix behind the gateway

---

## 1. Conventions (apply to every route)

| Concern | Rule |
|---|---|
| **AuthN** | Supabase JWT in `Authorization: Bearer`. Gateway validates, resolves workspace + role, injects `x-workspace-id` downstream. |
| **AuthZ** | Role matrix: owner > director > editor > viewer. Mutations require editor+; spend authorisation and provider-key admin require owner. |
| **Versioning** | URI major version (`/api/v1`). Breaking changes = new major; additive fields allowed in place. Registry/knowledge data versions internally (`valid_from`), not via URI. |
| **Idempotency** | All POSTs that create work accept `Idempotency-Key` header (client-generated UUID). Server stores key → response for 24h; replay returns original response without re-executing. Generation tasks additionally dedupe by content hash (ADR-0008). |
| **Errors** | RFC 9457 problem+json: `{type, title, status, detail, code, evidence?}`. `code` is machine-stable (e.g. `FREE_QUOTA_EXHAUSTED`, `ESTIMATE_EXCEEDED`, `GATE_PENDING`). Never leak provider payloads or key material in errors. |
| **Pagination** | Cursor-based: `?cursor=&limit=` (default 50, max 200). Response `{items, next_cursor}`. |
| **Validation** | Zod schemas shared between client and server (single TS package) — spec-defined YAML schemas compile to Zod. |
| **Rate limits** | Per-workspace: 600 req/min general, 60 req/min estimate-generating endpoints (they are cheap but abuse-prone), queue depth caps on generation submits. |
| **Money display** | All cost fields numeric minor-unit-safe decimals + currency; estimates carry `registry_snapshot_id` so the UI can show "priced as of …" (freshness rule). |

## 2. Route map (by engine)

Routes are the contract; full field schemas live in each engine's spec (docs/02-proprietary-systems) and the Database doc.

### Creative Director
```
POST   /api/v1/briefs                              create brief
POST   /api/v1/briefs/:id/versions                 submit structured version
GET    /api/v1/briefs/:id                          brief + current version
POST   /api/v1/briefs/:id/plan                     run staged pipeline → Plan + CostEstimate (async)
GET    /api/v1/plans/:id                           plan graph
POST   /api/v1/plans/:id/approve                   approve plan (owner/director)
GET    /api/v1/plans/:id/decisions                 CreativeDecision graph
POST   /api/v1/plans/:id/decisions/:did/override   human override with rationale (append-only)
```

### Scene & Continuity
```
GET    /api/v1/scenes/:sceneId/state               current SceneState
POST   /api/v1/scenes/:sceneId/state/versions      commit new state version
GET    /api/v1/scenes/:sceneId/contract            active ContinuityContract
PUT    /api/v1/scenes/:sceneId/contract            replace rule set (versioned)
POST   /api/v1/continuity/check                    check artefact vs contract → ContinuityReport
GET    /api/v1/continuity/reports/:id
```

### Storyboard & Shots
```
GET    /api/v1/projects/:id/shots?view=board|table|timeline
POST   /api/v1/shots                               create shot
POST   /api/v1/shots/:id/versions                  new ShotVersion
POST   /api/v1/shots/:id/regenerate                selective regen (frozen snapshot, ADR-0007)
GET    /api/v1/projects/:id/export?format=csv|pdf|animatic|edl
```

### Characters
```
POST   /api/v1/characters
POST   /api/v1/characters/:id/versions             new CharacterVersion (identity, wardrobe, capability map)
GET    /api/v1/characters/:id/capability-map       which registry models can hold this identity
POST   /api/v1/characters/:id/reference-sheet      generate sheet (intelligence + image tasks)
GET    /api/v1/characters/:id/portability          bindings & portability classes
```

### Cinema Intelligence
```
POST   /api/v1/shots/:id/cinematography            create CinematographyRecord
POST   /api/v1/cinematography/:id/compile          → CompiledInstructions per candidate model
GET    /api/v1/cinematography/:id/honesty-report   native vs approximated vs unsupported (ADR-0006)
```

### Brand & Marketing
```
POST   /api/v1/brands                              create BrandProfile
POST   /api/v1/brands/:id/versions
POST   /api/v1/brands/:id/compliance-check         → ComplianceReport (deterministic-first)
POST   /api/v1/brands/:id/variants                 generate compliant variants
```

### Workflow Intelligence
```
POST   /api/v1/workflows                           define + compile DAG (content-hash pinned)
POST   /api/v1/workflows/:id/runs                  start run (budget_cap optional)
GET    /api/v1/runs/:id                            status, spent, per-task breakdown
POST   /api/v1/runs/:id/gates/:gateId/decide       approve/reject gate
POST   /api/v1/runs/:id/authorise-spend            resolve awaiting_authorisation (explicit consent — never silent)
POST   /api/v1/runs/:id/cancel
```

### Orchestration & billing
```
GET    /api/v1/registry/models?modality=&capability=     capability-filtered catalog (current valid rows)
GET    /api/v1/registry/models/:provider/:model          detail incl. classification + data policy + evidence ref
POST   /api/v1/estimates                                 ad-hoc CostEstimate (deterministic)
GET    /api/v1/billing/balance                           ledger balance + open holds
GET    /api/v1/billing/entries                           ledger history
GET    /api/v1/billing/quotas                            free-quota windows + consumption (admin)
POST   /api/v1/billing/topups                            create Razorpay/Cashfree order (DISABLED until billing rules defined)
GET    /api/v1/jobs/:id                                  render job status + artefact links
```

### WebSocket
```
/ws?workspace=...   events: task.status, run.status, job.progress,
                    quota.exhausted, gate.pending, estimate.exceeded
```

## 3. Cross-route guarantees

1. **Estimate-before-execute.** Every route that can spend money (`/plan`, `/regenerate`, `/variants`, `/runs`, `/compile` with generation) returns or references a `cost_estimate_id`; execution routes validate a settled estimate exists and a hold covers it (ADR-0005).
2. **Honesty by construction.** Any route returning compiled model instructions includes the classification enum and, when `prompt_approximated` or `reference_conditioned`, an `honesty_report` link (ADR-0006). The UI must render the badge; this is a contract, not a suggestion.
3. **Free-quota transparency.** `GET /billing/quotas` exposes what the router sees; user-facing copy distinguishes "platform free capacity" from "your credits" — two ledgers, never blended.
4. **No key surface.** There is no route that returns provider credentials; provider admin routes store `auth_ref` only.

## 4. Endpoint classification for testing (feeds Testing-Strategy.md)

| Class | Routes | Test emphasis |
|---|---|---|
| Money-moving | estimates, runs, regenerate, variants, topups | hold/charge/refund invariants, idempotent replays, provider-failure billing semantics (F-0021/22) |
| Decision-producing | plan, compile, compliance-check, continuity/check | deterministic fixtures; snapshot tests on outputs given pinned registry |
| State-versioning | all `*/versions` | immutability (mutation attempts rejected), version chaining |
| Catalog | registry | freshness metadata present; evidence_id resolvable |
