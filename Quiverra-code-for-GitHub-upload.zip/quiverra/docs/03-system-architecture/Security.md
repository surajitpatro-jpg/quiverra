# Security Architecture

**Version:** 1.1 · **Date:** 2026-11-10 · **Status:** Updated post-gate (ADR-0020 confidential-by-default, ADR-0021 Mumbai residency)
**Binding constraints (master brief + gate):** all provider keys server-side; never in frontend code; never in public repos or project documentation; no silent paid spend; no live payments until billing/legal/refund rules are defined; privacy is the default posture.

---

## 1. Trust boundaries

```
Browser ──(1)──▶ Gateway/BFF ──(2)──▶ Domain services ──(3)──▶ Provider APIs
   │                  │                     │
   │                  ▼                     ▼
   │            Supabase Auth/DB      Redis (internal only)
   │                  │
   └──── never holds provider keys; holds only user JWT ────▶ R2 (signed URLs)
```

1. **(1) TLS only.** HSTS; no mixed content. JWTs short-lived (Supabase default), refresh via httpOnly cookie.
2. **(2) Server-internal.** Domain services trust gateway-injected identity headers only on the private network; external requests cannot forge them (network policy).
3. **(3) The only boundary where provider credentials exist** — in worker processes' environment, never persisted to DB, logs, or job payloads.

## 2. Secrets management

| Secret | Storage | Access | Rotation |
|---|---|---|---|
| Provider API keys | VPS-local env files (Docker secrets in compose), mode 600, outside repo | workers only, at process start | Manual quarterly; immediately on suspicion |
| Supabase service-role key | same mechanism, API only | API | On staff change |
| Razorpay/Cashfree keys + webhook secrets | same mechanism, API only | API | At payment activation (not before — payments stay disabled) |
| User JWT secrets | Supabase-managed | — | Supabase |

Hard rules: no secrets in git (enforced by pre-commit scan + CI `gitleaks`); `provider_accounts.auth_ref` stores an opaque env-var name, never material; logs scrub `Authorization`/key-shaped strings (denylist filter); error responses never include provider response bodies verbatim.

## 3. Authentication & authorisation

- **AuthN:** Supabase Auth (email + Google OAuth). Email verification required before any spend authorisation.
- **AuthZ:** workspace roles enforced twice — RLS policies in Postgres (defence in depth) *and* service-layer checks. Role matrix:

| Capability | owner | director | editor | viewer |
|---|---|---|---|---|
| Read artefacts | ✓ | ✓ | ✓ | ✓ |
| Create/edit artefacts, run free-tier work | ✓ | ✓ | ✓ | — |
| Authorise paid spend, top-ups | ✓ | — | — | — |
| Manage provider accounts, registry overrides | ✓ | — | — | — |
| Manage members, workspace confidentiality flag | ✓ | — | — | — |

- **Service-to-service:** workers authenticate to API via one-way queue contract (they never call back into auth); DB access uses a least-privilege role (no `ALTER`, no access to `ledger_entries` insert except ledger service role).

## 4. Data protection

- **Encryption:** TLS 1.2+ in transit; at-rest via Supabase (AES-256) and R2 (SSE). No additional field-level encryption in MVP except `provider_accounts` (defence in depth on the auth_ref indirection).
- **Customer media in R2:** private buckets; access via short-lived signed URLs minted by the API after AuthZ check. No public buckets, ever.
- **Confidential workspaces (DEFAULT ON — ADR-0020):** `workspaces.confidential` defaults `true`; turning it off is a deliberate owner action with a consequences summary. When on: the router applies a **hard filter** excluding any registry row whose `data_policy` is `trains_by_default` or `unknown` (OpenRouter `:free`, F-0020; free-tier Gemini, F-0044; ElevenLabs pre-opt-out, F-0045) — restricted providers are refused, never merely disclaimed. We do not claim our flag overrides third-party policies: providers that cannot meet the conditions are simply not used. Per-provider data-use/retention terms are surfaced to the user at the routing-decision level (honesty again).
- **Provider disclosure UX (ADR-0020):** before a workspace's first call to each external provider, the UI states exactly what will be sent, to whom, under which data-use/retention policy (generated from registry `data_policy` rows — the same mechanism that generates the privacy-policy sub-processor list, §7). The disclosure is logged with timestamp and version.
- **No training on customer content (ADR-0020):** we do not use customer content to train our own models. Provider-side training exposure is controlled by the hard filter above plus provider-specific measures: fal calls carry `X-Fal-Store-IO: 0` by default and payload deletion on request (F-0042); Gemini routes only via billing-enabled project (paid-tier terms, F-0044); ElevenLabs is inadmissible until its data-use opt-out is applied **and verified** (prospective-only setting, F-0045; ADR-0017 precondition).
- **PII minimisation:** user table stores email/name only; character reference photos are user-supplied media — likeness-consent attestation captured at upload (checkbox + log), consistent with the portability/consent stance in Character-Intelligence spec.
- **Backups:** Supabase PITR (plan-dependent; if unavailable, nightly `pg_dump` to R2, encrypted, 30-day retention). Restore drill documented in Deployment.md; untested backups are treated as absent (verification doctrine).

## 5. Application security

- Input validation on every route (shared Zod schemas); output encoding by framework defaults; SQL access exclusively via Drizzle parameterised queries (ADR-0010) — string-built SQL is a review blocker.
- Rate limiting at gateway (per-workspace + per-IP); stricter on auth endpoints and spend-adjacent endpoints.
- CSRF: cookie-based refresh only on same-site strict; API calls use Bearer header ⇒ CSRF-resistant by construction.
- Webhooks (Razorpay/Cashfree, provider job callbacks where supported): signature verification mandatory, replay protection via nonce+timestamp window, processing idempotent on provider event id.
- Dependency hygiene: lockfile committed; `npm audit` in CI; Renovate-style monthly update PRs (user-side CI once repo mirroring is active, KI-01).
- File uploads: MIME sniffing + size caps + AV scan hook (ClamAV container in compose) before R2 promotion.

## 6. Abuse & financial safety

- Free-quota consumption is per-workspace rate-limited so one workspace cannot drain shared platform free capacity (fair-use governor in the Free-Quota Manager).
- Spend authorisation UX requires explicit affirmative action (never a pre-checked box); `spend_authorisations` are logged append-only with the estimate snapshot shown at consent time.
- Anomaly alerts: charge velocity > threshold, repeated billable failures (F-0022 semantics), estimate-vs-actual drift beyond tolerance ⇒ auto-pause + owner notification.
- Ledger integrity: `ledger_entries` insert-only (DB revoke UPDATE/DELETE); reconciliation job (see Orchestration §5) is the detective control.

## 7. Compliance posture (pre-launch, India-first)

- Payments dormant until: refund policy, credit-expiry policy (schema-ready), GST invoice requirements, and ToS are defined — per the master brief, this is a launch gate, not an afterthought.
- Privacy policy must disclose sub-processors (each AI provider is one) — the registry's `data_policy` rows generate this list automatically, keeping legal text honest by construction.
- DPDP Act 2023 alignment: consent capture, purpose limitation (media used only to provide the service), user data export (workspace dump from Postgres + R2 manifest) and deletion (crypto-shredding via per-workspace R2 prefix delete + row deletion) as Phase 6 scope.
- **Data residency (ADR-0021):** primary database in Supabase Mumbai (ap-south-1). The data-residency register in Deployment.md §9 lists every external processor that may handle data outside India. **We do not claim the Mumbai region alone confers DPDP compliance** — compliance is the sum of consent, purpose limitation, disclosure, sub-processor honesty and deletion mechanics above, and it is never asserted as achieved in copy.

## 8. What we explicitly do NOT claim (verification doctrine)

- No penetration test has been run (no running system yet); Phase 7 includes an external or tooling-assisted (REA, per its defensive scope) review before public launch.
- No SOC 2 / ISO claims. Provider-side attestations (fal SOC 2, F-0021) are inherited at infrastructure level only and never presented as our own.
