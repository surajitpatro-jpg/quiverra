# Workflow Execution

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Draft for gate review
**Scope:** how compiled workflow DAGs execute: queues, workers, retries, gates, budgeting, observability. Implements ADR-0008 (compiled DAGs, idempotent content-hash tasks) on Redis + BullMQ.

---

## 1. Execution model

A `Workflow` is compiled once into an immutable DAG (`compiled_dag`, content-hashed). A `WorkflowRun` executes that exact compilation forever — edits to the workflow produce a new version, never mutate running DAGs. Each node becomes one or more `workflow_tasks`:

| Task kind | Executor | Queue | Timeout (default) |
|---|---|---|---|
| `intelligence` | worker-intel (LLM/VLM calls via router) | `q.intel` | 120s |
| `generation` | worker-gen (media providers) | `q.gen` | 30 min (provider-bound) |
| `deterministic` | inline in API/worker (validators, compliance rules, costing) | — | n/a |
| `gate` | scheduler state only | — | waits on human/auto decision |

Dependencies are resolved by the scheduler: a task becomes runnable when all parent tasks are `complete` (or `complete_with_warnings` where the DAG allows).

## 2. Queues & workers (BullMQ)

- Two queues, deliberately separate: `q.intel` (high throughput, small jobs, free-tier-optimised) and `q.gen` (low throughput, provider-concurrency-bound). fal concurrency grows 2→40 with purchase history (F-0021) — worker-gen concurrency is *configured per provider account* from `provider_accounts.concurrency_limit`, not guessed.
- Workers are stateless. All state lives in Postgres (`workflow_tasks`) + Redis (queue bookkeeping). A worker crash loses nothing: BullMQ re-queues stalled jobs; idempotency keys make re-execution safe.
- **Idempotency:** every task carries `idempotency_key = hash(run_id, node_key, input_hash)`. Before executing, the worker checks for a completed task with the same key (or an artefact with the same `content_hash`) and short-circuits to its output (ADR-0008). Regenerating one shot after an upstream edit re-runs only the affected subtree.

## 3. Scheduler loop

1. Pop runnable tasks (parents complete, run status `running`).
2. Pre-flight: deterministic checks (contract validators, budget remaining).
3. Route via Orchestration Engine (capability request → provider selection → quota allocation or credit hold).
4. If router returns `awaiting_authorisation`: run transitions to `awaiting_authorisation`, WS event fires, scheduler stops advancing that branch (parallel branches continue).
5. Enqueue to the appropriate queue with the **frozen job snapshot** (ADR-0007): inputs + registry snapshot + routing decision.

## 4. Retries & failure taxonomy

| Failure | Retry policy | Money effect |
|---|---|---|
| Provider 5xx / network | 2 retries same provider (exp backoff), then router failover | None — unbillable per fal/Replicate policy (F-0021/22); hold stays open |
| Provider 429 | Honour `Retry-After`; else park until quota window resets | None |
| Model output fails deterministic validation (e.g. continuity `fail`) | Regenerate with escalated quality class, max 2 escalations | Each attempt estimated & held; user sees retry spend line |
| Task timeout | Mark failed, router failover once | Hold released unless provider bills (billable failure surfaced) |
| Gate rejected | Branch cancelled; upstream artefacts retained | Holds on downstream tasks released |
| Budget cap reached | Run pauses (`awaiting_authorisation` with `BUDGET_CAP` code) | No further holds |

Escalation and failover are **recorded on the task row** (`attempt`, `output.routing_history`) — the receipt of what happened.

## 5. Gates

Two kinds, same mechanism:
- **Human gates** (plan approval, brand sign-off): run waits; WS + email notification; decision captured append-only with `decided_by`. Gate decisions are themselves artefacts (auditable — part of the "production intelligence" moat).
- **Auto gates** (continuity check, compliance check): deterministic validators run; `pass`/`warn`/`fail` per contract severity map; `fail` blocks by default, configurable to `warn`.

## 6. Budgeting

- Optional `budget_cap` per run; the Cost Estimator pre-computes the full-run estimate at compile time and refuses to start runs whose estimate exceeds the cap (fail fast, not mid-run).
- Live spend = settled charges + open holds; scheduler blocks new holds that would exceed `min(cap, estimate × (1+tolerance))`.
- All amounts in customer credits mirror ledger rows — the run page is literally a ledger view, so the numbers can never disagree (one source of truth).

## 7. Observability

- Structured logs per task: `run_id, node_key, provider, model, registry_snapshot_id, latency, billed`.
- Metrics: queue depth, per-provider success/latency/error-rate, free-quota consumption vs window, estimate-vs-actual drift (target: within declared tolerance; drift itself is a product feature shown to users).
- Tracing: OpenTelemetry spans from API → scheduler → worker → provider call; exported to a self-hosted collector on the VPS (Grafana/Prometheus, see Deployment.md).
- WS events mirror every state transition — the UI is a live projection, never polls for status.

## 8. Disaster behaviour

- Redis loss: queues rebuild from `workflow_tasks` (status `queued`/`running` re-enqueued; idempotency keys prevent duplicates). Acceptable because Redis holds no unique state.
- Postgres failover: managed by Supabase; workers pause on DB unavailability (jobs re-poll provider handles on recovery via `provider_job_id`).
- Provider outage mid-run: tasks stay `running` with provider handle; a sweeper reconciles statuses against provider APIs every 5 min; unbillable failures release holds automatically.

## 9. Throughput planning (MVP)

Intelligence tasks dominate volume and are free-tier-first; generation tasks dominate cost and are concurrency-limited by provider accounts. Sizing conclusion: 2 worker-intel + 2 worker-gen processes on the MVP VPS are sufficient; scale by adding worker processes before ever scaling the API (monolith remains single-writer to the scheduler, avoiding distributed-lock complexity in Phase 6).

---

## 10. Completion & Recovery Protocol (v2 — 2026-11-10)

*Added in the correction phase. §8 sketched the sweeper; this section is the normative per-provider completion contract, closing the "how does a job actually reach a terminal state" gap.*

### 10.1 Completion channels per provider (from verified contracts)

| Provider | Primary channel | Fallback | Provider-specific obligations |
|---|---|---|---|
| fal | **Webhook** after `subscribe()` (server-side requeue; no max-retry ceiling, F-0036) | Poll `status` endpoint every 30 s while `submitted/in_progress` | On completion: download outputs to R2 within the same worker turn; then delete nothing (payloads persist 90 days unless `X-Fal-Store-IO: 0`, F-0042) |
| Replicate | **Poll** (webhooks supported; poll is primary for MVP simplicity) | Webhook as latency optimisation post-MVP | **Outputs must be ingested to R2 immediately** — prediction files are deleted after 1 hour (F-0037/F-0043). Ingestion is part of the job, not a separate task: a job is not `succeeded` until its outputs are checksummed in R2 |
| Kling direct | Poll (task status API) | — | Package concurrency 5–20 enforced by ADR-0014 reservations |
| Runway Dev | Poll | Webhook where available | Input-video billed extra — estimate must include it (F-0038) |
| Gemini (video/LLM) | Poll long-running operation | Batch API where offered (50 % price, separate limits, F-0039) | Failed 400/500 still consume quota ⇒ adapter pre-validates against the model's schema before submit |
| ElevenLabs | REST response (synchronous per request) / WS session close | — | Self-tuning concurrency from `current/maximum-concurrent-requests` headers (F-0040) |

### 10.2 Webhook handling rules

1. **Verify, then treat as a hint.** Signature/HMAC verification per provider; even a valid webhook only *schedules a status poll* — ledger settlement happens solely on the polled/confirmed provider state. A forged webhook can therefore never move money or mark jobs complete.
2. **Idempotent by construction.** Webhook handler keys on `(provider, provider_ref, reported_status)`; replays are no-ops (ledger idempotency keys add a second layer, Credit-Ledger §4).
3. **Order-independent.** A webhook arriving before the submit transaction commits is parked and re-evaluated by the sweeper; final state always comes from provider truth, never from message order.

### 10.3 The reconciler sweeper (normative)

Runs every 60 s on worker-gen, single-instance (Redis lock):

1. Find jobs in `submitted` / `in_progress` older than their provider's expected latency (per-registry `expected_latency_s`).
2. Poll provider status for each (respecting ADR-0014 reservations — the sweeper consumes rate budget like any caller).
3. Terminal success ⇒ ingest outputs (Replicate: immediately), write `usage_reports`, settle ledger (R4/R8), release reservation, emit WS event.
4. Terminal failure ⇒ classify (`server_error` free-retry / `validation` no-retry / `content_flag` surface), release or reverse reservation per class, emit event.
5. Provider reports "unknown job" for a job we believe is in-flight ⇒ mark `orphaned`, release reservation, alert — this should never happen and always indicates a real incident.
6. Jobs with expired quota-reservation leases whose worker died ⇒ re-enqueue once via idempotency key (ADR-0008); provider-side duplicates are impossible because re-attach checks `provider_ref` first.

### 10.4 Crash re-attach

At submit time the worker writes `jobs.provider_ref` in the **same DB transaction** as the queue enqueue. A worker dying between provider-acceptance and commit is handled by the sweeper polling the reservation's `job_payload` and re-attaching by provider_ref — the provider job is never abandoned or double-submitted.

### 10.5 Recovery drills (pre-launch gate)

Executed against staging with real provider sandbox keys, results recorded in `ops/drills.md`:
- Kill -9 worker-gen mid-render ⇒ job recovers, ledger shows reservation release + re-run settles once.
- Block webhook endpoint ⇒ sweeper converges all jobs within one sweep interval × poll cadence.
- Replicate output ingested ≥55 min late (simulated) ⇒ job marked failed-recoverable and **alerted as a process bug** (ingestion SLA is minutes, not an hour).
- Redis flushall ⇒ queues rebuild from Postgres; reservations rebuild from `submitted` jobs; zero double submissions (verified by provider dashboards).
