# Database Architecture

**Version:** 2.0 · **Date:** 2026-11-10 · **Status:** Corrected (see §7 Correction Register)
**Store:** Supabase Postgres (managed) · **Access:** service role from API only; RLS for any direct client reads · **ORM:** Drizzle (SQL-first migrations) — see ADR-0010

---

## 1. Design rules

1. **Artefacts are immutable once published.** Versions are new rows, never edits (ADR-0004). `UPDATE` permitted only on mutable workflow state columns (`status`, `progress`), never on creative content.
2. **The ledger is append-only.** Credits are never updated in place; balance is a derived view. Holds are rows with lifecycle, not negative balances.
3. **Registry and knowledge tables carry `valid_from`/`evidence_id`** (ADR-0009) so every cost or capability claim traces to an Evidence-Index finding.
4. **Every creative row belongs to a workspace** — all AuthZ is `workspace_id` + role via RLS policies.
5. **Blobs live in R2; Postgres stores pointer + metadata + content hash.**

## 2. Schemas (DDL-level, abbreviated types)

### 2.1 Identity & tenancy
```sql
workspaces(id uuid pk, name text, plan text, confidential boolean default false,
           created_at timestamptz)
workspace_members(workspace_id fk, user_id uuid fk, role text check(role in
           ('owner','director','editor','viewer')), pk(workspace_id,user_id))
```

### 2.2 Creative Director (spec: Creative-Director-Engine.md)
```sql
briefs(id pk, workspace_id fk, title, raw_text, attachments jsonb, status,
       created_by, created_at)
brief_versions(id pk, brief_id fk, version int, structured jsonb,    -- immutable
       assumptions jsonb, open_questions jsonb, created_at)
creative_decisions(id pk, workspace_id fk, brief_version_id fk,      -- decision graph
       parent_id null fk, stage text, kind text,                     -- e.g. tone, format, model_policy
       rationale text, alternatives jsonb, decided_by, decided_at)
plans(id pk, workspace_id fk, brief_version_id fk, version int,      -- compiled plan
       graph jsonb, status text check(status in ('draft','approved','archived')))
cost_estimates(id pk, plan_id fk, registry_snapshot_id fk,           -- pinned registry (ADR-0005)
       currency char(3), total_estimate numeric(12,4), breakdown jsonb,
       tolerance_pct int, created_at)
```

### 2.3 Scene & Continuity (spec: Scene-Continuity-Engine.md)
```sql
scene_states(id pk, workspace_id fk, scene_id text, version int, state jsonb, -- time of day, weather, props…
       supersedes_id null fk, created_at)                                     -- immutable chain
continuity_contracts(id pk, workspace_id fk, scene_state_id fk,               -- rules-as-data
       rule_set jsonb, severity_map jsonb, version int)
continuity_reports(id pk, workspace_id fk, contract_id fk, subject_type text, -- shot | render | edit
       subject_id uuid, verdict text check(verdict in ('pass','warn','fail')),
       findings jsonb, advisory_vlm jsonb null,                                 -- two-layer per ADR-0006
       created_at)
```

### 2.4 Storyboard & Shots (spec: Storyboard-Shot-Planner.md)
```sql
shots(id pk, workspace_id fk, scene_id text, seq int, status text, current_version_id null)
shot_versions(id pk, shot_id fk, version int, framing text, lens_mm numeric,
       movement jsonb, dialogue text, duration_s numeric, refs jsonb,         -- immutable
       content_hash text, created_at)                                          -- hash enables idempotency (ADR-0008)
shot_dependencies(shot_version_id fk, depends_on_id fk, kind text)            -- continuity edges
```

### 2.5 Characters (spec: Character-Intelligence-Engine.md)
```sql
characters(id pk, workspace_id fk, name text, status text, portability jsonb)
character_versions(id pk, character_id fk, version int, identity jsonb,      -- face/voice refs
       wardrobe_sets jsonb, capability_map jsonb,                            -- which models can hold this identity
       reference_sheet jsonb, content_hash text, created_at)                 -- immutable
character_provider_bindings(character_version_id fk, provider text,          -- e.g. Soul-ID-class lock-in tracked
       external_id text, portability_class text)                             -- native | exportable | locked (F-0005 lesson)
```

### 2.6 Cinema Intelligence (spec: Cinema-Intelligence-Engine.md)
```sql
cinematography_records(id pk, workspace_id fk, shot_version_id fk, intent jsonb)
compiled_instructions(id pk, cinematography_record_id fk, provider text, model text,
       classification text check(classification in
       ('native','prompt_approximated','reference_conditioned','unsupported')), -- ADR-0006 honesty
       payload jsonb, honesty_report jsonb, created_at)
```

### 2.7 Brand & Marketing (spec: Brand-Marketing-Intelligence.md)
```sql
brand_profiles(id pk, workspace_id fk, name text, version int, voice jsonb,
       messaging_rules jsonb, visual_rules jsonb, legal jsonb, created_at)   -- immutable versions
compliance_reports(id pk, workspace_id fk, brand_profile_id fk, subject_type text,
       subject_id uuid, verdict text, deterministic_findings jsonb,           -- deterministic-first
       advisory_findings jsonb null, created_at)
```

### 2.8 Workflow Intelligence (spec: Workflow-Intelligence.md)
```sql
workflows(id pk, workspace_id fk, name text, version int, definition jsonb,   -- source definition
       compiled_dag jsonb, content_hash text, status text)                    -- compiled once, hash-pinned (ADR-0008)
workflow_runs(id pk, workflow_id fk, trigger jsonb, status text check(status in
       ('queued','running','awaiting_authorisation','awaiting_gate','failed','complete')),
       budget_cap numeric null, spent numeric default 0, started_at, finished_at)
workflow_tasks(id pk, run_id fk, node_key text, kind text,                    -- intelligence | generation | gate
       idempotency_key text unique, status text, attempt int, input jsonb,
       output jsonb null, cost_estimate_id null fk, created_at)
gates(id pk, run_id fk, node_key text, kind text,                             -- human approval / auto check
       status text, decided_by null, decided_at null, payload jsonb)
```

### 2.9 Orchestration: registry, quotas, ledger, jobs
```sql
model_registry(id pk, provider text, model text, modality text,               -- text|image|video|audio|vlm
       capabilities jsonb,                                                     -- per-capability classification map
       pricing jsonb,                                                          -- unit + rates (per MP/s/image/1k tok)
       free_tier jsonb null,                                                   -- quota type, amount, reset cadence, license flags
       data_policy jsonb,                                                      -- train_on_prompts, retention
       valid_from timestamptz, valid_to timestamptz null, evidence_id text,    -- F-####
       unique(provider, model, valid_from))
provider_accounts(id pk, provider text, label text, auth_ref text,            -- vault reference, never raw key
       concurrency_limit int, status text)
free_quota_windows(id pk, provider_account_id fk, model text null,
       window_start timestamptz, window_end timestamptz, quota jsonb,          -- amount+unit per F-0018..20
       consumed jsonb default '{}', safety_margin_pct int default 20)
ledger_accounts(id pk, workspace_id fk, currency char(3))                     -- customer credit account
ledger_entries(id pk, account_id fk, kind text check(kind in
       ('purchase','hold','charge','release','refund','expiry','adjustment')),
       amount numeric(14,4), ref_type text, ref_id uuid, idempotency_key text unique,
       memo text, created_at)                                                  -- append-only
ledger_holds(id pk, account_id fk, estimate_id fk, amount numeric, status text -- open|settled|released
       check(status in ('open','settled','released')), created_at, settled_at)
render_jobs(id pk, workspace_id fk, task_id fk, provider text, model text,
       registry_snapshot jsonb,                                                -- pinned pricing/capabilities
       frozen_input jsonb,                                                     -- ADR-0007 snapshot
       provider_job_id text null, status text, billed_amount numeric null,
       failure_billable boolean null,                                          -- per provider policy F-0021/22
       created_at, finished_at)
artefacts(id pk, workspace_id fk, kind text, r2_key text, content_hash text,
       bytes bigint, meta jsonb, created_at, unique(kind, content_hash))       -- dedupe by hash
```

## 3. Invariants enforced in DB

| Invariant | Mechanism |
|---|---|
| No silent paid spend | `workflow_tasks` of kind `intelligence` cannot transition to `running` without either free-quota allocation row or an authorised `cost_estimates` row; enforced in service layer + CHECK on status transition trigger |
| Ledger never negative | Balance view + deferred constraint on charge entries; hold must cover charge |
| Immutability of versions | No `UPDATE`/`DELETE` grants on `*_versions`, `ledger_entries`; triggers raise on mutation |
| Registry traceability | `model_registry.evidence_id` NOT NULL; cost estimator rejects snapshots whose registry rows lack `evidence_id` |
| Shot is source of truth | `render_jobs.frozen_input` must equal hash of the referenced `shot_versions` row at enqueue time |

## 4. Indexing & performance

- `(workspace_id, created_at desc)` on all artefact tables — board/table views are workspace-scoped time-ordered reads.
- `content_hash` unique on `artefacts`, `shot_versions`, `character_versions` — idempotency lookups (ADR-0008).
- `model_registry (provider, model, valid_from desc)` — latest-version resolution.
- `ledger_entries (account_id, created_at)` + materialised `ledger_balances` refreshed on entry insert.
- JSONB `GIN` only on queried paths (`state.props`, `capabilities`), not blanket.

## 5. Migrations & lifecycle

- Drizzle migrations, numbered, forward-only; destructive changes via expand-contract.
- Nightly job: reconcile `ledger_entries` vs `render_jobs.billed_amount` vs provider usage APIs (fal usage endpoint, F-0021) → `reconciliation_reports` table; mismatch > $0.01 pages the operator.
- Retention: artefacts in R2 lifecycle rules (temp renders 30 days); Postgres rows retained indefinitely (they are the product's memory).

## 6. What is deliberately NOT in the database

- Provider credentials → vault/env only (`provider_accounts.auth_ref` is an opaque reference).
- Media binaries → R2.
- Ephemeral queue state → Redis (BullMQ), reconstructable from `workflow_tasks` if lost.

---

## 7. Correction Register (v2 — 2026-11-10)

*Added in the correction phase per user review. The v1 sections above remain valid except where superseded here.*

| # | Correction | Supersedes | Normative reference |
|---|---|---|---|
| C-1 | Ledger upgraded from "append-only entries + holds" to **proper double-entry**: transactions with balanced debit/credit postings, chart of accounts, reservation sub-accounts, recipe-validated single write door | v1 §1 rule 2, §3 row "Ledger never negative", §4 ledger bullets | **Credit-Ledger.md** (ADR-0012) |
| C-2 | Asset dedup scoped to **workspace-only**; R2 keys workspace-namespaced; no cross-tenant blob sharing | v1 `artefacts.content_hash` uniqueness note | **Asset-Storage.md** (ADR-0013) |
| C-3 | Provider quota control formalised as **atomic Redis Lua reservations** with leases, window-aligned TTLs, self-tuning limits | v1 §3 row "No silent paid spend" (mechanism now concrete) | **Quota-Reservations.md** (ADR-0014) |
| C-4 | RLS policies written out in full (§8 below) — was referenced but not specified | v1 header note "RLS for any direct client reads" | §8 below |
| C-5 | Migration discipline specified (§9 below) | v1 §5 | §9 below |

## 8. Row Level Security (normative policies)

All tenant tables carry `workspace_id uuid NOT NULL` (registry/system tables are exempt and are read-only to application roles). The API connects with the service role for trusted server operations; any direct client connection (Supabase auto-API, future realtime subscriptions) uses the `authenticated` role with `app.workspace_id` set per request via `SET LOCAL` from the JWT claim.

```sql
-- Helper: current workspace from JWT claim
CREATE OR REPLACE FUNCTION current_workspace() RETURNS uuid AS $$
  SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb ->> 'workspace_id', '')::uuid;
$$ LANGUAGE sql STABLE;

-- Template applied to every tenant table (shown for shots; identical for
-- projects, sequences, scenes, characters, character_sheet_versions,
-- storyboards, frame_candidates, brand_profiles, products, product_assets,
-- campaigns, assets, asset_embeddings, jobs, job_snapshots, dag_versions,
-- dag_nodes, dag_edges, approvals, cost_estimates, usage_reports,
-- continuity_evaluations, brand_evaluations, storyboard_operations,
-- creative_briefs, creative_concepts, production_plans, quota_events):
ALTER TABLE shots ENABLE ROW LEVEL SECURITY;
ALTER TABLE shots FORCE ROW LEVEL SECURITY;   -- applies to table owner too

CREATE POLICY tenant_isolation ON shots
  USING (workspace_id = current_workspace())
  WITH CHECK (workspace_id = current_workspace());

-- Ledger: deny-all to application roles; writes only via SECURITY DEFINER
-- function ledger.post() (Credit-Ledger.md §5)
ALTER TABLE ledger_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ledger_postings    ENABLE ROW LEVEL SECURITY;
CREATE POLICY ledger_read_own ON ledger_transactions
  FOR SELECT USING (workspace_id = current_workspace());
-- (no INSERT/UPDATE/DELETE policies → denied; the post() function runs as
--  the migration role which owns the tables and has FORCE disabled there)

-- Immutable version tables: no UPDATE/DELETE at all
-- (also enforced by trigger; RLS adds a second layer)
CREATE POLICY versions_immutable ON character_sheet_versions
  FOR SELECT USING (workspace_id = current_workspace());
```

Rules:
1. `FORCE ROW LEVEL SECURITY` on every tenant table so even the owning role is subject to policies (defence against future role mistakes); exempted only for the migration role's maintenance connection, which uses a separate login.
2. Every policy is `USING` + `WITH CHECK` — a row can never be written into a workspace the caller doesn't belong to, even by SQL injection reaching raw queries.
3. Junction tables (`shot_characters` etc.) join-scope their policies through the parent (`EXISTS` sub-select on parent `workspace_id`).
4. A CI migration test creates two workspaces and asserts cross-reads/cross-writes return zero rows for every tenant table (generated from the table list).

## 9. Migrations & lifecycle (normative)

- **Tool:** Drizzle Kit migrations (ADR-0010), numbered `0000_init`, `0001_…`, forward-only. Hand-written SQL for anything Drizzle can't express (constraint triggers, RLS, views, functions) — migration files are the source of truth, never the ORM's push mode.
- **Discipline:** every migration ships with its `down`-equivalent documented as an expand/contract plan (no destructive change in one step: add new → backfill → switch reads → drop old across ≥2 migrations). Migrations run in CI against a scratch Postgres before merge; the same artefact runs on staging and prod.
- **Seed data:** registry seeds, diversity vectors, cinema lexicon and eval rubrics are **data migrations** with `evidence_id` references, versioned like code (ADR-0009) — never hand-edited in production.
- **RLS/constraint audit:** CI fails if any new table lacks either (a) `workspace_id` + the policy template, or (b) an explicit exemption note in the migration header.
- **Backup/DR:** per Deployment.md — nightly pg_dump + WAL archiving to R2; quarterly restore drill recorded in `ops/drills.md`.

## 10. Constraint & index additions (v2)

| Object | Addition |
|---|---|
| `ledger_postings` | `CHECK (amount > 0)`; FK to `ledger_accounts`; deferred balance trigger (Credit-Ledger.md §4) |
| `ledger_transactions` | `UNIQUE (idempotency_key)`; `CHECK` forcing `reason`+`operator_id` on adjustments |
| `assets` | `UNIQUE (workspace_id, content_hash, asset_class)` — workspace-scoped dedup (C-2); `CHECK (r2_key LIKE 'ws_' || workspace_id::text || '/%')` enforcing namespacing at the DB layer |
| `jobs` | `quota_reservation_id text`, `provider_ref text` (re-attach after crash), `spend_policy_at_submit text` (audit of the user's rule in force) |
| `quota_events` (new) | `(id, workspace_id, provider, scope, kind, units, reservation_id, created_at)` — audit trail for ADR-0014 |
| `v_workspace_credit_balances` | derived view replaces v1's materialised `ledger_balances` (C-1) |
| All tenant tables | `(workspace_id, created_at DESC)` composite — board views; `assets (workspace_id, asset_class)` for library filters |
| `registry_models` | `UNIQUE (provider, model_version, valid_from)`; `CHECK (honesty_class IN ('native','reference_conditioned','prompt_approximated','unsupported','unknown'))` |
