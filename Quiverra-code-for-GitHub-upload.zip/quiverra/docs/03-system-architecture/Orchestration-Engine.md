# Orchestration Engine

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Draft for gate review
**Scope:** Multi-Provider AI Router, Model Capability Registry, Free-Quota Manager, Credit Ledger, Cost Estimator, provider adapters.

---

## 1. Why this layer exists

Every competitor aggregates models and meters credits (F-0004, F-0010..F-0014). None expose *how* a request was routed, what the model can *natively* do, or what it will cost before commitment (F-0016). This layer is our answer: **routing is explicit, capability-honest, and financially deterministic.**

## 2. Model Capability Registry

The registry is **data, versioned, evidence-backed** (ADR-0009). One row per (provider, model, validity window):

```yaml
# Example rows (values from Evidence F-0017..F-0024, freshness-caveated)
- provider: groq
  model: llama-3.3-70b-versatile
  modality: text
  capabilities: {reasoning: native, json_mode: native, tool_use: native}
  pricing: {unit: per_1m_tokens, input: 0.59, output: 0.79}
  free_tier: {quota: per_model_table, reset: daily, license_ok: true}
  data_policy: {train_on_prompts: false}
  valid_from: 2026-11-10
  evidence_id: F-0018

- provider: fal
  model: kling-3.0-pro
  modality: video
  capabilities:
    text_to_video: native
    image_to_video: native
    motion_brush: prompt_approximated      # honesty classification (ADR-0006)
    last_frame_control: unsupported
  pricing: {unit: per_second, rate: 0.112, audio_extra: separate}
  free_tier: null
  data_policy: {train_on_prompts: provider_default}
  valid_from: 2026-11-10
  evidence_id: F-0021
```

**Maintenance loop:** weekly job re-reads provider pricing pages/APIs (fal exposes a pricing API, F-0021 — preferred path), diffs against current rows, and writes new versions with `valid_from`. Material changes (price >10%, capability downgrade, model deprecation — cf. Veo→Omni-Flash repositioning, F-0024) raise an operator review. Every row needs an `evidence_id`; unverifiable rows are marked `confidence: hypothesis` and are excluded from paid routing by default.

## 3. Router

### 3.1 Request model
Engines never ask for a provider — they ask for a **capability contract**:

```json
{
  "modality": "text",
  "requires": {"json_mode": "native", "context_tokens": 32000},
  "quality_class": "standard",
  "latency_class": "interactive",
  "workspace_confidential": true,
  "spend_policy": "free_preferred"    // free_only | free_preferred | paid_authorised:<estimate_id>
}
```

### 3.2 Selection algorithm (deterministic, logged)
1. **Filter** registry (current valid rows) by modality + required capabilities at `native` classification. If none, widen to `prompt_approximated` and flag the result (honesty badge propagates to the artefact).
2. **Policy screen:** drop rows whose `data_policy.train_on_prompts=true` when `workspace_confidential` (OpenRouter free roster risk, F-0020); drop rows with license-incompatible free tiers for customer deliverables (ElevenLabs free is non-commercial, F-0023 ⇒ internal-only).
3. **Order candidates:** (a) free-quota-available rows, cheapest-latency first; (b) paid rows by unit cost from registry.
4. **Quota check:** Free-Quota Manager confirms headroom with safety margin (default 20% — published limits lie at the edges, F-0018..F-0020 caveat).
5. **Commit:** pin registry snapshot to the job; allocate quota or place credit hold; emit `routing_decision` log row (candidates, scores, reason) — replayable per ADR-0007.
6. **No candidate:** if `spend_policy=free_only`/`free_preferred` and no free capacity → task parks as `awaiting_authorisation`, user notified (Flow C, Overall-Architecture §5). **Never silently route to paid.**

### 3.3 Failover
Provider error → classify: `rate_limit` (rotate to next candidate same class), `server_5xx` (retry same provider ×2 with backoff, then rotate; fal/Replicate don't bill 5xx, F-0021/22 — hold unaffected), `content_refusal` (record; rotate model class, flag to engine), `auth/quota_exhausted` (mark account degraded, rotate, alert operator). Failover may not change the pinned price without re-estimation.

## 4. Free-Quota Manager

- Tracks `free_quota_windows` per provider account/model against published quotas: Groq per-model RPM/RPD (F-0018), Cloudflare 10K Neurons/day (F-0019), OpenRouter 20 RPM & 50/1000 RPD (F-0020), Gemini Flash-only free tier (F-0017, PV — treated conservatively until re-verified).
- Consumption is counted from *our* job log (authoritative), periodically sanity-checked against provider dashboards where APIs exist.
- Windows are derived rows; the manager answers one question: *"can this model take one more request of estimated size X right now?"* with a safety margin.
- Reset cadences are data (daily for Cloudflare/Groq/OpenRouter) so parking flows can tell the user *when* free capacity returns — a UX asset, not just plumbing.

## 5. Credit Ledger

- **Double-entry, append-only** (`ledger_entries`): purchase, hold, charge, release, refund, expiry, adjustment. Balance is a view; holds are explicit rows.
- **Lifecycle of a generation spend:** estimate (registry snapshot) → hold (full estimated amount) → execute → settle:
  - success → `charge` actual (from provider usage/billing record where available, else pinned rate × measured units);
  - provider-verified unbillable failure (fal 5xx, Replicate public failure) → `release`;
  - billable failure (private deployment crash, F-0022) → `charge` + `failure_billable=true` surfaced in UI honesty.
- **Reconciliation:** nightly job compares ledger vs provider usage APIs vs `render_jobs.billed_amount`; variance > $0.01 or >0.5% → operator alert + `reconciliation_reports` row. This is the audit spine competitors don't offer (F-0016).
- **Expiry policy** (customer credits): defined at billing launch — *not* silently copied from competitors' hostile norms (no-rollover, 90-day expiry at Higgsfield, F-0007). Decision deferred to billing/legal definition per the master brief; the schema already supports `expiry` entries.

## 6. Cost Estimator

Deterministic pure function: `(plan graph, registry snapshot) → CostEstimate`. Per task node: unit rate × estimated units (duration for video, MP for images, tokens for text) + declared retry-rate multiplier (per activepieces' pricing guidance, F-0021 source set: price with retries, not single-shot). Output includes per-line evidence references and `tolerance_pct`; runs exceeding estimate × tolerance auto-pause for authorisation (`estimate.exceeded` event). The estimator is a library used by both API (previews) and workers (pre-flight), never duplicated.

## 7. Provider adapters

One interface, thin per-provider implementations:

```ts
interface ProviderAdapter {
  capabilities(): RegistryRows;            // used by registry maintenance
  estimate(task, registryRow): CostLine;   // provider-specific unit math
  submit(frozenInput, registrySnapshot): ProviderJobHandle;
  poll(handle): JobStatus;                 // normalised: queued|running|succeeded|failed(billable?)
  usage(since): UsageRecord[];             // for reconciliation (fal: supported; others best-effort)
}
```

Adapters contain **no creative logic and no pricing constants** — pricing comes from registry rows. Adding a provider = adapter + registry rows + evidence entry. (Design consequence of F-0022: expect Cloudflare/Replicate consolidation to merge two adapters into one eventually; keep them separate until pricing actually merges.)

## 8. Failure & edge-case matrix (operator-facing)

| Case | Behaviour | User-visible |
|---|---|---|
| All free LLM capacity exhausted | Park task, notify with reset times | "Free capacity returns ~HH:MM. Authorise paid (~₹X) or wait." |
| Paid authorised, provider 5xx storm | Rotate providers, then pause run after N rotations | Run status + incident note |
| Registry price drift mid-run | Run continues at pinned snapshot; drift logged; next estimate uses new row | "Priced as of …" on receipt |
| Model deprecated by provider | Registry `valid_to` set; affected workflows flagged at compile time | Migration suggestion in UI |
| Provider free tier withdrawn (cf. Sora API exit, F-0024) | Rows invalidated same day; router redistributes; roadmap note | Changelog + in-app notice |

## 9. What this layer deliberately does not do

- No creative judgement (that's the engines); no prompt rewriting beyond capability compilation (Cinema Engine owns that).
- No cross-customer quota pooling tricks that violate provider ToS — free tiers are used within published terms.
- No shadow mode silently spending paid "to keep UX smooth" — forbidden by the master brief and by ADR-0005.
