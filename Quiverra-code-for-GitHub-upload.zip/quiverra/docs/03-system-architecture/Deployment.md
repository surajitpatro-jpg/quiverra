# Deployment Architecture

**Version:** 1.1 · **Date:** 2026-11-10 · **Status:** Updated post-gate (ADR-0021: Supabase Mumbai + residency register)
**Target (per master brief):** Hostinger VPS + Docker · **External managed services:** Supabase (Postgres + Auth), Cloudflare R2
**Environment caveat:** the build sandbox has no Docker (KI-02) and no persistent processes (KI-04) — everything here is specified for execution on the VPS/CI, and nothing in Phase 6 may be marked "deployed/tested" from this sandbox.

---

## 1. Topology

```
                 ┌──────────── Cloudflare (DNS + TLS + R2) ───────────┐
Internet ───────▶│  Caddy/Nginx reverse proxy (TLS termination)        │
                 │            │                                        │
                 │     ┌──────┴───────┐                                │
                 │     ▼              ▼                                │
                 │  web (Next.js)   api (Node/TS monolith)             │
                 │     │              │                                │
                 │     │      ┌───────┼───────────────┐                │
                 │     │      ▼       ▼               ▼                │
                 │     │  worker-intel  worker-gen   scheduler         │
                 │     │      │       │               │                │
                 │     │      └───────┴──── Redis ◀───┘                │
                 └─────┼──────────────┬────────────────────────────────┘
                       ▼              ▼
              Supabase (Postgres+Auth)   R2 (media/artefacts)
                       ▲
              provider APIs (outbound only)
```

One VPS, Docker Compose (v2). No orchestrator in MVP — Compose restart policies + healthchecks suffice; Kubernetes would be resume-driven complexity, not need-driven.

## 2. Services (compose inventory)

| Service | Image base | Replicas (MVP) | CPU/RAM budget | Notes |
|---|---|---|---|---|
| `proxy` | caddy:2 | 1 | 0.25 / 128MB | TLS, security headers, rate-limit preamble |
| `web` | node:22-alpine build | 1 | 0.5 / 512MB | Next.js standalone output |
| `api` | node:22-alpine build | 1 | 1.0 / 1GB | gateway + domain services + scheduler |
| `worker-intel` | same image as api | 2 | 0.5 / 512MB ea | q.intel consumers |
| `worker-gen` | same image as api | 2 | 0.5 / 512MB ea | q.gen consumers; provider-concurrency-limited, not CPU |
| `redis` | redis:7-alpine | 1 | 0.25 / 256MB | BullMQ; AOF everysec |
| `clamav` | clamav/clamav | 1 | 0.5 / 1GB | upload scanning (Security §5) |
| `otel-collector` + `prometheus` + `grafana` | official | 1 each | 0.5 / 1.5GB total | observability stack |

MVP VPS recommendation: **4 vCPU / 16 GB / 160 GB NVMe** (Hostinger KVM 4 class) — headroom for observability + clamav without contention. Media workload is outbound-API-bound; CPU stays mostly idle.

## 3. Environments & promotion

| Env | Where | Data | Purpose |
|---|---|---|---|
| `dev` | contributor machines / sandbox (Node 22 bootstrap, KI-03) | seeded fixtures, mock provider adapters | unit + integration tests |
| `staging` | same VPS, separate compose project + separate Supabase project + R2 bucket | synthetic only | pre-release verification, restore drills |
| `prod` | VPS compose project `prod` | real | launch |

Promotion: git tag → build images on VPS (or GitHub Actions once mirroring works, KI-01) → deploy staging → run smoke suite (Phase 7) → deploy prod with tagged images. **Rollback = re-deploy previous tag** (images retained); DB is forward-only migrations so rollback never needs schema reversal within a compatibility window.

## 4. CI/CD (designed for post-mirroring)

Sandbox cannot push to GitHub (KI-01); user mirrors `creative-platform/` to `surajitpatro-jpg/quiverra` (ADR-0001, updated 2026-11-10). Once mirrored, GitHub Actions:

1. `ci.yml`: lint, typecheck, unit tests, `gitleaks`, build.
2. `integration.yml`: spin compose (docker-compose in GH runner) with mock adapters; run API + workflow integration suite; **tests must actually execute to count** (verification doctrine).
3. `deploy.yml` (manual trigger): rsync compose bundle + env template to VPS over SSH; `docker compose pull/up`; run migrations; health gate.

Secrets live in GitHub Environments + VPS env files — never in the repo (brief constraint).

## 5. Configuration & env matrix

| Var | web | api | workers | Notes |
|---|---|---|---|---|
| `NEXT_PUBLIC_API_URL` | ✓ | | | only non-secret config reaches browser |
| `SUPABASE_URL` / `SUPABASE_ANON_KEY` | ✓ | ✓ | | anon key is safe by design (RLS) |
| `SUPABASE_SERVICE_ROLE_KEY` | | ✓ | | server-only |
| `REDIS_URL` | | ✓ | ✓ | |
| `R2_*` | | ✓ | ✓ | signed-URL minting |
| `PROVIDER_KEY_<NAME>` | | | ✓ | workers only; referenced as `auth_ref` in DB |
| `RAZORPAY_*` / `CASHFREE_*` | | ✓ | | present but inert until payment activation gate |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | | ✓ | ✓ | |

## 6. Networking & exposure

- Public ingress: 443 only, via proxy. `api` exposes `/api/*` + `/ws`; `web` everything else. Redis, Prometheus, Grafana, ClamAV on the internal network only; Grafana behind proxy basic-auth for operators.
- Outbound: unrestricted HTTPS (provider APIs). Egress allowlist is premature at MVP (providers change endpoints; registry is the control point instead).
- IPv4 + IPv6; Caddy handles cert renewal.

## 7. Backups, restore, DR

- **Postgres:** Supabase PITR if plan allows; else nightly `pg_dump | zstd` → R2 `backups/` prefix, 30-day retention. **Quarterly restore drill to staging is required** — untested backups are treated as absent (verification doctrine).
- **Redis:** AOF; loss acceptable by design (queues rebuild from Postgres, Workflow-Execution §8).
- **R2 artefacts:** versioning enabled on the bucket; lifecycle: temp renders 30d, published artefacts indefinite.
- **VPS failure:** rebuild = provision new VPS → install Docker → pull repo bundle → restore env files (stored offline by owner) → point DNS → run migrations → restore latest backup. Target RTO 4h, RPO 24h (nightly backups) for MVP; documented in runbook, tested during Phase 7 staging drill.

## 8. Observability & alerting (deployment-side)

- Prometheus scrapes api/workers (BullMQ metrics exporter), node-exporter, cAdvisor.
- Grafana dashboards: request rates/latency, queue depth, provider error rates, free-quota burn-down, ledger reconciliation status, estimate drift.
- Alerts (Grafana → email/Telegram to operator): disk >75%, container restart loops, reconciliation variance, provider 5xx rate >10%/10min, queue depth growth >30min.
- Logs: JSON to stdout → collected via Docker logging driver → Loki (compose) with 14-day retention.

## 9. Data residency register (ADR-0021)

**Decision:** Supabase project region = **Mumbai (AWS ap-south-1)** for both production and staging. This places the primary database at rest in India. It does **not** by itself guarantee DPDP compliance, and no document or UI may claim it does (user instruction).

| Data class | Location / processor | Cross-border? | Notes |
|---|---|---|---|
| Postgres (artefacts, ledger, registry, users) | Supabase Mumbai (ap-south-1) | No (at rest) | PITR/backups stay in-region per Supabase plan; verify at setup |
| Media blobs | Cloudflare R2 | **Verify at bucket creation** — pin location if the plan allows; otherwise register actual location | Backups to R2 inherit this entry |
| Auth tokens / user identity | Supabase Auth (same project region) | With Postgres | — |
| Content sent to AI providers | fal.ai / Google (Gemini) / Groq and future providers process on **their own infrastructure, potentially outside India** | **Yes — disclosed per provider** | Router-level disclosure UX (ADR-0020) states this before first use per provider; confidential workspaces only use providers meeting ADR-0020 conditions |
| Redis/queue state | On the VPS (India-region Hostinger DC if available at purchase; register actual DC) | Verify at purchase | Ephemeral control plane, no customer content at rest |
| Transactional email | Provider TBD at setup | Register when chosen | Contains no project content |
| Observability (logs/metrics) | Self-hosted on the VPS (Loki/Grafana) | No | Logs must not contain provider payloads (Security §2 scrubbing) |

The register is **living**: reviewed and updated whenever a provider or service is added (registry seed checklist includes a residency row).

## 10. Cost envelope (indicative, to be priced before purchase — Unknown until quoted)

| Item | Class | Notes |
|---|---|---|
| Hostinger KVM 4-class VPS | fixed monthly | 4vCPU/16GB assumption above |
| Supabase | free tier → Pro as data grows | PITR requires paid plan — decision at launch |
| Cloudflare R2 | near-zero (no egress fees) | Class A/B ops only at MVP volume |
| Domain + email | fixed | — |
| Provider spend | variable | governed by Credit Ledger, not infra budget |

These are planning figures, not verified quotes — marked **U** per methodology until checked at purchase time.

## 11. Launch checklist hook

Phase 7 consumes this doc as a checklist: every § becomes a verification item (TLS config tested, restore drill executed, alert fired in anger, payment dormancy verified, key-exposure scan clean). Nothing ships on assertion.
