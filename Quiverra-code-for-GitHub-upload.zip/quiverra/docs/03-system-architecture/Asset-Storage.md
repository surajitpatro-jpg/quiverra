# Asset Storage & Tenancy

**Version:** 2.0 · **Status:** Corrected design · **ADR:** 0013 · **Date:** 2026-11-10
**Correction driver:** user review — multi-tenant asset storage and deduplication must prevent cross-workspace conflicts and exposure.

---

## 1. Tenancy model

- **Isolation unit = workspace.** Every asset, blob, embedding, thumbnail and derived artefact belongs to exactly one workspace. There is no shared blob pool.
- **R2 layout is workspace-namespaced:** `r2://<bucket>/ws_<workspace_id>/<asset_class>/<asset_id>/<version>/<filename>`. The workspace segment is mandatory; the worker rejects any key not matching the caller's workspace prefix. Presigned URLs are minted only for keys under the requesting workspace's prefix, short-lived (≤15 min), single-purpose (PUT or GET), and bound to the asset ID in the request.
- **No cross-workspace deduplication — ever.** The earlier draft's content-hash dedup is retained **only within a workspace**. Two workspaces uploading byte-identical files store two objects. This costs storage (cheap: R2 $0.015/GB-month class) and buys: zero cross-tenant exposure surface, trivial GDPR/DPDP erasure (delete the prefix), no "whose object is canonical" ownership puzzles.

## 2. Workspace-scoped deduplication (the corrected rule)

```sql
CREATE TABLE assets (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id   uuid NOT NULL REFERENCES workspaces(id),
  content_hash   bytea NOT NULL,                  -- sha256 of the blob
  asset_class    text NOT NULL,                   -- upload|reference|frame|video|audio|composite|export
  r2_key         text NOT NULL UNIQUE,            -- always ws_<id>/… prefixed
  bytes          bigint NOT NULL,
  mime           text NOT NULL,
  status         text NOT NULL DEFAULT 'active',  -- active|quarantined|deleted
  created_by     uuid NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, content_hash, asset_class)  -- dedup scope = workspace
);
```

- Upload flow: client requests upload URL → API computes nothing; worker receives the completed blob, hashes it, and on `(workspace_id, content_hash, asset_class)` match returns the **existing asset row** and deletes the duplicate blob. Deduplication is a storage optimisation only; logically each upload still yields the caller an asset they "own".
- The unique key includes `workspace_id`, so hash collisions across tenants are structurally impossible to conflate.
- Malware scanning (ClamAV per Deployment.md) gates `status`: blobs are `quarantined` until scanned clean; presigned GETs are refused for non-`active` assets.

## 3. Derived artefacts follow the same rule

Thumbnails, proxies, embeddings and evaluation outputs reference `asset_id` (which is workspace-scoped) and are stored under the same workspace prefix. The continuity engine's pgvector table (`asset_embeddings`) carries `workspace_id` with RLS like every other tenant table — similarity search is always filtered `WHERE workspace_id = current_workspace()` before any vector ordering, enforced by policy, not by remembering to add the predicate in app code.

## 4. Deletion & erasure

- User deletes an asset → row `status='deleted'`, blob deleted from R2; if other rows in the **same workspace** reference the blob (dedup hits), deletion is refused until references are removed (reference count from the unique-key cohort).
- Workspace erasure (DPDP/GDPR) → delete `ws_<id>/` prefix recursively, then the DB rows. Because nothing is shared, erasure is a prefix operation with no side effects on other tenants. Provider-side copies are governed per provider contract: Replicate API data auto-deletes in 1 hour (F-0043); fal payloads deletable via Delete Request Payloads API and suppressed via `X-Fal-Store-IO: 0` (F-0042) — the worker issues provider-side deletion calls on erasure and records completion.

## 5. Provider-egress minimisation (privacy by routing)

- Confidential workspaces (Security.md) force `X-Fal-Store-IO: 0` on all fal calls, exclude `trains_by_default` registry rows (Gemini free, OpenRouter `:free`, ElevenLabs default — F-0044/F-0045/F-0020), and prefer providers with deletion guarantees.
- Reference media sent to providers is always the **minimum set** the model schema accepts (e.g. Kling Motion Control API takes exactly one character ref, F-0031) — the adapter sends one, not the whole sheet.
