# Milestone Report — W0 + W1 (for review before W2)

**Date:** 2026-11-10 · **Scope:** Phase 6 workstreams W0 (repository foundation) and
W1 (database foundation) · **Status:** complete and verified locally; **held for your
review per the execution conditions — no further milestones will be started until approved.**

Everything below was built and executed against real tooling in the development
environment: PostgreSQL 15.19 (system service), Node 20.20.2, npm workspaces,
Vitest, ESLint 9, Prettier, Next.js 15.5.29 build. Nothing is marked complete on
the basis of generated code alone; items that could not be exercised here are
listed under §7.

---

## 1. Files and modules created

All under `creative-platform/` (git initialised, branch `main`, 4 commits):

**W0 — repository scaffold (`application/`)**

- `package.json` / `package-lock.json` — npm workspaces root; scripts for
  dev/build/typecheck/lint/format/test/db lifecycle.
- `tsconfig.base.json` — TypeScript 5.6 `strict` + `noUncheckedIndexedAccess` +
  `exactOptionalPropertyTypes`.
- `eslint.config.mjs` — ESLint 9 flat config, typescript-eslint `strict`,
  hard rules `no-eval`, `no-implied-eval`, `no-explicit-any`
  (test-file override for non-null assertions only).
- `.prettierrc.json`, `.prettierignore`, `.gitignore` (env files, keys, `secrets/`,
  build output ignored), `.gitleaks.toml`.
- `.env.example` — every variable documented, placeholders only; provider keys
  commented out until their milestone; `PAYMENTS_ENABLED=false`,
  `INTELLIGENCE_PAID_CEILING_INR=0`.
- `.github/workflows/ci.yml` — gitleaks → `postgres:15` service → `npm ci` →
  lint → typecheck → test → build on push/PR.
- `packages/config/` — Zod-validated environment loader (`src/index.ts`) that
  fails closed on missing secrets and **throws if payments are enabled in
  development**; browser-safe public subset separated from server secrets.
  3 unit tests (`test/env.test.ts`).
- `apps/api/` — Fastify 5 skeleton: `GET /healthz`, `GET /version`
  (exposes `paymentsEnabled: false`, `intelligencePaidCeilingInr: 0` so a
  misconfigured deployment is immediately visible). 2 inject tests.
- `apps/web/` — Next.js 15 + React 19 App Router shell page listing the
  production pipeline stages; production build verified (4/4 static pages).
- `application/SETUP.md` — setup, migration discipline, verification, deployment
  topology, troubleshooting.

**W1 — database foundation (`application/packages/db/`)**

- `src/schema.ts` — Drizzle definitions: 7 enums, 10 tables
  (`workspaces`, `memberships`, `profiles`, `projects`, `creative_briefs`,
  `assets`, `ledger_accounts`, `ledger_transactions`, `ledger_postings`,
  `audit_log`).
- `migrations/0000_w1_foundation.sql` — generated DDL (tables, constraints,
  indexes, the `assets.r2_key` workspace-prefix CHECK, workspace-scoped dedup
  `UNIQUE(workspace_id, content_hash, asset_class)`).
- `migrations/0001_policies_and_functions.sql` — hand-written custom SQL:
  auth stub, roles, tenant-context functions, RLS + FORCE on all 10 tenant
  tables, grants, audit triggers, ledger immutability triggers, balanced-postings
  deferred constraint trigger, 8 system ledger accounts, derived-balance view,
  `app.provision_workspace()`, and the single write door **`ledger.post()`**
  implementing all recipes R1–R10.
- `src/index.ts`, `src/migrate.ts` — postgres.js + Drizzle client and a
  forward-only migration runner.
- Test suite (`test/`): `migrations.test.ts` (3), `rls.test.ts` (6),
  `assets.test.ts` (3), `audit.test.ts` (3), `ledger.test.ts` (12), shared
  fixtures/helpers, fresh-database global setup.

**Preservation check:** all prior research, evidence (F-0001…F-0045), specs,
ADRs and planning documents are untouched — the first commit contains them
unchanged alongside the new scaffold.

## 2. Architecture decisions made

No new decisions were taken beyond the ratified ADRs; W0/W1 **implements**
existing ones:

- **ADR-0012 (double-entry ledger):** realised as SQL — chart of accounts, two
  currency domains linked by `link_group`, recipes R1–R10 inside
  `ledger.post()` (SECURITY DEFINER, the only write path), deferred constraint
  trigger rejecting unbalanced transactions at commit, balances derived from
  postings (never stored), idempotency by unique key with replay returning the
  original transaction, advisory-lock-serialised reservations raising
  `INSUFFICIENT_CREDITS` before any posting.
- **ADR-0013 (workspace-scoped assets):** `r2_key` must match
  `ws_<workspace_id>/%` (DB CHECK), dedup unique per workspace, no cross-tenant
  sharing, new assets default to `quarantined` pending the scan gate.
- **ADR-0014 (atomic reservations):** ledger-side reservation primitive is in
  place; the Redis quota windows themselves arrive with providers in W5.
- **ADR-0015 (OpenAPI):** contract already validated in Phase 5; the API
  skeleton is positioned to implement against it.
- **ADR-0016/0019 (MVP, deferred commercials):** `PAYMENTS_ENABLED=false`
  enforced at boot; no purchase endpoints exist.
- **ADR-0018 (₹0 paid-LLM ceiling):** `INTELLIGENCE_PAID_CEILING_INR=0` is a
  validated env setting with test coverage.
- **ADR-0020 (confidential default ON):** `workspaces.confidential` defaults
  `true`; RLS isolates everything workspace-scoped.
- **ADR-0021 (Mumbai residency):** deployment target documented in SETUP.md;
  nothing deployed yet.

## 3. Database schema and migrations

**Live-verified shape (from the migrated test database):**

- 10 tables, all with `ENABLE` + `FORCE ROW LEVEL SECURITY`
  (confirmed: `relrowsecurity=t, relforcerowsecurity=t` for every table).
- 9 RLS policies: `tenant_isolation` on workspaces/memberships/projects/
  creative_briefs/assets, `tenant_isolation_select` on audit_log,
  `own_profile` on profiles, `ledger_read_own` on ledger_transactions,
  `ledger_accounts_read` on ledger_accounts. **ledger_postings has no policy —
  deny-all direct access.**
- Ledger: append-only (UPDATE/DELETE triggers raise), balanced-postings enforced
  by a `DEFERRABLE INITIALLY DEFERRED` constraint trigger at commit, adjustments
  require reason + operator (CHECK), idempotency keys unique.
- Assets: r2-key prefix CHECK and per-workspace dedup verified by rejection tests.

**Migration files (for your review):**

- `application/packages/db/migrations/0000_w1_foundation.sql` (generated, 206 lines)
- `application/packages/db/migrations/0001_policies_and_functions.sql` (hand-written,
  ~480 lines — RLS, grants, triggers, view, both SECURITY DEFINER functions with
  full recipe logic)
- Journal + snapshots under `migrations/meta/` so `drizzle-kit migrate` applies
  both in order; runner: `packages/db/src/migrate.ts`.

## 4. Tests actually executed, and results

Executed 2026-11-10 against PostgreSQL 15.19 (fresh `platform_w1_test` database
dropped/recreated and fully migrated by the test harness each run):

| Suite                                   | Tests | Result |
| --------------------------------------- | ----- | ------ |
| `packages/db` migrations                | 3     | ✅ pass |
| `packages/db` RLS isolation             | 6     | ✅ pass |
| `packages/db` asset isolation           | 3     | ✅ pass |
| `packages/db` audit logging             | 3     | ✅ pass |
| `packages/db` ledger recipes+invariants | 12    | ✅ pass |
| `packages/config` env validation        | 3     | ✅ pass |
| `apps/api` health/version               | 2     | ✅ pass |
| **Total**                               | **32**| **✅ 32/32** |

Notable coverage: cross-tenant SELECT invisibility and WITH CHECK insert
rejection; shared-member context isolation; ledger idempotent replay;
reservation overflow rejected with `INSUFFICIENT_CREDITS`; settlement with USD
recognition leg; unbalanced postings rejected at commit; ledger immutability;
balance view readable only for own workspace; and a **400-operation seeded
property test** (random issuance/reserve/settle/release/expiry sequences)
asserting after every operation: `available ≥ 0`, `reserved ≥ 0`, and model-vs-DB
drift = 0.

Also executed: `npm run lint` (clean), `npm run format:check` (clean),
`npm run typecheck` (clean, all 4 workspaces), `npm run build`
(Next.js production build ✅, API `tsc` build ✅).

Three defects were found by these tests and fixed during the milestone (audit
trigger field access on tables without `workspace_id`; plpgsql compile-time
field validation in the same trigger; one test using a constrained transaction
kind). Details are in git history.

## 5. Security checks performed

- **Secrets:** repo contains no credentials — `.env.example` placeholders only;
  manual pattern scan (API keys, private keys, passwords) clean; `.gitignore`
  blocks all env files/keys; gitleaks runs in CI (config present).
- **RLS:** FORCE ROW LEVEL SECURITY on all 10 tables (table owner included);
  cross-tenant tests pass, including as a shared member.
- **Ledger write path:** single SECURITY DEFINER door; EXECUTE revoked from
  PUBLIC and granted only to `authenticated` (same for provisioning);
  `ledger_postings` has no grant and no policy.
- **Payments:** no purchase/grant endpoints; boot-time refusal of
  `PAYMENTS_ENABLED=true` in development, with a test.
- **Confidentiality default:** `workspaces.confidential` defaults to true.
- **Audit:** triggers capture actor (from JWT claim), action, before/after JSON
  on workspaces, memberships, projects, assets.

## 6. Known issues / limitations

1. **Supabase parity is emulated, not real.** Local tests stub `auth.users` and
   inject JWT claims via `SET LOCAL request.jwt.claims`. The same SQL is written
   to be no-op-safe on Supabase, but it has not been run against a real Supabase
   (Mumbai) project yet.
2. **SECURITY DEFINER functions rely on the function owner bypassing RLS.**
   Locally the owner is superuser; on Supabase the `postgres` role has
   `BYPASSRLS`. Behaviour is equivalent, but must be re-verified on first
   Supabase deploy (planned smoke test at W2 start).
3. **CI has not executed on GitHub.** The workflow is committed; the first real
   run happens when you mirror the repo. Steps mirror exactly what was run
   locally and passed.
4. **`creative_briefs` is the only creative-stage table so far.** Script,
   storyboard, shot-plan and generation-job tables arrive with their workflow
   milestones (W3–W6), per the roadmap.
5. Web workspace has no tests yet (shell page only); `passWithNoTests` is set.

## 7. Remaining dependencies

- **Your GitHub mirror:** repo is committed locally at
  `creative-platform/` (4 commits); push to `quiverra` when convenient —
  no secrets are present.
- **Supabase project (Mumbai/ap-south-1):** needed at W2 for managed auth +
  hosted database; no account exists yet (per staged onboarding, ADR-0017).
- **Redis (Upstash):** first needed at W5 quota windows; not required before.
- **Provider accounts:** Gemini/Groq/fal/R2 as milestones approach; none needed
  for W2–W4 beyond mock adapters.
- **ElevenLabs:** deferred to W13, gated on verified data-use opt-out.

## 8. Running locally

Full instructions in `application/SETUP.md`. Short version:

```bash
cd creative-platform/application
npm install
cp .env.example .env                       # fill values; never commit
createdb platform_dev
DATABASE_URL=postgres://postgres:postgres@localhost:5432/platform_dev \
  npm run db:migrate --workspace packages/db
npm run dev:api    # :4000  GET /healthz  GET /version
npm run dev:web    # :3000
```

Verify: `npm run lint && npm run typecheck && npm run build`, and
`DATABASE_URL=postgres://postgres:postgres@localhost:5432/platform_w1_test npm run test`
(32 tests; the DB suite recreates the test database itself).

## 9. What requires your approval next

1. **This W0+W1 review** — schema, migrations, RLS policies and test results
   (§3–§4). W2 will not start until you approve.
2. **W2 scope (proposed):** authentication + workspace onboarding against real
   Supabase (Mumbai) — sign-up/login, session handling, workspace provisioning
   via `app.provision_workspace()`, membership management, and the first
   authenticated API routes, wiring the W1 foundation into a usable sign-in
   flow. This is the first milestone requiring a Supabase account; it can begin
   with local emulation if you prefer to create the project later.
3. **Confirmation of staging order** for W3+: the working creative pipeline
   first (Brief → Concepts → … → Asset Management), per your direction, with the
   seven intelligence systems integrated along that path rather than built
   independently.
