# Development Roadmap — Solo Founder / Small Team

**Version:** 1.1 · **Date:** 2026-11-10 · **Status:** Approved at gate (ADR-0016) — with staged provider onboarding (ADR-0017) and ₹0 paid-LLM ceiling (ADR-0018) applied below
**Planning basis:** one primary developer (the founder) + AI coding agents as force multiplier. Estimates in **elapsed weeks**, assuming ~20–25 focused hours/week of founder time. Ranges reflect real uncertainty; nothing here is a promise.

---

## 1. Build classification (what AI agents can and cannot do)

| Class | Definition | Examples in this project |
|---|---|---|
| **A — Agent-buildable** | CRUD surfaces, typed clients, UI screens from specs, schema-driven forms, standard integrations with verified contracts | OpenAPI client scaffolding; Drizzle schema from DDL; storyboard board components; asset library UI; auth screens; provider adapter skeletons from documented APIs (fal/Replicate/Gemini/ElevenLabs) |
| **B — Agent-assisted, human-verified** | Logic with correctness contracts where agents write, humans review against the spec's test contract | Ledger `post()` function + recipes; quota Lua script; prompt assembler; estimator; DAG invalidation; reconciler sweeper |
| **C — Substantial engineering** | Multi-system integration, failure-mode work, anything needing judgement under real-provider behaviour | Webhook/poll/reconcile convergence under real provider quirks; ElevenLabs self-tuning concurrency; continuity eval thresholds; estimate calibration; staging recovery drills (§10.5) |
| **D — Manual, not automatable** | Accounts, keys, legal, money | Provider account setup + free-tier activation; ElevenLabs training opt-out; spend authorisations; privacy/refund policy writing; payment-gateway compliance (dormant anyway) |

Honest ratio: roughly **55 % A / 25 % B / 15 % C / 5 % D** by effort. AI agents compress calendar time on A and B; they do not remove C, and C is where launch risk lives.

## 2. Workstreams & timeline

| # | Workstream | Class | Elapsed | Dependencies |
|---|---|---|---|---|
| W0 | Repo scaffold, CI (typecheck, lint, migration runner, contract-test harness), env matrix | A | ½ wk | Approval of this plan |
| W1 | DB foundation: Drizzle schema + migrations for full DDL (incl. ledger, RLS policies, triggers, views) + migration audit test | B | 1 wk | W0 |
| W2 | Ledger core: `post()` recipes R1–R10, balance view, property/replay/recovery tests | **C** | 1½ wk | W1 |
| W3 | Registry: schema, seed data with evidence IDs, snapshot pinning, staleness badges; weekly refresh job | B | 1 wk | W1 |
| W4 | Quota layer: Lua reservations, limits-refresh, fail-closed tests, ElevenLabs header feedback | **C** | 1½ wk | W3 |
| W5 | Provider adapters — **staged (ADR-0017):** fal (image+video), Gemini (LLM+video), Groq (LLM) behind `capabilities/estimate/submit/poll/usage`. Replicate + ElevenLabs adapters deferred until required (ElevenLabs additionally gated on opt-out verification — class D) | A→**C** | 2 wk | W3, W4; provider accounts (D) |
| W6 | Orchestration: router (filter→policy→order→quota→commit), estimator, Free-Quota Manager, spend-policy enforcement | **C** | 1½ wk | W3–W5 |
| W7 | Job execution: queues, idempotency, sweeper, webhook endpoints, crash re-attach, recovery drills | **C** | 2 wk | W5 |
| W8 | API layer: implement openapi.yaml routes; contract tests in CI | A/B | 1½ wk | W1 (parallel with W4–W7) |
| W9 | Intelligence pipeline: brief→interpretation→concepts→plan chain (schema gates, diversity vectors, q.intel) | B | 1½ wk | W8 |
| W10 | Character engine: canonical descriptions, sheet batches, screening, bindings | B | 1½ wk | W9, W5 |
| W11 | Storyboard + shot planning: board UI, ops log, fractional indexing, DAG compile/invalidation, feasibility badges | B→**C** | 2½ wk | W9 |
| W12 | Generation UX: estimates UI, batch approvals, frames/alternates, selective regeneration, continuity flags display | A/B | 2 wk | W11, W6 |
| W13 | Asset management: upload flow (presign+scan), library, lineage, export assembly | A/B | 1½ wk | W12 |
| W14 | Hardening: load smoke, security review vs Security.md, privacy routing tests, DPDP erasure drill, docs | C/D | 1½ wk | All |

**Critical path:** W0→W1→W2/W3→W4→W5→W6→W7→W12→W14. **Total elapsed estimate: 13–17 weeks** with parallelisation (W8/W9 overlap W4–W7). A second engineer or a higher weekly hour budget compresses W11–W13, not W2/W4/W7 (those are understanding-bound, not typing-bound).

### Deferred-provider insertion points (ADR-0017)

- **Replicate adapter** — enters when M4 needs a second image route or M5 needs Kling-via-Replicate fallback; expected insertion: during W12 if fal reliability or cost data justifies it.
- **ElevenLabs adapter (audio/voiceover)** — enters at W13 (export assembly needs VO); **precondition chain (class D, owner action):** create account → apply data-use opt-out → **verify the setting is active** → only then submit any project content (the setting is prospective only, F-0045). Voiceover is the last pipeline feature to land, so this deferral has zero critical-path cost.
- **Specialist video routes (Kling direct, Runway Dev)** — enter post-M6 when fal's Kling pricing/concurrency data justifies a direct contract or Kling 4.0-class availability matters.

## 3. Milestones (verifiable gates)

| Milestone | Target week | Gate — what must be demonstrably true |
|---|---|---|
| M1 Ledger + DB foundation | wk 3 | Property/replay/recovery tests green in CI; RLS cross-tenant test proves isolation; migrations run clean on scratch Postgres |
| M2 Router + quota + one live adapter | wk 6 | Real fal call executed from worker through reservation→settlement with ledger entries visible; free-quota exhaustion demonstrably parks a job |
| M3 Intelligence pipeline | wk 8 | Brief→3 concepts→approved plan runs at $0 on free tiers (Gemini + Groq); schemas enforced; decisions logged |
| M4 Storyboard-to-frames | wk 11 | Full board editing; frame batch with alternates + selective regen; estimate shown before spend; estimate-vs-actual recorded |
| M5 Video + export | wk 14 | Shot clips generated via capability-translated controls (fal routes; Replicate adapter only if inserted per §deferred-provider points); final assembly export of a 30 s project (VO via ElevenLabs **only after opt-out verification**, else export ships video+music-bed and VO lands next iteration) |
| M6 Launch candidate | wk 15–17 | Recovery drills (§10.5) executed and recorded; security checklist signed; E2E journey suite green on staging |

## 4. Risks to the timeline (honest)

1. **Provider account/limits friction** (fal concurrency starts at 2, Gemini prepay $5) — create the four initial accounts (Gemini, Groq, fal, Cloudflare) in week 1 even though needed later (class D; ADR-0017 staged set).
2. **Free-tier intelligence quality** may force the paid-LLM benchmark path (ADR-0018): if insufficiency is observed, produce the quality/latency/cost benchmark and present it with a recommended budget — never self-authorise. The ₹0 ceiling stands until the user approves otherwise.
3. **Continuity eval calibration** (thresholds) is open-ended; timeboxed by shipping conservative flag-only behaviour in M4 and tuning with real data.
4. **Scope discipline**: every "quick extra" (brand scoring, scheduling) is a post-MVP phase by definition — the roadmap protects the one-workflow promise.

## 5. What I will NOT do during implementation

No silent rerouting to paid providers · no claiming tests passed that were not executed · no live payment activation · no skipping M-gate verification to hit dates — gates move, honesty doesn't.
