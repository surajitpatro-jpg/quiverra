# Feature Acceptance Criteria

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Proposed — each criterion maps to a test layer (Testing-Strategy §1). "Verified" means executed, with CI run / drill record linked.

---

## Stage 1 — Creative Brief
- AC-1.1: Given any brief text, the system returns a schema-valid interpretation; fields below confidence threshold produce ≤5 targeted questions. *(Unit + E2E G1)*
- AC-1.2: Skipping all questions still allows progression; defaults are visibly marked as assumptions. *(E2E)*
- AC-1.3: Brief edits create new versions; prior versions retrievable. *(Integration)*

## Stage 2 — Creative Concepts
- AC-2.1: Exactly 3 concepts returned with **pairwise-distinct diversity vectors** (palette family, era register, camera grammar all differ in ≥1 axis). *(Unit, deterministic)*
- AC-2.2: Selection stores rationale; rejected concepts archived with reason; all queryable later. *(Integration)*
- AC-2.3: Zero paid calls through stage 2 on `free_only`. *(E2E G1 + provider mock)*

## Stage 3 — Visual Direction
- AC-3.1: Approved direction is an immutable versioned artefact; downstream prompt assembly demonstrably consumes its structured fields (a palette change changes compiled prompts — snapshot test). *(Unit/contract)*

## Stage 4 — Characters
- AC-4.1: Sheet request generates the requested angle set as one cost-previewed batch; estimate shown before submission; ledger shows reservation then settlement. *(E2E G2 + ledger tests)*
- AC-4.2: Consistency screening flags are advisory; only user confirmation produces a bindable sheet. *(E2E)*
- AC-4.3: A shot referencing a cast role without a `character_binding` fails API validation (`422`). *(Contract)*
- AC-4.4: Character assets export (image set + canonical JSON) — identity is the user's, not platform-locked. *(E2E)*

## Stage 5 — Script
- AC-5.1: Editing a scene marks exactly its dependent DAG nodes `stale` — verified against hand-computed expectation on a fixture DAG. *(Unit)*

## Stage 6 — Storyboard
- AC-6.1: All structural ops (merge/split/add/reorder/duplicate/delete) cost zero credits and are undoable via the operation log. *(Integration)*
- AC-6.2: Drag-reorder between any two shots performs O(1) writes (fractional indexing; no position renumbering). *(Unit)*
- AC-6.3: Board remains interactive with 500 shots (virtualisation; performance smoke). *(Perf)*

## Stage 7 — Shot Planning
- AC-7.1: Every camera/motion control resolves against the registry to `native | reference_conditioned | prompt_approximated | unsupported`; the resolution is stored on the job and visible in UI. *(Contract)*
- AC-7.2: An `unsupported` control returns `422 CONTROL_UNSUPPORTED` with alternative routes suggested — never a silently compiled prompt. *(Contract, negative test)*
- AC-7.3: The estimate equals the sum of registry-pinned unit prices × units × retry factor, byte-identical when recomputed from the same snapshot hash. *(Unit, determinism)*

## Stage 8 — Image Generation
- AC-8.1: Batch submission requires an estimate ID; paid spend above workspace threshold additionally requires an approval record. *(Contract)*
- AC-8.2: Alternates share the compiled prompt and differ in seed where the model's `seed_control` is native; otherwise labelled. *(Integration)*
- AC-8.3: A provider 5xx job auto-retries ≤3× with **zero ledger movement**; a 422-class job is never auto-retried. *(Integration + fixtures)*
- AC-8.4: With `free_only` and exhausted free quota ⇒ `quota_blocked`, user notified, no paid call observed. *(`test_no_silent_paid_fallback`)*
- AC-8.5: Concurrent batch submissions never exceed provider ceilings (property test with N racing workers). *(Property)*

## Stage 9 — Video Generation
- AC-9.1: Keyframe pins map to native model slots where `honesty=native` (e.g. first/last; up to 16 on Ray3.2-class rows) and are refused elsewhere. *(Contract)*
- AC-9.2: Replicate outputs are in R2 within 10 minutes of completion (drill-verified SLA vs the 1-hour deletion rule, F-0037). *(Drill)*
- AC-9.3: Worker kill mid-render ⇒ job recovers via `provider_ref` re-attach; exactly one provider-side job exists. *(Drill §10.5)*
- AC-9.4: Webhook forgery (bad signature) is rejected and settled state never derives from webhooks alone. *(Security test)*

## Stage 10 — Asset Management
- AC-10.1: Every asset row's `r2_key` starts with the workspace prefix (DB CHECK) and presigned URLs are refused outside it. *(Integration)*
- AC-10.2: Cross-workspace reads return zero rows for every tenant table (generated RLS test). *(Migration test)*
- AC-10.3: Duplicate upload within a workspace returns the existing asset; across workspaces stores separately. *(Integration)*
- AC-10.4: Workspace erasure removes the R2 prefix and issues provider-side deletion calls where the contract supports them; completion recorded. *(Drill)*
- AC-10.5: Export assembles accepted clips in storyboard order with VO and music bed. *(E2E G2)*

## Cross-cutting
- AC-X.1: Ledger property/replay/recovery suites green; nightly reconciliation proves zero drift. *(Property/CI)*
- AC-X.2: Every registry row carries a valid `evidence_id` resolvable in Evidence-Index.md. *(CI lint)*
- AC-X.3: Confidential workspace can only route to `data_policy=no_training` rows (router unit test across all seed data). *(Unit)*
- AC-X.4: No UI string promises capability guarantees ("guarantee", "perfect consistency") — copy lint. *(CI)*
