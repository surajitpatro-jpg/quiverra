# MVP Scope — One Complete Creative Production Workflow

**Version:** 1.1 · **Date:** 2026-11-10 · **Status:** APPROVED at gate (ADR-0016) — "do not overcomplicate the initial release" is binding
**Scope rule (user):** the first release delivers **one complete creative production workflow**, end to end, reliably. Advanced continuity, brand and workflow-automation capabilities are developed progressively — but the architecture supports them from the beginning.
**Gate amendments applied:** staged provider onboarding (ADR-0017), ₹0 paid-LLM ceiling (ADR-0018), deferred configurable commercials (ADR-0019), confidential-by-default (ADR-0020), Mumbai residency (ADR-0021).

---

## 1. The pipeline (as specified by the user)

```
Creative Brief → Creative Concepts → Visual Direction → Characters → Script
→ Storyboard → Shot Planning → Image Generation → Video Generation → Asset Management
```

Every stage below: what the user does, what the system does, and the exit gate to the next stage. Stages 1–7 run on free-tier intelligence ($0); stages 8–9 are paid generation, always estimated and approved before spend; stage 10 wraps everything.

| # | Stage | User does | System does | Exit gate |
|---|---|---|---|---|
| 1 | **Creative Brief** | Writes/pastes brief, attaches references, sets constraints (budget cap, duration, aspect) | Stores versioned brief; LLM interpretation with confidence flags; asks ≤5 targeted clarifying questions | Interpretation complete (answers given or skipped) |
| 2 | **Creative Concepts** | Compares 3 concepts (palette swatches, mood tags, rationale, pairwise trade-offs); selects / edits / merges | Generates 3 concepts with enforced diversity vectors; archives rejects with reasons | One concept `selected` |
| 3 | **Visual Direction** | Reviews/edits art direction (palette, lighting grammar, texture, typography hints) | Compiles versioned art-direction artefact that downstream engines consume as structured data | Visual direction approved |
| 4 | **Characters** | Reviews generated characters; approves multi-angle sheets; optionally uploads references | Normalises canonical identity descriptions; generates angle sheets (cost-previewed); screens consistency; versions confirmed sheets | Every cast role has a confirmed sheet or explicit "no character" |
| 5 | **Script** | Edits scene-structured script | Generates draft script from plan; versions edits; DAG marks affected nodes stale | Script approved |
| 6 | **Storyboard** | Restructures scenes/shots freely (merge, split, add, reorder) — zero cost; edits shot fields; binds characters structurally | Maintains board state (fractional indexing), operation log (undo), structured bindings | Structure locked for framing |
| 7 | **Shot Planning** | Reviews per-shot camera/motion intent and feasibility badges | Compiles shot controls against registry capabilities; flags `unsupported` with alternatives; deterministic cost estimate per shot and total (3 policies) | Estimate approved (spend gate) |
| 8 | **Image Generation** | Approves frame batch; reviews frames + up to 3 alternates per shot; selects; requests selective regeneration (seed/prompt/reference/model) with cost preview | Routes per registry honesty classes; generates alternates with varied seeds; continuity checks (deterministic + embedding + rubric); ledger reservation→settlement | Every shot has a selected frame (or is marked no-image) |
| 9 | **Video Generation** | Approves clip batch per shot (start-frame / keyframe mode auto-resolved per model); reviews clips; retakes selectively | Capability-translated generation; keyframe pins where native; failure-class retries (server errors free); fal routes first — Replicate adapter inserted only if needed (ADR-0017); immediate R2 ingestion where provider retention demands it | Every shot has an accepted clip (or explicit skip) |
| 9b | **Voiceover (conditional)** | Reviews VO renders against script | ElevenLabs adapter lands at W13 **only after** the data-use opt-out is applied and verified (ADR-0017/F-0045); if not ready by M5, export ships video + music bed and VO lands in the next iteration — the pipeline never blocks on an unverified provider | VO accepted per scene, or deferred |
| 10 | **Asset Management** | Browses library; downloads/exports; manages project assets | Workspace-scoped library (frames, clips, sheets, uploads) with lineage (every asset → job → plan version); final assembly export (timeline-ordered clips + VO + music bed); confidential-by-default privacy applies throughout (ADR-0020) | Project export delivered |

## 2. What is deliberately excluded from the first release

| Excluded | Why | When |
|---|---|---|
| Brand compliance scoring & campaign governance | Advisory evaluators need calibration; deterministic parts (palette/logo checks) may land early | Phase 2 (progressive) |
| Continuity auto-repair (frame-chaining etc.) | Detection ships; automated repair paths after telemetry shows which failures dominate | Phase 2 |
| Workflow automation / scheduling / auto-approvals | Human gates are the trust feature; automation needs per-workspace policies + ceilings | Phase 3 |
| Real-time collaboration | Operation log is OT/CRDT-ready; MVP is single-editor + optimistic locking (F-0026 is Higgsfield's, not our MVP) | Phase 3 |
| Trained identity models | Reference-conditioned identity ships; LoRA-style training post-MVP | Phase 3+ |
| Self-hosted GPU fleet | Registry-ready (`provider: self`, F-0041); economics justify only at utilisation ≥66 % | Scale decision |
| Payments activation | User constraint: dormant until billing/legal/refund rules defined (Razorpay/Cashfree integrations stay dark) | After legal review |

## 3. Architecture readiness proof (support-tomorrow, build-today)

| Future capability | Today's support |
|---|---|
| Brand/campaign governance | `brand_profiles`, `campaigns`, `brand_evaluations` tables + engine module exist; UI surfaces later |
| Auto-repair | Continuity eval pipeline stores rubric results; repair actions are new job kinds, not schema changes |
| Scheduling | `approvals` + DAG gates are data; a scheduler is a new gate-policy, not a rewrite |
| New video models (e.g. Kling 4.0 official API) | Registry rows; zero code (ADR-0009) |
| Self-hosted models | Same registry, `provider: self` (F-0041) |
| Collaboration | `storyboard_operations` log is the OT/CRDT foundation |
| Payments | Ledger already double-entry (ADR-0012); activation is config + legal, not re-engineering |

## 4. Definition of done for MVP (rollup)

The MVP is done when a new user can execute stages 1–10 for a 30-second ad (one character, 8–12 shots) with: zero silent paid spend (policy enforcement demonstrable), one approved estimate before the first paid call, ledger balance matching every event exactly, and an exported final assembly — verified end-to-end on staging with real provider sandbox keys. Feature-level criteria: **Feature-Acceptance-Criteria.md**.
