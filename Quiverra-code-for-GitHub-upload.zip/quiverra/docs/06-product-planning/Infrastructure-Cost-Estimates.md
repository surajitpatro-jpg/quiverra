# Infrastructure & Operating Cost Estimates

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Proposed · All figures carry the freshness rule — re-verify vendor pricing before purchase. Ranges are planning estimates (**H**) except where tied to an Evidence-Index finding.

---

## 1. Fixed infrastructure (monthly)

| Item | Choice | Cost (est.) | Notes |
|---|---|---|---|
| VPS | Hostinger 4 vCPU / 16 GB (per Deployment.md) | ~$15–25/mo | Runs API + workers + Redis + ClamAV + observability (Docker Compose) |
| Database | Supabase free tier → Pro $25/mo when limits bite | $0–25/mo | Start free; Pro unlocks point-in-time recovery |
| Object storage | Cloudflare R2 | ~$0–5/mo at MVP scale | $0.015/GB-mo class; zero egress fees — key vs S3 |
| Domain + DNS | Cloudflare registrar | ~$10–12/**yr** | — |
| Email (transactional) | Resend/SES-class free tier | $0 | — |
| Error tracking | Self-hosted (Grafana stack on VPS) / Sentry free | $0 | Included in VPS sizing |
| **Fixed total (dev)** | | **≈ $15–55/mo** | |

## 2. AI provider costs — development phase

**Intelligence: $0** by design (structural asymmetry). Groq free tier + Gemini Flash free + OpenRouter `:free` + Cloudflare 10k Neurons/day cover all LLM work at dev volumes (Provider-Research-Intelligence §4 — ≈40–120 calls per full project, within free windows).

**Generation: deliberately small, paid, capped.**

| Item | Est. volume (dev/testing) | Unit basis (evidence) | Monthly est. |
|---|---|---|---|
| Image frames (dev iterations + E2E) | ~1,000 images | flux-2 flash $0.005/MP → schnell $0.003/MP via fal (F-0021) | $3–8 |
| Video clips (dev + drills) | ~200 s | Wan 2.5 $0.05/s via fal (F-0021) | ~$10 |
| TTS (dev) | ~200k chars | ElevenLabs Flash $0.04–0.05/1k (F-0023/F-0040, conflict noted) | $8–10 |
| STT | — | Workers AI Whisper free Neurons (F-0019) | $0 |
| fal/Replicate/Gemini minimum prepays | one-time | fal credits (365-day), Replicate $10 min, Gemini $5 prepay (F-0036/F-0037/F-0039) | ~$25 one-time |
| **Provider total (dev)** | | | **≈ $20–30/mo + $25 one-time** |

## 3. Pilot / early-production phase (first ~50 active workspaces, planning estimate)

Assumptions (declared, **H**): average paying user completes 2 projects/mo; a project = 10 shots × (3 image candidates + 8 s video) + VO ≈ 30 images + 80 s video; blended acceptance 70 % (so ÷0.7 attempts); intelligence stays free-tier-heavy at this scale.

| Cost centre | Basis | Est. monthly |
|---|---|---|
| Image generation | 50 ws × 2 proj × 43 images × ~$0.008 blended | ~$35 |
| Video generation | 50 × 2 × 115 s × $0.06 blended | ~$690 |
| Audio | 50 × 2 × ($0.50 VO + $0.15 music) | ~$65 |
| Infrastructure | VPS upg. 8 vCPU + Supabase Pro + R2 + bandwidth | ~$80 |
| **Total COGS+infra** | | **≈ $870/mo** |

**Pricing logic implication** (from API-Cost-Analysis.md): at $0.05–0.11/s video COGS (fal Kling/Wan range, F-0021), a credit priced at $0.01 with ~25 cr/s average billing yields ~55–75 % gross margin at pilot scale — healthy; the margin funds the free intelligence layer. These are planning numbers; the ledger + usage reports exist precisely to replace them with measured truth from week one of pilot.

## 4. Scale triggers (pre-decided)

| Trigger | Action |
|---|---|
| fal concurrency ceiling (<40) throttles jobs | Open Kling direct package (concurrency 5–20, F-0038) + second provider account per policy |
| Video COGS > $2k/mo sustained | Evaluate self-hosted LTX-2.5 on RunPod (≈$0.002/s at ≥66 % utilisation, F-0041) as registry `provider: self` rows |
| Supabase free exhausted | Pro $25/mo (already budgeted in §1 range) |
| VPS CPU >70 % sustained in worker peaks | Split worker-gen to a second VPS (stateless, ADR-0011) |
| Intelligence free tiers saturated | `paid_authorised` LLM routing decision with workspace consent — never silent |

## 5. Cost controls built into the product (not optional extras)

1. Deterministic pre-flight estimates on every batch (user-visible).
2. Per-job budget tolerance (default ×1.2) halting runaway batches.
3. Monthly workspace caps enforced at reservation time (ADR-0014).
4. Provider balance auto-reload thresholds (Replicate guidance: keep >$20, F-0037) with alerts.
5. Nightly ledger↔provider reconciliation paging on drift >$0.01 (Database-Architecture §5).
