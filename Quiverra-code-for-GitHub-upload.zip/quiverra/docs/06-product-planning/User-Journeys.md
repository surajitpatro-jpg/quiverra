# User Journeys

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Proposed — golden paths drive the E2E suite (Testing-Strategy §1)

---

## Journey G1 — First project, free tier only (the trust builder)

**Actor:** solo creator, new account, zero credits. **Goal:** experience the full planning pipeline and one cheap generation without spending money.

1. Signs up → workspace created with `spend_policy: free_only` (default), empty ledger.
2. Creates project "30-second cafe launch ad", pastes brief, uploads 2 reference photos.
3. **Stage 1–2**: interpretation returns in seconds; answers 3 clarifying questions; receives 3 visually distinct concepts (different palettes/camera grammar by construction). Selects concept 2; the reject reasons form asks one line ("too dark") — stored.
4. **Stage 3–5**: approves visual direction; reviews generated character "Maya, cafe owner", but sheet generation is a paid image batch → system shows the estimate (~₹/$ equivalent credits) and states: *"This is your first paid step. Free preview: character description only."* User approves plan and script without generating.
5. **Stage 6–7**: restructures the storyboard (merges two scenes, reorders shots), binds Maya structurally to 6 shots, sees per-shot feasibility badges and a full-project estimate under three policies.
6. Journey ends with an approved, costed plan the user owns — total spend ₹0, total time ~15 minutes. **The product has already delivered value no competitor gives for free** (F-0016).

**Instrumented assertions (E2E):** zero paid provider calls in logs; estimate reproducible from pinned registry snapshot; all stages resumable after browser refresh mid-flow.

## Journey G2 — The 30-second ad, end to end (the MVP proof)

**Actor:** same creator, credits purchased (or dev credits in staging). **Goal:** complete all 10 stages.

1. Character sheet: approves estimate; 4 angles generate; one angle flagged `review` by consistency screening; user rejects it, auto-regen succeeds; sheet confirmed (immutable v1).
2. Storyboard → frames: requests primary + 2 alternates for 10 shots in one cost-previewed batch. Ledger shows reservation → jobs run → settlement; 2 shots' frames flagged by continuity checks (palette drift, character likeness) → user retakes one (`seed_only`), accepts the other as-is (decision logged).
3. Video: shot 3 requests a dolly-in. Routed model's registry row says camera moves are `prompt_approximated` → badge visible; user proceeds knowingly. Shot 7 requests 16-point keyframe choreography → system refuses for the default route (`CONTROL_UNSUPPORTED`) and offers the Ray3.2-class route at a higher price — user chooses per-shot.
4. One video job fails with a provider 5xx mid-batch → auto-retry succeeds; ledger shows **no movement** for the failure (server errors are non-events, F-0036).
5. Voiceover: script → ElevenLabs Flash batch; user had been asked at onboarding about training opt-out (done at account setup, F-0045).
6. **Stage 10**: library shows every asset with lineage; user exports the assembled 30 s timeline (clips + VO + music bed).
7. Billing page: every event itemised — reservation, settlement, retry, the one goodwill gesture they didn't need. Balance exactly matches history.

**Instrumented assertions:** balance == derived ledger sum at every step; no `quota_blocked` job ever produced a paid call; Replicate outputs ingested <10 min after completion; export plays in order.

## Journey G3 — Free quota exhausted mid-project (the hard rule)

**Actor:** heavy user on `free_only`. Mid storyboard structuring, the day's free intelligence quota (Groq RPD) exhausts.
- System: current job parks `quota_blocked`; banner explains exactly what happened, shows reset time (per-provider window truth), offers two honest paths: wait, or switch policy to `paid_authorised` with a monthly cap they set. **No silent reroute occurs** (contract test `test_no_silent_paid_fallback` is the CI proof).

## Journey G4 — Brand mini-campaign (post-MVP preview, architecture proof)

**Actor:** marketing lead. Uploads brand PDF → confirms extracted profile draft; product packshots tagged with sacred regions; three projects inherit the campaign palette lock. One generated frame triggers a logo-mismatch flag; user chooses the compositing path (real packshot into generated scene). *In MVP scope only if timeline allows (MVP-Scope §2); journey documented now to keep the UI from painting itself into a corner.*

## Journey G5 — Confidential client work (privacy routing)

**Actor:** studio with a confidential workspace. Every route resolves to `no_training` registry rows only; fal calls carry `X-Fal-Store-IO: 0` (F-0042); free-tier Gemini and OpenRouter `:free` are structurally unreachable (router test proves it). Erasure request → workspace prefix delete + provider-side deletion calls recorded (Asset-Storage §4).
