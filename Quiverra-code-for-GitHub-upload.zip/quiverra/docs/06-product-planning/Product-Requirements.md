# Product Requirements Document

**Version:** 1.1 · **Date:** 2026-11-10 · **Status:** Approved at gate with directions (ADR-0016..0021 applied in §8)
**Builds on:** corrected architecture (ADRs 0001–0015), seven system specs v0.2, provider research v2.0, competitive evidence F-0001..F-0045

---

## 1. Product definition

An **AI Creative Production Operating System**: a professional web platform that takes a creative brief and produces finished video assets through one managed pipeline — with planning, cost estimation, character/scene continuity and audit-grade billing built in, not bolted on. It is not another AI tools aggregator (user-approved positioning): generation models are swappable infrastructure behind a capability-honest router; the product is the production intelligence above them.

## 2. Target users

| Persona | Need we serve | Evidence |
|---|---|---|
| Solo content creator / small studio | Brief→finished ad or short film without juggling 5 tools and re-planning in their head | F-0015 (fragmented pre-production), F-0016 (nobody offers plan+cost+continuity) |
| Marketing / brand team | Campaign consistency, product/packaging fidelity, approval trail | F-0016 (no brand-rule storage anywhere), Brand spec |
| Cost-sensitive professional | Know what a project costs before spending; never get silently upgraded to paid spend | F-0034/F-0035 (billing complaints are the industry wound), user-mandated spend rule |

## 3. Differentiators (evidence-anchored)

1. **Plan-before-pay**: project-level, itemised, policy-switchable cost estimate before any generation. No competitor offers project-level estimation (Higgsfield previews per-render only, F-0028).
2. **Capability honesty**: every camera/motion control labelled `native | reference_conditioned | prompt_approximated | unsupported` per model version; unsupported controls are refused, never silently approximated (nobody does this, F-0016).
3. **Structured continuity**: characters as reusable, exportable assets with structured shot bindings — not @-mentions whose omission is LTX's primary inconsistency cause (F-0033), and not platform-locked like Soul ID (F-0027).
4. **Billing you can trust**: double-entry ledger, deterministic estimates, visible free/paid routing, self-serve cancel, plain refund rules — the exact inverse of documented competitor complaints (F-0034, F-0035).

## 4. Scope (MVP)

The full MVP scope is defined in **MVP-Scope.md** — the 10-stage pipeline:
Brief → Concepts → Visual Direction → Characters → Script → Storyboard → Shot Planning → Image Generation → Video Generation → Asset Management.

**Explicitly out of MVP** (architecture supports them from day one; built progressively): brand compliance scoring, advanced continuity auto-repair, workflow automation/scheduling, real-time collaboration, trained identity models (Soul-ID-style), self-hosted GPU fleet, payments activation (dormant until legal/refund rules defined — user constraint).

## 5. Functional requirements (rollup)

The normative requirements live in the seven system specs (v0.2, §FR lists) and the API contract (openapi.yaml). Rollup of what the MVP must do:

1. Accept a brief; produce structured interpretation with targeted clarifying questions; generate N=3 diverse concepts; capture selection rationale.
2. Produce versioned visual direction; compile an editable production plan with scene breakdown and shot list.
3. Generate and manage characters with multi-angle sheets, consistency screening, and structured shot binding.
4. Hold an editable script; propagate edits to exactly the affected DAG nodes.
5. Provide a professional storyboard workspace: structural editing (free), drag sequencing, alternates, selective regeneration with cost preview.
6. Route all generation through the registry with capability translation and honesty labelling; estimate cost deterministically pre-flight.
7. Execute jobs reliably (idempotent, resumable, reconciled per provider contract) with atomic quota reservation.
8. Track every credit and every cent in a balanced double-entry ledger; expose balance and history to the user.
9. Enforce spend policy: free-only default; paid only on explicit authorisation; exhaustion pauses and notifies.
10. Manage all assets workspace-scoped with presigned access, scanning, and workspace-only dedup.

## 6. Non-functional requirements

| NFR | Target | Mechanism |
|---|---|---|
| Honesty | No invented capability, no silent paid spend, no "tests passed" claims without execution | Registry honesty classes; spend-policy enforcement; testing strategy |
| Reliability | Zero double-charges; zero lost jobs | Ledger invariants + property tests; idempotent jobs + reconciler sweeper |
| Security | Workspace isolation at DB level; keys server-side only | RLS FORCE policies; secrets matrix (Security.md) |
| Privacy | Confidential-workspace routing away from training-on-data providers | Registry `data_policy` + routing rules (F-0042..F-0045) |
| Performance | Storyboard board interactive at 160+ thumbnails; estimates <500 ms | Virtualised board; deterministic estimator vs pinned snapshot |
| Cost | MVP infra ≤ ~$100/mo at dev scale (see Infrastructure-Cost-Estimates.md) | Hostinger VPS + Supabase free/Pro + R2 + free-tier intelligence |

## 7. Success metrics (post-launch, measurable)

- **Estimate accuracy**: median |actual − estimate| / estimate per workspace, target ≤20 % after calibration.
- **Acceptance rate**: user-accepted / completed generations per route (feeds estimator; industry pain is paying for defective output, F-0034).
- **Free-tier coverage**: % of intelligence calls served at $0 (structural cost moat, Provider-Research-Intelligence §1).
- **Time brief→approved plan**: target <15 min median for a standard ad brief.
- **Trust**: zero billing disputes escalating past self-serve resolution (vs industry norm, F-0035).

## 8. Constraints (user-mandated; gate 2026-11-10 reaffirmed and extended)

All provider keys server-side; never in frontend code, public repositories or project documentation · No silent paid spend · No live payments or customer credit purchases until the commercial model, refund rules, expiry policy and legal requirements are reviewed and approved (ADR-0019) · No fabricated evidence or test claims · No copying competitor code/branding · No authentication bypass · All commercial settings configurable, never hardcoded (ADR-0019).

**Gate directions now binding:**
- **Privacy is the default (ADR-0020):** confidential mode ON by default — private projects/assets, no public sharing by default, workspace-level isolation, no training on customer content, provider disclosure before external submission, per-provider data-use policies enforced at the router; providers that cannot meet the conditions are restricted, not merely disclaimed.
- **Staged providers (ADR-0017):** Gemini + Groq (intelligence), fal.ai (image/media), Cloudflare R2 (storage) first; Replicate, ElevenLabs and specialist video routes land only when the roadmap requires them; ElevenLabs opt-out applied and verified before any content submission.
- **₹0 paid-LLM budget (ADR-0018):** free-only intelligence; insufficiency triggers a benchmark deliverable for approval, never an automatic paid fallback.
- **Data residency (ADR-0021):** Supabase Mumbai (ap-south-1); residency register maintained; no claim that region choice alone confers DPDP compliance.
