# Testing Strategy

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Proposed
**Prime directive (user):** "Do not claim tests passed unless they were actually executed." Every test claim in this project carries an execution record (CI run ID + date).

---

## 1. Test pyramid for this system

| Layer | What it proves | Tools | Where |
|---|---|---|---|
| Unit | Pure logic: estimator math, prompt slot-filling, DAG invalidation, fractional indexing, capability translation table | Vitest | CI, every push |
| Contract | Server routes match openapi.yaml (paths, schemas, error shapes); provider adapters satisfy the adapter interface | generated client + schema validators | CI, every push |
| Property | Ledger invariants under randomised recipe sequences; quota acquire never exceeds limits under concurrency | fast-check | CI, every push (ledger/quota suites gate merge) |
| Integration | Postgres + Redis real: migrations, RLS cross-tenant isolation, reservation lifecycle, sweeper convergence, webhook idempotency | Docker-less CI Postgres/Redis services | CI, every push |
| Provider sandbox | Real API calls against provider sandbox/free tiers: submit→poll→ingest→settle; failure classes observed for real | recorded fixtures + live weekly run | Staging, weekly (live), CI (fixtures) |
| E2E journeys | The User-Journeys.md golden paths on staging | Playwright | Staging per release candidate |
| Recovery drills | §10.5 scenarios (kill worker, block webhooks, Redis flush, late ingestion) | scripted + manual checklist | Pre-launch gate, then quarterly |

## 2. Money-path tests (the launch gate)

1. **Balanced books**: every randomised property run ends with Σdebit=Σcredit per transaction and global drift 0.
2. **No double-charge**: duplicate idempotency keys (webhook replay, worker retry, sweeper re-run) yield exactly one settlement.
3. **Reservation honesty**: job cancelled/failed-server ⇒ `available` balance unchanged from pre-reservation state (hold released, nothing consumed).
4. **Spend-policy enforcement**: with policy `free_only` and exhausted free quota, the attempted job is `quota_blocked`, zero paid calls observed at the provider mock, and the user notification was emitted. This test is named `test_no_silent_paid_fallback` and its CI history is linked from the release checklist.
5. **Reconciliation**: injected synthetic drift is detected by the nightly job in ≤1 run.

## 3. Provider-contract tests

Each adapter has a **contract fixture suite** recorded from verified behaviour (F-0036..F-0045): fal 429 shape (`concurrent_requests_limit` + header), Replicate 1-hour deletion handling, Gemini 402/quota semantics, ElevenLabs concurrency headers. Fixtures replay in CI; a **weekly live probe** against real free tiers re-validates the fixtures and files a freshness report (registry staleness feeds the same loop).

## 4. Honesty-surface tests

- Registry rows round-trip with `evidence_id` mandatory; a row without evidence is rejected at insert (DB CHECK) and in CI lint of seed files.
- Capability translation: for every (control × model) the translator emits the declared honesty outcome; `unsupported` ⇒ 422 `CONTROL_UNSUPPORTED`, never a compiled prompt (contract test).
- UI copy scan: strings claiming "guarantee/consistency guaranteed" fail lint — the product's honesty rules are enforced on its own marketing surface.

## 5. Performance smoke

- Storyboard board with 500 synthetic shots: render budget <100 ms scripting per interaction (virtualisation on).
- Estimate endpoint: p95 < 500 ms against pinned snapshot (10k registry rows).
- Sweeper convergence: 1,000 in-flight jobs reconcile within one sweep interval (load-gen against provider mocks).

## 6. What is NOT tested automatically (stated)

- **Aesthetic quality** of generations — user judgement, measured via acceptance-rate telemetry, never asserted in CI.
- **LLM output "correctness"** beyond schema validity and diversity-vector distinctness — creative quality is evaluated by users, not fabricated into test claims.
- **Cross-browser visual polish** beyond the two primary browsers — manual checklist per release.
