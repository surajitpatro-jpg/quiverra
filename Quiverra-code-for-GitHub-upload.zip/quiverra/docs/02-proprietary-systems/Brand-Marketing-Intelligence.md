# System Specification — Brand & Marketing Intelligence Engine

**System 6 of 7 · Priority P2 · Version 0.2 · 2026-11-09**
Depends on: Shared Project Model, Creative Director Engine (consumes brand rules at concept stage), Provider Router (VLM evaluation), Asset Library, Shot Planner (multi-format exports).
Evidence base: Gap 6 — brand intelligence is import-and-pray everywhere (F-0004 Higgsfield Brand Kit "pulls brand details from your site", Ads Studio imports products; F-0010 Runway Brand Kits = asset bags; no competitor stores messaging rules or scores compliance, F-0016).

---

## 1. Purpose

A persistent **brand intelligence layer**: store what a brand is (visual identity, voice, messaging rules, restrictions, products, approved assets, campaign history) once — and have every creative decision and generated output respect it automatically, with measurable brand-compliance evaluation.

## 2. User problems (evidence-backed)

1. **Brand context is re-explained every time.** Even the best competitor (Higgsfield Ads Studio) imports brand from a URL into a session; nothing persists rules across campaigns (Gap 6).
2. **Compliance is manual review.** Agencies check outputs against brand guidelines by eye; no platform evaluates outputs for compliance (F-0016).
3. **Brand kits are asset bags.** Runway Brand Kits store colours/logos; nothing encodes tone, messaging rules, or restrictions ("never show X", "always plural product naming") (F-0010).
4. **Multi-format is re-work.** Adapting one campaign concept to 9:16/1:1/16:9 is manual re-generation per competitor workflows, without shared continuity or brand checking.

## 3. Functional requirements

### FR-1 Brand profile
Persistent record: name, logo(s), brand colours (with roles), typography, guidelines documents (uploaded + parsed), photography style, visual references, **product catalogue** (product records with references and selling points), **brand voice** (tone descriptors, vocabulary do/don't, example copy), **messaging rules** (claims policy, mandatory lines, forbidden topics), **restrictions** (visual and verbal), approved assets, campaign history links.

### FR-2 Brand ingestion assist
Optional bootstrap from a website URL + uploaded guideline PDFs: VLM/LLM extracts a draft profile (colours, typography, style descriptors, voice hypothesis) — user reviews and corrects before saving (draft-only automation, per our honesty rule).

### FR-3 Brand-aware creative planning
When a project links a brand profile: the Creative Director Engine generates concepts/scripts under the brand's voice and rules; violations are flagged at *plan* stage (cheap) rather than after generation (expensive).

### FR-4 Brand-compliance evaluation
Automated evaluation of generated assets: palette conformance (deterministic colour analysis), logo/product presence where required (VLM), style match vs references (VLM), copy compliance vs messaging rules (LLM check on text/VO scripts). Per-check scores with confidence; compliance report per asset and per campaign; human override with reason (audited).

### FR-5 Multi-format campaign production
One approved plan → aspect-ratio/duration variants (16:9 hero, 9:16 cutdown, 1:1 social, banners) generated from the same shots with reframing rules; brand evaluation runs per variant.

### FR-6 Campaign memory
Campaigns link to the brand; approved assets, evaluation results and performance notes accumulate — the next campaign starts smarter (Persistent Creative Memory, brief §13-A).

### FR-7 Team governance
Brand profiles are org assets with roles (viewer/editor/approver); locked profiles can't be edited by creators; change history is versioned.

## 4. User workflows

**W1 — Onboard a brand:** paste brand URL + upload guidelines PDF → review extracted draft profile (correct two colours, add forbidden-claims rule) → lock v1 → all team projects can now attach it.

**W2 — Brand campaign:** new project → attach brand → brief "product launch teaser for new serum" → concepts arrive already brand-voiced with palette applied → plan flagged: "concept 2 mentions 'clinically proven' — forbidden claim per rule R7" → user picks concept 1 → production proceeds.

**W3 — Compliance review:** 12 assets generated → compliance report: 9 pass, 2 style-mismatch (confidence 0.78), 1 palette violation (deterministic) → user regenerates the 3 with guidance → report goes green → export.

**W4 — Multi-format export:** approved 30s 16:9 master → "create variants" → 9:16 and 1:1 versions generated with reframing → each variant gets its own compliance check before export.

## 5. Data structures

```yaml
BrandProfile:  { id, org_ref, name, logos[], colours:[{hex, role}], typography[{family, role}], guidelines_docs[], photography_style, visual_refs[], voice:{tone[], vocabulary_do[], vocabulary_dont[], example_copy[]}, messaging_rules:[{id, kind(claim/mandatory/forbidden), rule, severity}], restrictions[], product_catalogue:[{id, name, refs[], selling_points[]}], approved_assets[], version, status }
ComplianceReport: { id, brand_ref, asset_ref, checks:[{check, kind(deterministic/vlm/llm), result, score, confidence, evidence_ref}], model_used, created_at }
Campaign:      { id, brand_ref, project_refs[], master_plan_ref, variants:[{format, aspect_ratio, duration, shots_override[]}], status }
```

## 6. Dependencies

- **Creative Director Engine** — consumes voice/rules at concept and script stage.
- **Provider Router** — extraction, evaluation tasks (intelligence class).
- **Asset Library** — logos, products, approved assets.
- **Shot Planner / Workflow Engine** — variant production and export.
- **Character Engine** (optional) — brand mascots/spokescharacters as characters linked to the brand.

## 7. API requirements

```
POST   /api/library/brands                          # create
POST   /api/brands/:id/ingest                       # URL/PDF → draft profile
PATCH  /api/brands/:id                              # edit (versioned)
POST   /api/brands/:id:lock                         # governance
POST   /api/brands/:id/products                     # catalogue management
GET    /api/projects/:id/brand-context              # compiled rules for planning
POST   /api/assets/:id/compliance:check             # → ComplianceReport
GET    /api/campaigns/:id/compliance                # campaign-level report
POST   /api/campaigns/:id/variants                  # multi-format variant creation
```

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Profile extraction (URL/PDF) | Multimodal VLM + LLM | Draft only, user-confirmed |
| Palette compliance | Deterministic colour analysis | Code, not a model; exact thresholds |
| Style/logo/product checks | VLM | Scored with confidence |
| Copy/claims compliance | LLM with rules context | Structured verdicts citing rule IDs |
| Reframing guidance for variants | Deterministic + VLM spot-check | Composition rules per aspect ratio |

## 9. Technical implementation approach

- **Rules as data, compiled into context:** messaging rules are structured records injected into planning prompts and checked deterministically where possible (forbidden strings, mandatory lines) — LLM judgement only where semantics require it.
- **Deterministic-first evaluation:** palette and copy-rule checks are exact code; VLM checks carry confidence; the report clearly separates "measured" from "judged" (honesty rule).
- **Brand context as a compiled artefact:** `brand_context(brand_version)` is a versioned, cacheable document consumed by every engine — a brand edit produces a new version, and in-flight work keeps its snapshot (ADR-0007 pattern).
- **Variants inherit, don't fork:** variants reference the master plan with override lists, so master edits propagate intentionally, not accidentally.

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| URL ingestion finds little (JS-heavy site) | Report what was extracted, ask for guidelines PDF or manual entry — never fabricate a profile |
| Conflicting rules (user-created) | Validation flags contradictions at save time |
| Compliance model unavailable | Assets marked `unevaluated`, queued; export gates (if configured) block until evaluated |
| Override of a failing check | Mandatory reason; appears in audit log; never hidden from reviewers |
| Brand edited mid-campaign | Running work uses frozen snapshot; affected artefacts flagged for re-check |

## 11. Acceptance criteria

1. A brand profile round-trips ingestion → correction → lock; the compiled brand context reflects the locked version exactly (integration test).
2. A deliberately non-compliant asset (wrong palette, forbidden claim) fails both the deterministic and LLM checks with rule citations (evaluation test).
3. Plan-stage flagging: a concept containing a forbidden claim is flagged before any generation spend (end-to-end test).
4. Variant creation produces per-format assets each with independent compliance reports (workflow test).
5. Overrides require reasons and appear in the audit trail (policy test).

## 12. Improvement opportunities over existing products (≥3)

1. **Rules, not just assets.** Competitors store logos and colours (Runway) or scrape a site per session (Higgsfield); we encode voice, messaging rules, claims policy and restrictions as structured, enforced data.
2. **Compliance as a measurable gate.** No competitor scores outputs for brand compliance; our per-check reports (deterministic + confidence-scored) turn brand safety from manual review into a system property — the feature agencies actually pay retainers for.
3. **Plan-stage prevention.** Violations are caught in concepts and scripts (free) rather than in rendered videos (expensive) — a direct cost story competitors can't tell.
4. **Campaign memory:** profiles accumulate campaign history, evaluation outcomes and approved assets, so brand work compounds — versus every competitor session starting from zero.

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: **brand identity, product photography, packaging, campaign consistency**.*

### 13.1 How it works technically

**Brand identity as structured data.** A `brand_profile` is a versioned artefact: logo assets (SVG/PNG, with clearspace rules), colour system (hex + roles: primary/secondary/accent/background), typography (family names + fallback stacks + usage rules), tone-of-voice descriptors, forbidden-elements list, and product line records. Nothing here is LLM-generated prose — it is entered once (or extracted from an uploaded brand PDF by an LLM into a **user-confirmed draft**) and thereafter enforced mechanically.

**Product & packaging intelligence.** Products are first-class entities: `products` → `product_assets` (packshots, packaging angles, label close-ups, 3D turnarounds where supplied). Packaging text/labels are treated as **sacred regions**: when product images feed generation as references, the registry route must support reference-conditioned editing (Nano Banana 2-class rows) and the compiled prompt carries an explicit `preserve_regions` clause assembled from the product asset metadata (label artwork, logo placement, pack proportions). Where the routed model's honesty class is only `prompt_approximated`, the UI warns that label fidelity is at risk and recommends compositing instead.

**Compositing fallback (deterministic).** For packshot-critical frames, the platform supports a **no-model path**: generated background/scene + user's actual packshot composited programmatically (worker, sharp/libvips: perspective pin, shadow synthesis, colour-match to scene palette). This is the honest answer to a real industry failure — models mangle label text. Composite jobs are ledger entries like any other, priced at worker time (near-zero vs model cost), and flagged `composite: true` so the user knows exactly what they're looking at.

**Campaign consistency.** Campaigns group projects under a brand with shared: palette lock (generated assets' measured palettes are histogram-checked against brand colours — deterministic, from the Creative Director's quantiser), typography overlay templates (title cards rendered by the worker, never by image models), tone rules enforced at script stage (LLM check against brand tone descriptors with structured flags), and a per-campaign asset lineage view (every asset traces to brand-version + concept-version + job).

**Brand compliance scoring.** Each deliverable asset gets a layered score: deterministic checks (palette distance, logo presence via template match, forbidden-element OCR sweep on generated frames) + one multimodal rubric call (same pattern as Scene Continuity §13.1 layer 3) for tone/style fit. Scores and evidence are shown; threshold breaches flag for review. Scoring is advisory in MVP (see §13.4.2).

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| Brand profile versions | user entry / LLM-extracted draft | `brand_profiles` |
| Product records + packshots | user upload | `products`, `product_assets`, R2 |
| Sacred-region metadata | user tagging UI | `product_assets.regions` |
| Campaign structure | user | `campaigns`, project links |
| Compliance results | checks + eval | `brand_evaluations` |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Brand PDF → draft profile | multimodal LLM | Gemini Flash | Draft only; user confirms every field |
| Tone-of-voice checks | LLM text | Groq free | Advisory flags with quoted evidence |
| Product-in-scene generation | reference-conditioned image models | router (Nano Banana 2 class) | Label fidelity at risk unless composited |
| Compositing | none (libvips) | worker | Deterministic; the packshot is real pixels |
| Palette/logo/forbidden checks | none (histogram/template/OCR) | worker | Deterministic |

### 13.4 Limitations (stated honestly)

1. **Model-generated label text is unreliable industry-wide.** Our contract: never let a model invent packaging text; sacred regions are preserved by reference-conditioning with warnings, or composited. Where a user insists on full generation, the UI states the risk explicitly. This is a differentiator claim we can evidence, not a solved problem we hide.
2. **Compliance scoring is advisory in MVP.** Deterministic checks are trustworthy; the LLM tone/style rubric is not a certification. Enterprise-grade brand-governance (legal sign-off workflows) is post-MVP.
3. **Perspective/shadow compositing quality.** Programmatic compositing handles standard packshot-into-scene cases well; complex reflections/transparent packaging will look synthetic and get flagged for manual review. We state this rather than over-promising "studio quality".
4. **Brand extraction from PDFs is draft-grade.** Extraction accelerates setup but every extracted field requires user confirmation before it becomes enforced data.
