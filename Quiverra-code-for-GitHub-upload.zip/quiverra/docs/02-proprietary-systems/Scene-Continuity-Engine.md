# System Specification — Scene & Continuity Engine

**System 4 of 7 · Priority P0 · Version 0.2 · 2026-11-09**
Depends on: Shared Project Model, Character Engine (identity refs), Storyboard & Shot Planner (shot ordering), Provider Router (VLM evaluation tasks), Cinema Engine (lighting/camera state vocabulary).
Evidence base: Gap 2 — continuity is folklore in every competitor (F-0006, F-0010, F-0012). This engine is the project's strongest differentiator.

---

## 1. Purpose

Maintain a **structured, queryable scene state** across an entire production and use it to (a) prevent continuity errors before generation, (b) detect them in generated outputs, and (c) repair them with minimal regeneration. Continuity becomes a system property, not a user chore.

## 2. User problems (evidence-backed)

1. **Continuity is entirely manual today.** Higgsfield's own guidance is a list of techniques (@refs, Elements, frame chaining, "start a new chain every 2–3 clips because errors accumulate", post-hoc Genjutsu repair) — the burden is on the user (F-0006).
2. **No state tracking exists anywhere.** Runway: "Gen-4.5 does not remember earlier generations" (F-0010). Luma: consistency is its primary weakness even with Master Reference Assets (F-0012).
3. **Errors are discovered after spend.** A wardrobe change or vanished prop is noticed in the rendered clip, after credits are consumed, and the only fix is regenerate-and-pray or post-hoc editing.
4. **Long-form is punished.** Flagship models cap at 5–15s; chaining accumulates drift (Higgsfield's own caveat). Without state, 30–60s productions are a drift lottery.

## 3. Functional requirements

### FR-1 Scene state model
Every scene carries structured state:
- **Characters present** (ref → Character Engine), per character: wardrobe, accessories, position/blocking, emotional state, held props
- **Location** (ref) + layout notes + geography ( entrances/exits, relative positions)
- **Props**: present items, positions, states (e.g., "glass: full → empty")
- **Environment**: time of day, weather, lighting setup (per Cinema Engine vocabulary), colour treatment
- **Screen direction**: established axis of movement/eyelines per scene
- **Temporal links**: previous/next scene; entry state and exit state per scene

### FR-2 Shot-level continuity contracts
Each shot declares what it must preserve: characters' wardrobe/positions at start and end, visible props, lighting continuity, screen direction, and its **dependencies** (e.g., "start state = end state of shot 12"). Contracts are auto-derived from the script/plan and user-editable.

### FR-3 Pre-generation conflict detection
A rule engine evaluates the shot list before generation and reports conflicts with severity:
- Wardrobe change between adjacent same-scene shots without narrative justification
- Prop disappears/teleports; held object mismatch between consecutive shots
- Position/blocking jump inconsistent with elapsed story time
- Lighting/time-of-day change without scene break or stated motivation
- Screen-direction violation (crossing the line)
- Location layout inconsistency
Output: a **Continuity Report** (blocking vs warning), auto-fix suggestions ("carry wardrobe from shot 11"), and one-click propagation fixes.

### FR-4 Reference selection
For each generation task, the engine assembles the optimal reference set: approved character refs (right wardrobe state), location refs, previous shot's end frame (for chaining), style refs — chosen by rule from the scene state, not by the user digging through assets.

### FR-5 Output evaluation (post-generation)
Generated assets are evaluated against their continuity contract using multimodal models: does the character match the approved ref? Wardrobe correct? Prop present? Lighting plausible? Each check returns pass/uncertain/fail with a confidence and a human-review queue. **Honesty rule:** evaluation is advisory scoring, not a guarantee — documented as such.

### FR-6 Selective regeneration
When an output fails evaluation, the user can regenerate *only that shot* with corrected references/instructions; dependent shots are re-checked automatically. No full-project rebuilds (mirrors Gap 2's "regenerate-and-pray" pain).

### FR-7 Scene version history
Scene states, contracts and reports are versioned; every change is attributable (user edit, engine propagation, evaluation outcome).

## 4. User workflows

**W1 — Plan import:** approved production plan arrives → engine builds scenes, initial states and shot contracts automatically → user reviews the continuity view (timeline of states) → approves.

**W2 — Pre-flight:** user hits "Pre-flight check" before generating → report shows 2 blocking conflicts (shot 8: protagonist's jacket changes; shot 14: prop vanishes) → user applies suggested propagations → report goes green → generation unlocked.

**W3 — Review a generated shot:** shot 9 video returns → evaluation: character ✓, wardrobe ✓, prop ✗ (phone missing, confidence 0.82) → flagged in review queue → user chooses: accept (records override with reason), regenerate shot 9 only with corrected references, or edit the contract (phone intentionally absent).

**W4 — Insert a shot:** user adds shot 9A between 9 and 10 → engine derives its contract from neighbours, re-validates 10's start contract against 9A's end state → conflicts surface immediately.

## 5. Data structures

```yaml
Scene:        { id, project_id, sequence, location_ref, time_of_day, weather, lighting_setup, color_treatment, screen_axis, entry_state_ref, exit_state_ref, version }
SceneState:   { id, scene_id, characters:[{character_ref, wardrobe_ref, accessories[], position, emotional_state, held_props[]}], props:[{prop_ref, position, state}], notes, version }
ContinuityContract: { id, shot_ref, preserves:{characters[], wardrobe[], props[], lighting, screen_direction}, depends_on:[shot_refs], start_state_ref, end_state_ref, status }
ContinuityReport:   { id, scope(project/scene/shot), findings:[{rule_id, severity(blocking/warning), description, affected_refs[], suggested_fix, status(open/fixed/overridden), override_reason}], created_at }
ContinuityEvaluation:{ id, generation_ref, contract_ref, checks:[{check, result(pass/uncertain/fail), confidence, evidence_ref}], model_used, created_at }
```

Rules engine: versioned rule set (`continuity_rules_v1`), each rule = predicate over contracts/states + severity + suggestion template. Rules are data, not code, so the set grows without redeploys.

## 6. Dependencies

- **Character Engine** — wardrobe/appearance states, approved references.
- **Shot Planner** — shot ordering, durations, edit events.
- **Cinema Engine** — canonical lighting/camera vocabulary so "lighting continuity" is well-defined.
- **Provider Router** — VLM evaluation calls (multimodal, free-tier eligible); evaluation must be cheap enough to run per generation.
- **Generation Orchestrator** — consumes reference sets and contracts; receives regeneration requests with corrected context.

## 7. API requirements

```
GET    /api/projects/:id/scenes                     # scene list + states
PATCH  /api/scenes/:id/state                        # edit scene state (versioned)
GET    /api/shots/:id/contract                      # continuity contract
PATCH  /api/shots/:id/contract                      # edit contract
POST   /api/projects/:id/continuity:check           # run rule engine → report
GET    /api/reports/:id                             # fetch report
POST   /api/reports/:id/findings/:fid:apply-fix     # apply suggested propagation
POST   /api/reports/:id/findings/:fid:override      # accept with reason
POST   /api/generations/:id/evaluate                # run output evaluation
GET    /api/projects/:id/review-queue               # failed/uncertain checks
```

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Derive contracts/states from script & plan | Mid-tier LLM (structured output) | Intelligence task → free-tier eligible |
| Rule engine evaluation | Deterministic code | No model; instant, testable |
| Output evaluation (identity, wardrobe, props, lighting) | Multimodal VLM | Per-check confidence; cheapest passing model; benchmark-driven routing |
| Fix suggestions & report summaries | Mid-tier LLM | Templates first, LLM for phrasing |

## 9. Technical implementation approach

- **State as data:** scene states are versioned documents; shots reference start/end states by ID, making propagation and diffing trivial and auditable.
- **Two-layer detection:** deterministic rules (fast, explainable, unit-tested) handle structural conflicts; VLM evaluation (probabilistic, confidence-scored) handles perceptual checks. The two never blur: a VLM result never mutates state without user or rule confirmation.
- **Contract derivation pipeline:** script/plan → LLM extraction → user review. Extraction is always editable because automatic extraction will be wrong sometimes (honesty rule from the brief).
- **Event-driven re-validation:** any edit to a shot, scene, character or contract emits an event; affected contracts re-validate in the background; the report is always current, never a stale snapshot.
- **Reference assembly as a pure function:** `assemble_references(contract, asset_store, registry)` → deterministic, testable, and explainable ("these 4 refs because contract requires wardrobe W2 and chains from shot 12's end frame").

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| Contract derivation produces nonsense | User edits before approval; derivation is a draft, never auto-trusted |
| VLM evaluation unavailable/quota exhausted | Evaluation queue pauses; generation results marked `unevaluated` (never silently passed); resumes on quota return |
| Conflicting state edits (collaborators) | Versioned states + conflict UI |
| User overrides a blocking finding | Override recorded with reason; report stays auditable; override never hidden |
| Rule false-positives | Per-rule "not applicable" dismissal feeds a per-project rule-tuning record |
| Long-chain drift despite contracts | Engine recommends chain resets (fresh approved refs) every N shots — policy visible, not hidden folklore like competitors |

## 11. Acceptance criteria

1. Given a 10-shot plan with a deliberately planted wardrobe change and a disappearing prop, the pre-flight report flags both as blocking with correct shot references and working one-click fixes (test suite).
2. Inserting/reordering/deleting a shot re-validates affected contracts within seconds and updates the report (integration test).
3. A failing evaluation marks exactly one shot for regeneration; regenerating it does not touch any other shot's assets (end-to-end test).
4. Every override carries a mandatory reason and appears in the audit trail.
5. Evaluation results always display confidence and the model used; the UI never presents a VLM pass as a guarantee.

## 12. Improvement opportunities over existing products (≥3)

1. **The only structured scene-state system in the market.** Every competitor (Higgsfield, Runway, Kling, Luma, LTX) offers reference anchoring at best; none tracks wardrobe/props/positions/screen direction as queryable state. This converts continuity from folklore into engineering.
2. **Pre-generation conflict detection.** Competitors surface errors only in finished renders (or via post-hoc repair like Genjutsu). Catching conflicts before spend is a direct, demonstrable money saver — and a marketing story ("we found the error before it cost you credits").
3. **Confidence-scored, auditable evaluation with overrides.** Competitor repair tools are opaque one-shots; our evaluation queue is explainable (per-check results, evidence, model used) and every human decision is recorded — essential for teams and agencies.
4. **Dependency-aware selective regeneration** driven by the contract graph, not by the user remembering what might be affected — eliminating the full-rebuild tax competitors impose.

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: **practical detection and evaluation methods** — what we can actually measure, with what models, and where the limits are.*

### 13.1 How it works technically

**Structured scene state is the foundation.** Unlike competitors (Higgsfield continuity = manual techniques: @refs, Elements, frame chaining, F-0006), we persist explicit continuity state per scene:

- `scene_state`: characters present (bindings + sheet versions), wardrobe/appearance deltas, location reference assets, lighting/time-of-day, props, colour grade, emotional register.
- `shot_state_in/out`: per shot, the expected entering/exiting state (character positions, wardrobe, prop continuity) generated when the shot list is drafted.

**Detection pipeline (three layers, cheapest first):**

1. **Deterministic checks (worker, no model).** Metadata-level validation runs on every generated asset: aspect ratio, duration, resolution, colour-profile stats (histogram distance vs scene palette from the art direction artefact), presence of required reference-conditioning inputs. These catch hard failures (wrong aspect, palette wildly off) at zero model cost.
2. **Embedding-similarity checks (worker, cheap).** Perceptual embeddings of generated frames are compared against: (a) the character sheet embeddings for each bound character, (b) the previous shot's last frame where shots are chained, (c) location reference embeddings. Distances above per-relation thresholds flag `suspect`. Thresholds are workspace-tunable and initially conservative (flag, don't block).
3. **Multimodal LLM evaluation (q.intel, structured).** A Gemini-Flash-class model receives the shot's declared `state_in/out` + the generated frames and answers a **fixed evaluation rubric** (character identity preserved? wardrobe consistent? prop present? lighting coherent with scene?) returning structured JSON per dimension with confidence. The rubric is versioned; results are stored per asset (`continuity_evaluations`) and aggregate into the workspace's per-model acceptance-rate telemetry (the same numbers the Cost Estimator uses — evaluation is not a side show, it prices future work).

**Conflict detection at planning time.** Before generation, the engine diffs consecutive shots' declared states: wardrobe change without an intervening scene boundary, prop vanishing, time-of-day jump, character present in `state_out` of shot N but absent from `state_in` of shot N+1. These are **deterministic DAG checks** over structured state — caught free, before money is spent.

**Repair paths.** Flagged assets offer three actions: (a) accept anyway (recorded), (b) regenerate with stricter conditioning (same shot, bumped reference weight / different seed — a targeted retry, cost-estimated before execution), (c) escalate to user edit of the shot state. Frame-chaining repair (use last good frame as I2V input, the manual technique competitors document, F-0006) is available as an explicit user-invoked action with cost preview.

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| Scene/shot state | shot planner + user edits | `scene_states`, `shots.state_in/out` |
| Character embeddings | worker from confirmed sheets | `asset_embeddings` (pgvector) |
| Evaluation rubric | curated, versioned | `eval_rubrics` |
| Evaluation results | multimodal LLM | `continuity_evaluations` |
| Acceptance telemetry | aggregated outcomes | `provider_model_stats` |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Deterministic metadata checks | none (classical CV) | worker | Exact |
| Embedding similarity | open embedding model (image) | self-hosted in worker / Workers AI | Distance ≠ identity proof; thresholds conservative |
| Rubric evaluation | multimodal LLM | Gemini Flash free tier | Advisory; false accepts/rejects exist (§13.4.2) |
| Repair regeneration | image/video models | router | Paid, cost-previewed before execution |

### 13.4 Limitations (stated honestly)

1. **Detection is probabilistic past layer 1.** Embedding distance and LLM rubrics both produce false flags and false passes. The system is designed as **decision support with full evidence display** (scores, compared frames side-by-side), not an auto-acceptance gate. We do not market "guaranteed continuity".
2. **Evaluation LLM bias.** A Flash-class evaluator may systematically miss subtle identity drift that a human catches (and vice versa). Rubric versions and their measured agreement with user accept/reject decisions are tracked; rubric changes are data migrations, not silent edits.
3. **Cold-start thresholds.** Initial thresholds are set from research, not from our corpus; they will need one calibration pass per workspace (the first ~20 evaluated assets tune flag sensitivity). Until then the UI says "calibrating".
4. **Continuity across video models is the hardest case.** Identity conditioned through different video models drifts differently; our state model is model-agnostic but measured drift is per-route. Cross-model shot chains are flagged as higher-risk by default.
