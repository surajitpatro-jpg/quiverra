# System Specification — Character Intelligence Engine

**System 2 of 7 · Priority P1 · Version 0.2 · 2026-11-09**
Depends on: Shared Project Model, Provider Router (image/VLM tasks), Continuity Engine (consumes character state), Cinema Engine (consumes appearance descriptors).
Evidence base: Gap 3 — character systems are face-deep (F-0005 Soul ID: visual-only, platform-locked, quota-limited, "high not absolute" consistency by their own admission; F-0011 Kling voice-bound Elements; F-0012 Luma Master Reference Assets).

---

## 1. Purpose

A persistent, structured **character management system**: characters are durable assets with identity, wardrobe, personality, expressions, movement and voice — versioned, approvable, reusable across projects — not temporary prompts. The engine also tracks **what each AI model can actually do** with character references, and evaluates generated outputs against the approved identity.

## 2. User problems (evidence-backed)

1. **Characters are prompts everywhere else.** Except Soul ID (visual identity only), every platform re-anchors characters per generation via reference images — and per Higgsfield's own blog, "consistency is high, not absolute" with drift on extreme styles/angles (F-0005).
2. **Identity is shallow.** No competitor stores wardrobe variants, personality, expression ranges, gesture/movement characteristics, or voice profile as structured data (Gap 3).
3. **Identity is imprisoned.** Soul ID is platform-locked and cannot be exported; per-plan character quotas (1/6/33/100 per month) artificially cap cast size (F-0005).
4. **No versioning or approval.** Teams can't say "this is the approved look for campaign B" or roll back a character change — nothing tracks it.
5. **Dishonest expectations.** Uploading a reference image is marketed as identity preservation; actual per-model behaviour varies wildly and is undocumented (brief explicitly forbids claiming reference uploads guarantee identity).

## 3. Functional requirements

### FR-1 Structured character identity
Every character is a record: ID, name, physical appearance, facial characteristics, body type, hair, skin/visible characteristics, **wardrobe sets** (named outfits with descriptions + reference images), accessories, personality, **expression range** (named expressions with reference frames), gestures, movement characteristics, voice characteristics (where supported), notes.

### FR-2 Reference management
Upload/attach reference images; organise into **reference sheets** (front/profile/three-quarter, expressions, wardrobe variants); mark images approved/rejected; per-image quality assessment (resolution, face visibility, angle coverage) with guidance — because garbage-in-garbage-out is the documented #1 cause of identity failure (F-0005).

### FR-3 Character versions and approval states
Versions per character (`draft → in_review → approved → locked`); a locked approved version is what production consumes; changes create new versions; full diff and rollback.

### FR-4 Cross-project reuse with permissions
Characters live at library level (user/org), attach to projects by reference; roles and permissions (owner/editor/viewer; org-shared vs private); usage tracking ("used in 4 projects, 87 shots").

### FR-5 Model capability mapping
Per character + per target model, the engine records what identity mechanisms the model actually supports (from the Model Capability Registry): native reference conditioning, multi-reference, trained identity (e.g., Soul-ID-style), face-swap post-processing, or prompt-only — and sets expectations accordingly in the UI. **Never claim guarantees the model doesn't provide.**

### FR-6 Reference selection for generation
Given a shot's requirements (wardrobe W2, expression E4, angle), select the optimal reference set from approved sheets automatically (consumed by the Continuity Engine's reference assembly).

### FR-7 Identity evaluation
VLM-based scoring of generated outputs against approved references (likeness, wardrobe correctness, attribute drift) with per-check confidence — feeding the Continuity Engine's evaluation queue.

### FR-8 Voice profile (where supported)
Voice characteristics as structured descriptors; linkage to voice-clone providers when available; consent/likeness metadata fields (legal hygiene for commercial use).

## 4. User workflows

**W1 — Create a character:** Library → New Character → describe or upload refs → engine drafts the structured profile (VLM-assisted attribute extraction from refs, user-editable) → user completes wardrobe/expressions → builds reference sheet → quality check passes → submit for approval → locked v1.

**W2 — Cast a project:** plan requires "protagonist, hotel manager, 2 guests" → user attaches library characters or creates new ones → continuity contracts reference character versions, so a mid-production character edit flags exactly the affected shots.

**W3 — Campaign variant:** character approved for campaign A → user creates v2 with new wardrobe set for campaign B → v1 untouched; both usable; usage tracked.

**W4 — Drift handling:** evaluation flags shot 22 (likeness 0.71, threshold 0.8) → user reviews → regenerates with a stronger reference set (engine suggests: add profile-angle ref) or overrides with reason.

## 5. Data structures

```yaml
Character:      { id, owner(org/user), name, status, current_version_ref, visibility, usage_stats, created_at }
CharacterVersion: { id, character_ref, version, identity:{appearance, face, body, hair, skin, accessories[], personality, expressions[{name, ref_images[]}], gestures[], movement[], voice_profile}, wardrobe_sets:[{id, name, description, ref_images[]}], reference_sheets:[{id, kind(front/profile/three_quarter/expression/wardrobe), images[], quality_report}], approval:{state, by, at}, parent_version_ref }
IdentityEvaluation: { id, character_version_ref, generation_ref, checks:[{check, score, confidence}], model_used, created_at }
```

## 6. Dependencies

- **Provider Router** — VLM extraction, quality assessment, identity evaluation (all intelligence tasks, free-tier-eligible models where quality permits).
- **Continuity Engine** — consumes character versions + wardrobe states; supplies evaluation results.
- **Generation Orchestrator** — receives reference sets + identity descriptors compiled per model capability.
- **Asset Library** — reference images and sheets stored as managed assets.

## 7. API requirements

```
POST   /api/library/characters                      # create
GET    /api/library/characters                      # list (filter by project, org, status)
PATCH  /api/characters/:id                          # edit (creates draft version)
POST   /api/characters/:id/references               # upload refs → quality report
POST   /api/characters/:id/sheets:build             # organise reference sheet
POST   /api/characters/:id:approve | :lock          # approval workflow
POST   /api/characters/:id/versions                 # new version (diff from parent)
POST   /api/characters/:id/versions/:v:rollback
GET    /api/characters/:id/capability-map           # per-model identity support
POST   /api/characters/:id/evaluate                 # identity evaluation of a generation
GET    /api/characters/:id/usage                    # projects/shots using it
```

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Attribute extraction from refs | Multimodal VLM | Draft only; user confirms |
| Reference quality assessment | VLM + deterministic checks (resolution, blur) | Fast, per upload |
| Identity evaluation | Multimodal VLM | Per-check scores + confidence; benchmark-driven model choice |
| Voice descriptors → clone request | Provider-specific | Only where provider supports cloning; consent metadata mandatory |

## 9. Technical implementation approach

- **Identity as structured data, descriptors as compilation:** generation prompts/instructions are *compiled* from the structured identity per target model's capability map — the same character renders as a reference-set + descriptor block on one model and a trained-identity call on another. The character record is provider-independent (anti-lock-in by design, contra Soul ID).
- **Versioning like code:** immutable versions, parent links, diffs; production always pins a version so edits never silently alter in-flight work (matches ADR-0007's frozen-snapshot rule).
- **Quality gates on input:** reference quality report before approval — prevention, since the market's documented failure mode is bad input (F-0005).
- **Evaluation thresholds are policy:** likeness/wardrobe thresholds configurable per project (social content vs brand campaign), with overrides always audited.

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| Poor reference uploads | Quality report blocks approval with specific guidance ("need 1 profile angle ≥960px") |
| VLM extraction wrong | Draft is user-edited before saving; extraction never auto-commits |
| Model lacks identity support | Capability map says so plainly; engine compiles best-effort descriptor and sets expectation ("approximation — review outputs") |
| Identity evaluation unavailable (quota) | Generations marked `unevaluated`, queued; never silently passed |
| Character edited mid-production | Downstream shots flagged stale via events; frozen generation snapshots unaffected |
| Likeness/consent metadata missing (org policy) | Voice-clone tasks blocked until metadata complete |

## 11. Acceptance criteria

1. A character round-trips: create → refs → quality report → sheet → approve → lock → attach to two projects → v2 variant → rollback to v1 (integration test).
2. Capability map returns honest per-model mechanisms for at least the registry's initial model set; no UI copy claims guaranteed identity (copy audit test).
3. Reference selection for a shot with (wardrobe W2, profile angle) returns exactly the matching approved refs (unit test).
4. Editing a locked character version flags precisely the dependent shots (event test with Continuity Engine).
5. Identity evaluation produces per-check scores with confidence and model identity recorded; sub-threshold results route to the review queue.

## 12. Improvement opportunities over existing products (≥3)

1. **Depth beyond the face.** Soul ID (best-in-class) stores a visual identity; we store wardrobe sets, expressions, gestures, movement, personality and voice as structured, compilable data — the difference between a face reference and a cast member.
2. **Portability and no artificial scarcity.** Competitor identities are platform-locked and quota-capped (Soul ID: 1/6/33/100 per plan). Our character records are provider-independent user data; any model with suitable capability can consume them.
3. **Versioning + approval + permissions** — team-grade asset governance (locked versions, diffs, rollback, org sharing) that no competitor offers for characters at all.
4. **Honesty as a feature:** a per-model capability map that tells the user exactly what identity mechanism applies and what to expect — versus the industry norm of overpromising reference conditioning (brief-mandated, and a trust differentiator).

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: character sheets, multiple reference angles, identity management, reusable assets — exact mechanics, data, models, limitations.*

### 13.1 How it works technically

**Character sheet generation.** A character is created from a text description (from the Production Plan) and/or user-uploaded face/body references. The engine builds a **structured Character Sheet** artefact:

1. **Canonical description.** An LLM produces a normalised identity description: face geometry descriptors, hair, eyes, skin, build, wardrobe, distinguishing marks — stored as structured fields, not prose, so they can be slot-filled into prompts deterministically.
2. **Multi-angle reference set.** The engine commissions a standard angle sheet via the image router: `front_portrait, three_quarter, profile, full_body_front, full_body_back` (+ optional expression set: neutral/smile/serious). Each angle is a separate generation job with the **same seed** where the target model supports native seed control (registry `seed_control: native`, e.g. Runway Fix Seed pattern, F-0030), and with the canonical description slot-filled identically otherwise. This directly addresses the user requirement for multiple reference angles.
3. **Consistency screening.** Returned angles are scored for identity agreement (§13.3) and flagged `consistent` / `review` / `reject`. Rejected angles auto-regenerate once with a different seed before surfacing to the user. The user confirms the sheet; confirmed sheets are immutable and versioned (`character_sheet_versions`).

**Identity management.** A character is a first-class entity (`characters`) with: canonical description, confirmed sheet (asset IDs per angle), wardrobe variants, age/register variants, and per-project usage history. Identity is **portable within the platform**: the same character binds to storyboard shots, image generation and video generation across projects. This is deliberately unlike Higgsfield Soul ID, which is platform-locked and non-exportable (F-0027) — our characters are user assets, exportable as image sets + description JSON.

**Reusable asset binding (structured, not @-mentions).** LTX's primary inconsistency cause is a missing @-mention in shot text (F-0033). We eliminate that failure mode: shots carry a **structured `character_bindings` array** (`character_id` + `sheet_version_id`); prompt assembly injects the character's canonical description + reference images mechanically. There is no natural-language mention to forget. The binding is enforced by the Storyboard schema — a shot with a cast role and no binding fails validation.

**Generation-time conditioning.** At image generation, the router prefers models whose registry row shows `reference_images.honesty ∈ {native, reference_conditioned}` (e.g. Nano Banana 2 via fal, F-0021). Reference images (the confirmed sheet angles) are passed per the model's input schema; the honesty class is shown in the UI so the user knows whether identity conditioning is native or prompt-approximated.

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| Character descriptions | LLM normalised | `characters.canonical` (JSONB) |
| User face/body uploads | user | R2 + `assets` (workspace-scoped) |
| Angle sheet images | generation | R2 + `assets`, linked in `character_sheet_versions` |
| Consistency scores | worker eval | `character_sheet_versions.scores` |
| Reference-capable model data | registry | pinned per generation job |
| Bindings | storyboard schema | `shots.character_bindings` |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Canonical description | LLM text | Groq free | Deterministic slot-fill downstream |
| Angle sheet generation | Image model w/ seed + reference support | fal flux-2 / Nano Banana 2 (registry-ranked) | Paid stage; per-angle cost estimated pre-run |
| Identity agreement scoring | Multimodal LLM pairwise comparison + face-embedding distance where a suitable open model is registered | Gemini Flash / self-host candidate | Screening aid, **not a guarantee** — user confirmation is the authority |
| Angle regeneration | same as generation | router | one auto-retry, then human |

### 13.4 Limitations (stated honestly)

1. **No identity training at MVP.** We do not train LoRA/dreambooth-style identity models in MVP (Higgsfield Soul ID trains on 20–80 photos, F-0027). Our conditioning is reference-image + canonical-description based, which is weaker under extreme style/angle shifts — the same caveat Higgsfield itself publishes ("consistency is high, not absolute", F-0005). Trained-identity support is a post-MVP registry capability, not a redesign.
2. **Cross-model identity drift.** Identity conditioned on model A does not transfer perfectly to model B. The sheet is model-agnostic data, but per-model conditioning quality varies; the UI shows the honesty class per route and the continuity engine measures drift downstream.
3. **Screening is advisory.** Automated identity scoring can rank candidates but false accepts/rejects occur; the user's confirmation click is the contract. We never claim automated consistency guarantees.
4. **Real-person uploads** carry consent/rights obligations — upload flow includes a rights attestation; voice/face cloning of real persons is out of MVP scope.
