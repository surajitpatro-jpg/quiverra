# System Specification — Cinema Intelligence Engine

**System 3 of 7 · Priority P2 · Version 0.2 · 2026-11-09**
Depends on: Model Capability Registry (per-model parameter support), Provider Router, Shot Planner (consumes compiled instructions), Continuity Engine (lighting/camera state vocabulary).
Evidence base: Gap 4 — cinematic controls without honesty or depth (F-0004 Higgsfield presets, F-0011 Kling Motion Brush as strongest direct control; no platform discloses which controls are model-native vs prompt-approximated, F-0016).

---

## 1. Purpose

Translate professional cinematography — camera, lens, movement, shot type, lighting — into **per-model generation instructions that honestly reflect what each model can do**, making professional control accessible without fake knobs. Every control in the UI is classified by mechanism and evidence, and the classification is visible to the user.

## 2. User problems (evidence-backed)

1. **Fake controls erode trust.** Platforms present camera "controls" that are often just prompt adjectives; users can't tell which settings genuinely affect output (Gap 4; brief explicitly: "Do not create fake camera controls that have no meaningful effect").
2. **Professional vocabulary is flattened.** Cinematographers think in focal length, DoF, camera height, motivated lighting; tools offer "cinematic" presets with no semantics (Higgsfield presets are the best available and still opaque).
3. **The same words behave differently per model.** "Dolly in" on Kling vs Seedance vs Veo produces different results; no platform documents or normalises this.
4. **Direct manipulation is rare.** Kling's Motion Brush (drawn motion paths) proved demand for direct control (F-0011); everywhere else, movement is text.

## 3. Functional requirements

### FR-1 Cinematography vocabulary (canonical, versioned)
Controlled vocabularies used across the whole platform:
- **Camera characteristics:** camera type, sensor format, lens family, focal length, aperture, depth of field, camera height, angle, distance
- **Movements:** dolly in/out, tracking, orbit, crane, pan, tilt, handheld, zoom, push-in, pull-out, static, slow motion
- **Shot types:** EWS, WS, MS, MCU, CU, ECU, OTS, POV, establishing
- **Lighting:** natural, studio, hard, soft, back, rim, practical, cinematic contrast, time-of-day

### FR-2 Control classification system
Every (control × model) pair carries a mechanism class with evidence:
- `native` — the model/API exposes a real parameter or verified behaviour (evidence-linked)
- `prompt_approximated` — achievable via prompt language, reliability rated (high/medium/low) from our benchmarks
- `reference_conditioned` — requires reference images/frames (e.g., composition from a start frame)
- `unsupported` — the model does not respond to this control; the UI disables it for that model
Classifications are benchmark-backed, dated, and re-verified on model updates (stored in the Model Capability Registry).

### FR-3 Instruction compiler
Input: a shot's cinematography record (from the Shot Planner) + target model. Output: compiled generation instructions — native parameters where supported, crafted prompt language where approximated, reference requirements where conditioned — plus an **honesty report**: "focal length: prompt-approximated (medium reliability); camera move: native".

### FR-4 Direct controls where feasible
Frame-space movement paths (Motion-Brush-style) for models supporting them; start/end frame conditioning for composition control; camera-path presets as data (shareable, versioned), not marketing copy.

### FR-5 Lighting continuity integration
Lighting setups are named, reusable records (used by the Continuity Engine to detect unmotivated changes); time-of-day and motivation are first-class fields.

### FR-6 Education layer
Inline, optional explanations of professional concepts (what a 35mm vs 85mm look implies, when OTS is used) — professional depth, accessible surface.

## 4. User workflows

**W1 — Shot cinematography:** user opens shot 8 → picks shot type (MCU), movement (slow push-in), lens intent (85mm, shallow DoF), lighting (golden-hour natural, soft) → honesty panel shows per-model behaviour → user picks model accordingly (or accepts approximation knowingly).

**W2 — Model comparison:** user runs the same cinematography record across two models in compare mode → sees the honesty report differ ("native movement on Kling-class vs approximated on Model B") → chooses knowingly.

**W3 — Cinematography language from the Director Engine:** the production plan's camera recommendations arrive pre-filled per shot → user adjusts → compiler regenerates instructions → no prompt-writing ever required.

## 5. Data structures

```yaml
CinematographyRecord: { shot_ref, camera:{type, sensor_format, lens_family, focal_length_mm, aperture, dof, height, angle, distance}, movement:{kind, speed, path_ref}, shot_type, lighting:{setup_ref, time_of_day, motivation}, notes }
LightingSetup:        { id, name, kind, description, reference_images[], colour_temperature, contrast, motivation }
ControlClassification:{ registry_entry(model), control, mechanism(native/prompt_approximated/reference_conditioned/unsupported), reliability(high/medium/low), evidence_ref, verified_at }
CompiledInstructions: { shot_ref, model, native_params{}, prompt_blocks[], required_references[], honesty_report[], compiled_at, registry_version }
```

## 6. Dependencies

- **Model Capability Registry** — stores classifications; versioning ties compiled output to evidence.
- **Shot Planner** — owns cinematography records per shot; consumes compiled instructions for generation jobs.
- **Continuity Engine** — consumes lighting setups and camera direction for conflict rules (screen direction, lighting continuity).
- **Provider Router** — executes with native params where available.

## 7. API requirements

```
GET    /api/cinema/vocabulary                       # canonical vocabularies
GET    /api/cinema/capabilities?model=..            # control classifications per model
POST   /api/shots/:id/cinematography                # set cinematography record
POST   /api/shots/:id/compile?model=..              # → CompiledInstructions + honesty report
GET    /api/cinema/lighting-setups                  # reusable setups
POST   /api/cinema/movement-paths                   # direct-control paths (where supported)
```

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Instruction compilation | Deterministic code + templates | No model; fully testable |
| Classification benchmarking | Executed generations across models | Offline benchmark harness; results → registry (evidence) |
| Reliability re-verification | Same harness on model updates | Scheduled; classification carries `verified_at` |
| Education content | Static authored content | No model |

## 9. Technical implementation approach

- **Vocabulary as platform-wide data:** one canonical, versioned vocabulary consumed by Shot Planner, Continuity Engine and compiler — so "soft backlight" means the same thing in planning, continuity rules and generation instructions.
- **Compiler as pure function:** `(cinematography record, registry entry) → instructions + honesty report`. Deterministic, unit-testable, reproducible against a registry version (aligns with ADR-0005/0007).
- **Benchmark harness:** scripted probe generations per model per control (e.g., "static vs dolly-in" pairs), VLM-assisted judgement of whether the control manifested, human spot-review; results land in the registry with evidence links. This is how classifications stay honest over time.
- **Degrade gracefully:** when a model lacks a control, the compiler substitutes the best available mechanism and says so — the UI never silently pretends.

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| Model updates change behaviour | Scheduled re-verification; stale classifications flagged (`verified_at` age badge) |
| Control unsupported by chosen model | Control disabled with explanation + nearest alternative suggestion |
| Approximated control fails in output | Surfaced in shot evaluation as "control not manifested" → user regenerates, switches model, or accepts |
| Benchmark evidence insufficient | Classification defaults to `unknown` → UI shows "unverified" rather than guessing |
| Vocabulary conflict across systems | Single source of truth; migrations versioned |

## 11. Acceptance criteria

1. For every model in the initial registry, each vocabulary control has a classification with evidence or is marked `unknown` — no unclassified controls (registry audit).
2. Compiling the same record twice against the same registry version yields identical instructions (determinism test).
3. A shot set to a model-native movement emits native params; the same shot on a prompt-only model emits prompt language + honesty report entry (unit tests).
4. Unsupported controls are disabled in the UI for that model (UI contract test).
5. Benchmark pipeline produces classification updates with evidence references (harness dry-run).

## 12. Improvement opportunities over existing products (≥3)

1. **The industry's first honest control taxonomy.** Higgsfield sells camera presets without disclosing mechanism; we classify every control (native / approximated / conditioned / unsupported) with dated evidence — professionals can finally trust the knobs.
2. **Depth competitors don't expose:** focal length, aperture, DoF, camera height, motivated lighting as structured semantics compiled per model — not a "cinematic" toggle.
3. **Cross-model normalisation:** one cinematography intent, correctly compiled per model with visible trade-offs — versus each platform pretending its vocabulary is universal.
4. **Benchmark-driven re-verification:** our classifications are living, evidence-backed data (a moat that compounds), while competitor claims are static marketing.

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: **actual model-specific camera and motion capabilities, not just prompt-based controls** — the evidence-backed capability model.*

### 13.1 How it works technically

**The capability model is the product.** Every video model version in the registry carries a structured `motion_capabilities` block, seeded from the verified research (Provider-Research-Video §3, F-0030..F-0033) and updated by live schema introspection where providers expose machine-readable input schemas (fal does; Replicate exposes per-version OpenAPI schemas):

```yaml
# registry row excerpt — capability data with evidence traceability (ADR-0009)
model_version: kling-3.0-pro@fal
motion_capabilities:
  camera_move:        { honesty: prompt_approximated }        # no dedicated API param verified
  keyframes:          { honesty: native, positions: [first, last], max_count: 2 }
  motion_control:     { honesty: native, mode: i2v_only, reference_video: required,
                        ref_duration_s: [2, 5], orientation_modes: [matches_video, matches_image],
                        character_refs_api: 1 }                 # F-0031
  motion_strength:    { honesty: reference_conditioned, param: cfg_scale, range: [0.0, 1.0] }  # PV
  seed_control:       { honesty: unsupported }
  extend:             { honesty: native }
model_version: luma-ray3.2@…
motion_capabilities:
  keyframes:          { honesty: native, max_count: 16 }      # F-0032
  motion_strength:    { honesty: native, param: motion_slider, range: [1, 9],
                        decoupled_from: structure_slider }      # F-0032
  hdr_exr:            { honesty: native }                     # F-0032
```

**Translation, not pass-through.** The Cinema Engine exposes a **provider-independent shot control vocabulary** to the user (camera: pan/tilt/zoom/roll/dolly/static; motion intensity 0–1; keyframe pins; seed lock). At generation time, the translator resolves each control against the selected model's capability row:

- `native` → emit the model's actual API parameter (e.g. keyframe image slots, motion slider value).
- `reference_conditioned` → supply reference media + parameter and **label the shot** in the UI ("motion driven by reference video").
- `prompt_approximated` → compile the control into a constrained prompt clause from a maintained clause library (e.g. "slow lateral dolly right, constant speed"), and label the shot accordingly.
- `unsupported` → the control is refused for that model with an explanation and a router suggestion of models that do support it. **Never silently approximate an unsupported control** — this is the platform's core honesty contract and the direct answer to competitors' opaque controls.

**Capability-aware shot planning.** When the Storyboard/Shot Planner drafts camera moves, it queries the registry first: shots are planned against what the routed models can actually do, and the shot list shows per-shot feasibility badges before any money is spent. A shot requiring 16-position keyframe choreography will be planned only against models with native multi-keyframe support (e.g. Ray3.2-class rows), or explicitly decomposed into multiple shots otherwise.

**Camera language library.** A curated, versioned dataset of cinematography vocabulary (shot sizes, move grammars, lens/DoF descriptors, lighting setups) maintained as data (`cinema_lexicon` table). Prompt compilation selects clauses from this lexicon — no freehand prompt invention at generation time, which keeps prompt-approximated controls reproducible and testable.

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| Per-model motion capabilities | verified research + live schema introspection | registry rows (`evidence_id` per claim, ADR-0009) |
| Provider input schemas | fal/Replicate schema endpoints | introspection job snapshots |
| Cinematography lexicon | curated seed | `cinema_lexicon` (versioned) |
| Shot control intent | storyboard/shot planner | `shots.camera`, `shots.motion` |
| Control-resolution audit | translator | `generation_jobs.control_resolution` |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Camera/move intent interpretation from script | LLM text | Groq free | Structured output, schema-validated |
| Prompt-clause compilation | none (template slot-fill) | worker | Deterministic from lexicon |
| Actual video generation | video models via router | fal / Replicate / Kling direct / Runway Dev / Gemini | Paid; capability-gated per §13.1 |
| Control verification (did the output move as asked?) | multimodal LLM eval | Gemini Flash | Advisory flag only — see §13.4.3 |

### 13.4 Limitations (stated honestly)

1. **Capability data decays.** Providers ship model updates that change control surfaces (Kling 4.0 reached Runway Dev before Kling's own API, F-0038). Registry rows pin **model versions**; new versions start with `honesty: unknown` until introspected/researched. Stale rows (>30 days unverified) show a badge, matching the Creative Director's estimate badge rule.
2. **Prompt-approximated camera control is genuinely unreliable.** Industry-wide, text-only camera direction has low compliance. We mitigate (lexicon clauses, feasibility badges, eval flags) but do not claim compliance rates; per-model acceptance telemetry will eventually quantify it per route.
3. **Output-side verification is advisory.** Multimodal eval can flag "camera did not move as requested" but has false positives; it informs the retry decision (Workflow Engine) and the acceptance-rate stats — it never auto-refunds or auto-approves.
4. **No parametric camera API exists at most providers.** Where the market ships one (Runway's panel is app-side; its API surface differs), the registry captures the API truth, not the marketing page.
