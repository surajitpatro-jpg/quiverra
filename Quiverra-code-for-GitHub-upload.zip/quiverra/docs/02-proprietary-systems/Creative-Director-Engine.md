# System Specification — Creative Director Engine

**System 1 of 7 · Priority P0 · Version 0.2 · 2026-11-09**
Depends on: Shared Creative Project Model (§6 of brief), Provider Router (System 7 infra), Brand Engine (optional input), Character Engine (output contract).
Evidence base: `docs/01-competitive-research/` — Gap 1 (no brief→plan OS), Gap 7 (no cost estimation before spend).

---

## 1. Purpose

Convert an unstructured creative brief ("a premium 30-second cinematic ad for a luxury hotel in Goa") into a **structured, editable, costed production plan** that the user reviews and approves before any paid generation begins. This is the central intelligence layer of the platform: every other system consumes its output.

## 2. User problems (evidence-backed)

1. **Planning is invisible in every competitor.** Higgsfield Supercomputer plans ad-hoc in chat and its artefact is generations, not a plan (F-0004). LTX jumps from script to storyboard without concept/cost stages (F-0014). Users currently re-plan in their heads or in external docs.
2. **No cost visibility before spend.** Every competitor shows cost per generation step at most (Higgsfield Supercomputer), never a project-level estimate (Gap 7). Users burn credits discovering what a project costs.
3. **Creative decisions are lost.** Chat-based planning (all agentic competitors) leaves no record of *why* decisions were made; nothing is reusable across projects.
4. **Briefs are ambiguous.** Professional users think in outcomes, not prompts. Today they must hand-translate intent into per-model prompt craft.

## 3. Functional requirements

### FR-1 Brief interpretation
Accept free-text brief (any length), optional attachments (references, brand URL, script draft), and optional constraints (budget cap, duration, aspect ratios, deadline). Produce a **Creative Interpretation** record: objective, audience, tone, deliverables, constraints, open questions. If the brief is critically ambiguous, the engine generates targeted clarification questions (max 5) instead of guessing.

### FR-2 Concept development
Generate 2–4 distinct **Creative Concepts** per brief: title, logline, narrative approach, visual direction, mood keywords, colour palette (hex values), art direction notes, reference-style descriptors, rationale. User selects/edits/merges concepts; rejected concepts are archived with reasons (feeds the Creative Decision Graph).

### FR-3 Production planning
From the approved concept, generate the full **Production Plan**:
- Story & narrative outline (acts/beats)
- Script (scene-structured, dialogue + action lines)
- Character requirements (roles → handed to Character Engine)
- Location, environment and prop requirements
- Scene breakdown
- Shot list draft (per shot: type, duration, camera, lighting, purpose)
- Audio direction (music mood, VO, SFX)
- Generation recommendations (candidate models per task, from the Capability Registry)
- **Cost estimate** per scene/shot/total, in credits and money, across routing policies (cost-optimised / quality-optimised / balanced)

### FR-4 Review and approval workflow
Every stage (interpretation → concepts → plan) is an explicit, editable artefact with an approval state (`draft → in_review → approved → locked`). Downstream stages unlock only on approval. All edits are versioned; the engine re-validates downstream artefacts when upstream decisions change (impact analysis: "this concept change affects 6 shots").

### FR-5 Regeneration and iteration
Any artefact can be regenerated with guidance ("shorter", "more premium", "change the ending") — the engine diffs old vs new and preserves user edits where possible.

### FR-6 Persistence
All outputs are first-class records in the Shared Creative Project Model, reusable across projects (a concept can seed multiple campaigns).

## 4. User workflows

**W1 — New project from brief:** Dashboard → New Project → paste brief → engine returns interpretation + clarifying questions → user answers → 3 concepts presented as cards (visual direction, palette, rationale) → user picks/edits one → engine drafts production plan → user walks the plan sections (script, characters, shots, cost) approving or editing each → plan locked → handoff to Storyboard & Shot Planner with one click.

**W2 — Iterate on cost:** user sees estimate "₹X / $Y, 34 credits, ~9 min wall-clock" → switches routing policy to cost-optimised → engine re-estimates, flags quality trade-offs per shot ("shots 3, 7 drop from Veo-class to Seedance-class") → user approves.

**W3 — Change of mind mid-production:** user edits the script after storyboard exists → engine lists impacted scenes/shots → user confirms → affected shots marked `stale`, untouched shots preserved (selective invalidation, never full rebuild).

## 5. Data structures (core entities — full schema in Phase 4 `Database-Architecture.md`)

```yaml
CreativeBrief:        { id, project_id, raw_text, attachments[], constraints{budget_cap, duration_s, aspect_ratios[], deadline}, status }
CreativeInterpretation:{ id, brief_id, objective, audience, tone[], deliverables[], open_questions[], version, approval_state }
CreativeConcept:      { id, brief_id, title, logline, narrative_approach, visual_direction, mood_keywords[], palette[{hex, role}], art_direction, rationale, status(selected/rejected/archived), rejection_reason }
ProductionPlan:       { id, project_id, concept_id, narrative_outline, script_ref, character_requirements[], location_requirements[], prop_requirements[], scene_breakdown[], shot_list_draft[], audio_direction, generation_recommendations[], cost_estimate_ref, version, approval_state }
CreativeDecision:     { id, project_id, artefact_ref, decision_type, chosen_option, alternatives[], rationale, made_by(user/engine), timestamp }   # Creative Decision Graph node
CostEstimate:         { id, plan_ref, per_task[{task_ref, model_candidates[], credits_low, credits_high, usd_low, usd_high}], policy, total, computed_at, registry_version }
```

## 6. Dependencies

- **Provider Router** (intelligence tasks routed to low-cost LLMs; FR-3 recommendations query the Model Capability Registry).
- **Shared Project Model** (all entities).
- **Character/Location/Prop systems** consume requirement lists and return resolved asset references.
- **Storyboard & Shot Planner** consumes the approved shot list draft.
- **Scene & Continuity Engine** receives scene structure and initial scene state.
- **Brand Engine** (when a brand profile is attached): concepts and script are generated under brand rules; compliance flagged at concept stage, not after generation.

## 7. API requirements (REST, backend-only)

```
POST   /api/projects/:id/briefs                    # submit brief → starts interpretation job
GET    /api/briefs/:id/interpretation              # fetch interpretation + open questions
POST   /api/briefs/:id/answers                     # submit clarification answers
POST   /api/briefs/:id/concepts:generate           # generate N concepts
PATCH  /api/concepts/:id                           # edit concept
POST   /api/concepts/:id:select                    # select + archive others (records decisions)
POST   /api/concepts/:id/plan:generate             # draft production plan
PATCH  /api/plans/:id                              # edit plan sections (fine-grained paths)
POST   /api/plans/:id/estimate                     # recompute cost estimate (policy param)
POST   /api/plans/:id:approve                      # approve/lock plan → emits PlanApproved event
GET    /api/plans/:id/impact?change=...            # impact analysis preview
POST   /api/artefacts/:id/regenerate               # guided regeneration
```
Long-running steps (concept generation, full plan draft) run as queued jobs with progress events; the API returns job handles, never blocks.

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Brief interpretation, clarification questions | Mid-tier LLM (free-tier eligible) | Structured-output (JSON schema) required |
| Concept generation | Strong creative LLM | Temperature diversity across the N concepts |
| Script + narrative | Strong creative LLM | Long-context for feature-length scripts |
| Cost estimation | Deterministic code, not a model | Reads registry rates; model only explains trade-offs |
| Impact analysis | Mid-tier LLM + graph diff | Deterministic diff first, LLM summarises |
| Palette/mood extraction from references | Multimodal model (free-tier eligible) | Only when user attaches references |

Routing rule (per brief §7.2): all of the above are **creative intelligence** tasks → cheapest model that passes our quality bar; no paid generation model is ever invoked by this engine.

## 9. Technical implementation approach

- **Pipeline, not a chatbot:** a staged state machine (`interpreting → clarifying → concepting → planning → estimating → review → locked`) with each stage a queued, retryable job. Chat is a UI convenience layered on artefacts, never the artefact itself.
- **Structured output everywhere:** every LLM call validates against a JSON Schema; invalid output auto-retries with the validation error fed back (max 3 attempts, then human-visible failure).
- **Decision capture:** every select/reject/edit writes a `CreativeDecision` node; alternatives and rationale are stored so later stages (and future projects) can explain "why".
- **Deterministic costing:** `CostEstimate` is computed by code from the Capability Registry (`credits × duration × resolution` per candidate model), versioned against the registry version so estimates are auditable and reproducible.
- **Impact analysis:** artefacts form a DAG (concept→script→scenes→shots); edits mark downstream nodes `stale` via graph traversal; an LLM pass summarises impact in human language.

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| LLM output fails schema validation ×3 | Stage marked `failed` with raw outputs preserved; user can retry or edit manually — never a silent wrong structure |
| Provider quota exhausted mid-plan | Job pauses (`quota_blocked`), user notified; resumes on quota reset or user-approved paid fallback (never silent) |
| Registry rates stale (>30 days unverified) | Estimate shown with a visible "rates unverified" badge |
| User abandons mid-flow | All artefacts persist; project resumes at exact stage |
| Conflicting edits (collaborators) | Optimistic locking + version conflict UI; no lost updates |

## 11. Acceptance criteria

1. Given the example brief (luxury hotel, Goa, 30s), the engine produces an interpretation, ≥2 clarifying questions where genuinely ambiguous, 3 visually distinct concepts, and a complete production plan with scene breakdown, shot list draft and itemised cost estimate — with **zero paid generation calls** (verifiable in the credit ledger).
2. Every plan section is independently editable and re-approvable; approving a plan emits an event consumable by the Shot Planner.
3. Editing the script post-approval marks exactly the affected scenes/shots stale (unit-tested on the DAG).
4. Cost estimate is reproducible from the registry version recorded on the estimate (deterministic test).
5. All decisions (selects, rejects, edits) are queryable in the Creative Decision Graph with rationale.

## 12. Improvement opportunities over existing products (≥3)

1. **Plan-before-pay:** no competitor offers a project-level, itemised, policy-switchable cost estimate before generation (Higgsfield shows per-step costs only). This is a trust and budgeting feature professionals will pay for.
2. **Creative Decision Graph:** competitors' agent chats (Supercomputer, Runway Agent, Luma Agents) discard decision context; we persist *what was chosen, what was rejected, and why* — reusable across projects and auditable by teams.
3. **Staged approvals with impact analysis:** competitor flows are one-shot generation; we offer software-grade change management for creative work (edit → impact preview → selective invalidation), eliminating the "regenerate everything" tax.
4. **Concept diversity by construction:** N concepts generated with enforced diversity (distinct visual directions/palettes) rather than N near-identical chat suggestions.

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: creative reasoning, visual reference analysis, concept comparison, art direction — with exact technical mechanics, data needs, model usage and limitations.*

### 13.1 How it works technically

**Pipeline shape.** The engine is a staged LLM pipeline with hard schema gates between stages — never one monolithic prompt:

1. **Brief → Interpretation.** The brief text (+ attachment manifests) is rendered into a structured extraction prompt. Output is validated against the `CreativeInterpretation` JSON schema (Drizzle-zod shared with the API contract). Confidence flags per field drive the clarifying-question generator: fields below threshold produce targeted questions (max 5), presented as a blocking but skippable UI step.
2. **Interpretation → Concepts.** N=3 concept generations run as **three independent jobs** (parallel on q.intel), each with a distinct enforced diversity vector: `{palette_family, era_register, camera_grammar}` drawn from a curated diversity table (e.g. palette_family ∈ {muted-earth, high-chroma-pop, noir-monochrome, pastel-soft, metallic-luxe…}). Diversity is **by construction**, not by hoping the LLM varies. Each concept output is schema-validated; failed generations retry up to 3× with temperature jitter, then surface as partial results (never silently dropped).
3. **Concept → Production Plan.** On approval, a decomposition chain runs: narrative outline → scene breakdown → shot-list draft → audio direction → generation recommendations. Each step receives the frozen outputs of the previous steps as context (job snapshots, ADR-0007) so the chain is reproducible.
4. **Cost estimation.** Deterministic — no LLM. The estimator resolves `generation_recommendations` against the pinned registry snapshot: per shot, `sum(model.unit_price × units) × retry_factor(workspace acceptance-rate telemetry)`, rendered under three routing policies. Registry version hash is stamped on the estimate for reproducibility (Acceptance §11.4).

**Visual reference analysis.** User-uploaded reference images are analysed by a **multimodal LLM call** (Gemini Flash free tier for non-confidential workspaces; Groq vision models where available) producing a structured `ReferenceAnalysis`: subject, composition, palette (extracted programmatically via colour-quantisation in the worker, not by the LLM), lighting descriptors, style tags, camera/lens guesses. The LLM's descriptors are stored as **searchable tags + embedding** (pgvector); the palette/technical attributes are stored as **measured data**. This hybrid avoids trusting LLM colour descriptions (known-unreliable) while capturing semantic content the quantiser can't see.

**Concept comparison.** The comparison view is rendered from stored structured fields (palette swatches from hex values, mood keyword clouds, side-by-side rationales) — the LLM is additionally asked for a **pairwise trade-off summary** ("Concept A trades production cost for location flexibility") cached per concept-pair. Comparison is data-driven first, prose second, so it survives model swaps.

**Art direction.** The approved concept's art-direction block (palette hex, typography hints, lighting grammar, texture/material notes) becomes an **immutable versioned artefact** referenced by Character, Storyboard, Cinema and Brand engines. Downstream prompts are assembled from these structured fields (slot-filling), so art direction actually constrains generation rather than being a paragraph nobody reads.

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| Brief + constraints | user input | `creative_briefs` |
| Reference images | user upload | R2 + `assets`, analysis in `reference_analyses` |
| Palette measurements | worker quantisation | `reference_analyses.measured` |
| Diversity vector table | curated seed data | `diversity_vectors` (versioned) |
| Concept/plan structures | LLM output, schema-validated | `creative_concepts`, `production_plans` |
| Registry snapshot | Model Capability Registry | pinned per estimate |
| Acceptance-rate telemetry | generation job outcomes | `provider_model_stats` |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Brief extraction, questions, concepts, plan chain | LLM text | Groq free tier (primary), Gemini Flash free (secondary), OpenRouter `:free` (fallback) | Structurally free layer; quality ceiling acknowledged in §13.4 |
| Visual reference analysis | Multimodal LLM | Gemini Flash (non-confidential) / Groq vision | Descriptors are LLM judgement; measurements are deterministic |
| Palette/technical extraction | None (classical CV) | worker | Deterministic, no model risk |
| Cost estimation | None | deterministic vs registry | Fully reproducible |

### 13.4 Limitations (stated honestly)

1. **Free-tier intelligence quality.** Groq/Gemini-Flash-class models are weaker than frontier paid models at nuanced art direction. The concept diversity mechanism compensates structurally, but a `paid_authorised` routing option for premium reasoning is registry-ready (Provider-Research-Intelligence §3). MVP ships free-tier-only; upgrading intelligence quality is a spend decision, not a rebuild.
2. **LLM aesthetic judgement is not verifiable.** Concept quality is evaluated by the user, not by us — we make no "quality score" claims for concepts. What we verify mechanically is schema validity, diversity-vector distinctness and cost reproducibility.
3. **Visual analysis depth.** Free multimodal models produce usable style tags but unreliable camera/lens identification; those fields are stored as `guess` confidence and never fed to the Cinema Engine as ground truth.
4. **Determinism boundary.** The estimate is deterministic given a registry snapshot, but acceptance-rate telemetry is cold at launch (no history) — early estimates carry a visible low-confidence badge until per-workspace data accumulates.
