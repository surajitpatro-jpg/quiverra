# System Specification — Creative Workflow Intelligence Engine

**System 7 of 7 · Priority P1 · Version 0.2 · 2026-11-09**
Depends on: Creative Director Engine (plan), Shot Planner (shots), Continuity Engine (contracts), Provider Router (execution + quotas), Credit Ledger.
Evidence base: Gap 7/8 — no competitor offers dependency-aware production workflows with cost governance (Higgsfield Supercomputer is agent-implicit; routing is a black box, F-0004/F-0016).

---

## 1. Purpose

Automatically construct and execute the production workflow for a project — Brief → Concept → Script → Characters → Locations → Storyboard → Shot Planning → Image → Video → Audio → Review → Export — as a **visible, controllable, dependency-aware execution graph**, with cost estimation, parallel execution where safe, approval checkpoints, failure recovery and partial regeneration.

Deliberately **not** a conventional node editor: the workflow is derived from the production plan and its dependencies, not drawn by the user. (Higgsfield Canvas already owns "draw your own node graph"; we compete on not needing one.)

## 2. User problems (evidence-backed)

1. **Users hand-orchestrate production today.** Across all competitors, the sequence (characters first, then frames, then video, then audio) is manual knowledge; the platform doesn't know that shot 12's video needs shot 12's start frame, which needs the approved character, which needs the character's reference sheet.
2. **Agentic execution is opaque.** Supercomputer's Orchestrator picks models and steps without exposing the plan or its cost before execution (F-0004). Users can't audit what will happen or what it will cost.
3. **Failures are expensive and unrecoverable.** A failed step in a long manual chain means redoing work; no competitor offers checkpointed, resumable production runs (Gap 7).
4. **No parallelism.** Users generate shot by shot sequentially even when 20 shots are independent (all competitors' UIs are per-generation).

## 3. Functional requirements

### FR-1 Automatic workflow construction
From an approved production plan + storyboard, the engine compiles a **Workflow**: a DAG of tasks (character design, reference sheets, location plates, per-shot frames, per-shot videos, VO, music, sound, continuity evaluations, reviews, exports) with edges from data dependencies (shot→scene→characters→refs) and approval policies.

### FR-2 Execution semantics
- **Parallel execution** of independent tasks up to configurable concurrency (respecting provider rate limits and plan tier).
- **Sequential execution** along dependency chains.
- **Branching** (e.g., two visual-direction variants for the same scene) and **conditional operations** (generate video only if frame approved).
- **Approval checkpoints**: the workflow pauses at configured gates (plan approval, character lock, frame approval, client review) and resumes on approval.
- **Retries** with exponential backoff per task; **fallback** to alternate models per routing policy; **no infinite retries** (max attempts, then `failed` with options).
- **Partial regeneration:** re-run any subgraph (one shot, one scene, one character's downstream) without touching the rest.

### FR-3 Cost estimation and control
Before execution: full workflow cost estimate (per task, per stage, total; low/expected/high bands) from deterministic costing over the Capability Registry (ADR-0005). During execution: running spend vs estimate; **budget caps** that pause the workflow rather than overrun; no silent paid fallback when free quotas exhaust (per brief §7.6).

### FR-4 Execution monitoring
Live run view: task states (queued/running/waiting-approval/done/failed/skipped), progress events, spend so far, provider used per task, durations, error details. Full execution log persisted per run.

### FR-5 Asset reuse and caching
Tasks declare their inputs by content hash + contract version; identical inputs reuse existing assets (a character reference sheet is generated once per character version, not once per shot).

### FR-6 Version management
Every workflow run is recorded (workflow version, inputs snapshot, task results, spend); runs are comparable; assets link back to the run that produced them.

## 4. User workflows

**W1 — Plan to production:** user approves plan → "Build production workflow" → engine presents the graph (stages and task counts, e.g., "3 characters, 4 locations, 30 shots → 96 tasks") with the cost estimate → user sets budget cap and approval gates → runs it → watches execution; gates pause for approvals.

**W2 — Failure recovery:** video task for shot 12 fails after 3 retries (provider outage) → workflow continues independent shots → shot 12 marked failed with provider error → user switches its routing policy → retries just that task.

**W3 — Partial regeneration:** client rejects scene 4's location plate → user regenerates the plate → engine marks downstream tasks (scene 4 shots' frames/videos) as affected → user confirms re-run of exactly that subgraph.

**W4 — Cost review:** before running, user compares policies: quality-first ($41, ~38 min) vs balanced ($19, ~52 min) vs cost-first ($11, ~74 min) — with per-stage quality notes → picks balanced.

## 5. Data structures

```yaml
Workflow:     { id, project_id, plan_version, graph:{tasks[], edges[]}, policy(routing, budget_cap, concurrency, gates[]), version, created_from }
WorkflowTask: { id, workflow_id, kind(character_ref_sheet/location_plate/shot_frame/shot_video/vo/music/sfx/continuity_eval/review/export/...), subject_ref, inputs_hash, depends_on[], model_policy, cost_estimate, status, attempts, provider_used, result_refs[], error }
WorkflowRun:  { id, workflow_id, started_at, finished_at, state, budget_cap, spend, task_states_snapshot, events_log_ref }
Gate:         { id, workflow_id, stage, approver_role, state(pending/approved/rejected), comment, decided_by, decided_at }
```

## 6. Dependencies

- **All production systems** emit and consume workflow artefacts (plan, characters, shots, contracts, assets).
- **Provider Router** executes intelligence and generation tasks; supplies quota/health signals; enforces the no-silent-paid-fallback rule.
- **Credit Ledger** records every task's spend against the run; refunds on eligible failures.
- **Notification system** for gate approvals and failures.

## 7. API requirements

```
POST   /api/projects/:id/workflows:build            # compile from plan/storyboard → graph + estimate
GET    /api/workflows/:id                           # graph + estimate
POST   /api/workflows/:id:run                       # start run (budget_cap, policy overrides)
GET    /api/runs/:id                                # live state
POST   /api/runs/:id:pause | :resume | :cancel
POST   /api/runs/:id/tasks/:tid:retry               # retry single task (optionally new policy)
POST   /api/runs/:id/regenerate-subgraph            # partial regeneration (subject_ref)
POST   /api/gates/:id:approve | :reject             # gate decisions
GET    /api/runs/:id/log                            # execution events
GET    /api/runs/:id/cost                           # spend breakdown vs estimate
```

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Workflow compilation | Deterministic code | Graph derived from plan + storyboard data; no model |
| Cost estimation | Deterministic code | ADR-0005 |
| Task execution | Whatever each task needs | Routed via Provider Router |
| Run summaries / error explanations | Mid-tier LLM | "Shot 12 failed because provider X returned 429 three times; suggested action…" |

## 9. Technical implementation approach

- **Compiled, not drawn:** the workflow is a build artefact of the plan (like a build system, not a whiteboard). Users edit the plan, not the graph; the graph recompiles.
- **Durable execution:** workflow state lives in the database; workers (BullMQ/Redis per brief §8) execute tasks idempotently; a crashed worker loses at most one task attempt, never the run.
- **Idempotent task contract:** every task = `(kind, inputs_hash) → result_refs`; safe to retry, safe to dedupe, naturally cacheable.
- **Backpressure and quotas:** scheduler consults the Router's quota/health signals before dispatching; per-provider concurrency limits are configuration, not code.
- **Event-sourced run log:** every state transition is an event; the live view and the audit trail are projections of the same log.

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| Provider error/rate limit | Backoff retry (max N), fallback model per policy, then `failed` with full error context — run continues elsewhere |
| Free quotas exhausted, no paid authorisation | Run pauses (`quota_blocked`), user notified with resume options — never silently spends (brief §7.6) |
| Budget cap reached mid-run | Run pauses (`budget_blocked`) with spend report; user raises cap or cancels |
| Gate rejected | Downstream tasks cancelled cleanly; affected subgraph returns to editable state |
| Worker crash | Tasks re-dispatched idempotently; run state intact |
| User edits plan mid-run | Run continues on frozen snapshot; engine reports the diff and offers a follow-up run for the delta |

## 11. Acceptance criteria

1. A 30-shot plan compiles into a correct DAG (dependency edges verified against the storyboard data) with an itemised estimate reproducible from the registry (unit tests).
2. Independent tasks execute in parallel up to the configured limit; dependent tasks never start before their inputs exist (integration test with mocked providers).
3. A provider failure triggers retry → fallback → failed-with-context, while unrelated tasks continue (chaos test).
4. Budget cap and quota exhaustion both pause the run with correct state and zero unauthorised spend (ledger-verified test).
5. Regenerating a subgraph re-executes exactly the affected tasks and reuses cached assets for identical inputs (end-to-end test).

## 12. Improvement opportunities over existing products (≥3)

1. **The only compiled, dependency-aware production workflow.** Competitors: manual sequencing (all), drawn node graphs (Higgsfield Canvas), or opaque agent runs (Supercomputer). We derive the workflow from the plan — correctness by construction, zero drawing.
2. **Cost governance competitors don't have:** pre-run estimates with policy comparison, live spend tracking, budget caps, and a hard rule against silent paid fallback (users' #1 credit complaint, Gap 7).
3. **Checkpointed, resumable, partially regenerable runs.** No competitor offers "re-run scene 4's subgraph" — the unit of recovery everywhere else is the whole project or the single generation.
4. **Auditable execution:** every run is an event log with per-task provider, cost, duration and error — the transparency that Supercomputer's black-box Orchestrator deliberately doesn't provide.

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: **reliable execution, dependency management, approvals, retries, cost control** — the production mechanics.*

### 13.1 How it works technically

**Dependency management.** Every project compiles to a frozen DAG at plan-approval time (ADR-0008): nodes are units of work (LLM stage, image batch, video render, eval, composite), edges are data dependencies. Editing a node marks exactly its transitive dependents `stale` — nothing else regenerates. The DAG is stored, versioned, and recompiled on structural edits with the diff shown to the user before re-approval.

**Reliable execution.** Jobs execute on q.intel / q.gen (ADR-0011) with: content-hash idempotency keys (ADR-0008 — a retried job with identical inputs returns the stored result, never double-charges), frozen input snapshots (ADR-0007), provider-specific adapters implementing `capabilities/estimate/submit/poll/usage`, and a **completion reconciler** per provider contract: fal ⇒ webhook-first (`subscribe()`, F-0036) with poll fallback; Replicate ⇒ poll + immediate R2 ingestion (1-hour deletion, F-0037); Gemini ⇒ poll with runtime-fetched quota awareness (F-0039).

**Retries with money effects.** Retry policy is failure-class driven (Workflow-Execution.md taxonomy): `server_error` ⇒ free to retry (unbilled at fal/Replicate-public/Veo-success-only), exponential backoff, max 3; `validation_error` ⇒ never auto-retried (billed 422s at fal, quota-burning 400s at Gemini — F-0036/F-0039 — mean a bad input costs money every attempt); `quota_exhausted` ⇒ job parks as `quota_blocked` and resumes on reset; `content_flag` ⇒ surfaced, not retried. Every retry decision is recorded with its cost exposure.

**Approvals as first-class gates.** Plan approval, batch generation approval, per-shot spend above workspace threshold, and any paid-fallback routing decision are blocking gate nodes in the DAG with full cost preview. Gates are data (`approvals` table: who, what snapshot, when, cost shown) — an approval is meaningless unless the exact artefact + estimate it approved is retrievable. **The router never silently upgrades spend**: free-quota exhaustion pauses work and notifies; paid routing requires the workspace's explicit `paid_authorised` policy (user-mandated rule).

**Cost control.** Three mechanisms stack: (a) pre-flight — every gate shows the deterministic estimate from the pinned registry; (b) in-flight — per-job budget caps; a job whose actual usage report exceeds estimate × `budget_tolerance` (default 1.2) halts its batch and flags; (c) post-flight — the double-entry ledger (ADR-0012) reconciles estimated vs actual per job, feeding the acceptance-rate-adjusted estimator so quotes improve with use. Monthly workspace spend caps are hard-enforced at reservation time (the atomic quota layer, ADR-0014).

**Failure recovery.** Worker crash ⇒ job lease expires, another worker picks it up via idempotency key (already-running provider jobs are re-attached by provider job ID stored at submit time — no double submission). Whole-queue outage ⇒ jobs persist in Redis+AOF with Postgres as the system of record; on restore, the sweeper reconciles `submitted` jobs against provider state before resuming.

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| DAG + versions | plan compiler | `dag_versions`, `dag_nodes`, `dag_edges` |
| Job records + snapshots | scheduler | `jobs`, `job_snapshots` |
| Provider job IDs | adapters at submit | `jobs.provider_ref` |
| Approvals | gate UI | `approvals` |
| Usage reports & ledger | adapters + ledger | `usage_reports`, `ledger_*` (ADR-0012) |
| Quota reservations | router | Redis (ADR-0014) + `quota_events` |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Workflow drafting from plan | LLM text | Groq free | Compiles to DAG; schema-validated |
| Failure classification | none (rule table) | worker | Deterministic per provider contract |
| Cost estimation | none | deterministic vs registry | Reproducible |
| Anomaly detection on spend | threshold rules (MVP); ML post-MVP | worker | Rules first, learning later |

### 13.4 Limitations (stated honestly)

1. **At-least-once semantics with idempotent effects.** We guarantee no double-charge and no lost jobs, not exactly-once execution at the provider (impossible — a provider may complete work whose webhook we miss; the reconciler exists for this). Stated precisely in Workflow-Execution.md.
2. **Webhook trust.** Provider webhooks are verified (signature per provider) and treated as *hints*; state is confirmed by a status poll before ledger settlement. A missed webhook never strands a job (sweeper), a forged one never moves money.
3. **Estimate accuracy is cold at launch.** Acceptance-rate telemetry starts empty; early quotes show a low-confidence badge (Creative Director §13.4.4). The estimator is honest about its own uncertainty rather than pretending precision.
4. **Human gates are the bottleneck by design.** Approval gates block automation; scheduled/unattended runs (a post-MVP feature) will need per-workspace auto-approval policies with hard spend ceilings — recorded as future work, not assumed.
