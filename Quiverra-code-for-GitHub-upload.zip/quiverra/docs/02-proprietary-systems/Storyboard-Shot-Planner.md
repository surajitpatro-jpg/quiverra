# System Specification — Storyboard & Shot Planner

**System 5 of 7 · Priority P0 · Version 0.2 · 2026-11-09**
Depends on: Creative Director Engine (approved plan), Scene & Continuity Engine (contracts), Cinema Engine (camera/lighting vocabulary), Provider Router, Generation Orchestrator.
Evidence base: Gap 5 — storyboards aren't data anywhere (F-0014 LTX best-in-class but thin; Boords owns approval without generation; F-0004 Higgsfield has no storyboard entity).

---

## 1. Purpose

Turn an approved production plan into a **production-ready, fully structured storyboard** in which every shot is a data record that drives generation — and give the user complete editorial control (edit, reorder, insert, delete, regenerate one, compare versions, approve/reject) without ever rebuilding the whole production.

## 2. User problems (evidence-backed)

1. **Boards are pictures, not data.** LTX's Dynamic Storyboard — the best available — is a visual board with limited structured fields; exporting a machine-usable shot list isn't possible (F-0014). Higgsfield's AI Director drafts shots but the artefact is generations, not an editable plan (F-0004).
2. **Approval workflow is disconnected from generation.** Boords does frame-level client approvals well but generates nothing; generation platforms have no approval states (F-0015).
3. **One bad shot costs the whole sequence.** Competitors offer full regeneration or post-hoc patch tools; there's no "replace shot 7 and keep the other 29" with dependency awareness (Gap 2/5).
4. **Shot metadata lives in people's heads.** Duration, lens intent, lighting, props, audio needs — professionals track these in spreadsheets (Storyflow/Studiovity exist precisely because of this), disconnected from where generation happens.

## 3. Functional requirements

### FR-1 Structured shot records
Every shot carries: project/scene/shot IDs, shot number, duration, narrative purpose, character refs, location ref, props, action, camera position + movement (Cinema Engine vocabulary), shot type (EWS→ECU, OTS, POV, establishing…), lighting, composition notes, start-frame ref, end-frame ref, audio requirements, generation model + settings (from recommendations, user-overridable), dependencies, approval status (`planned → generating → review → approved / rejected`), version chain.

### FR-2 Storyboard views
- **Board view:** visual grid of frames (generated thumbnails/placeholders), drag to reorder.
- **Table view:** spreadsheet-grade shot list (every field editable inline, filter/sort/group by scene).
- **Timeline view:** durations on a ruler, audio markers, gaps and total runtime at a glance.
All views are projections of the same shot records — no view-specific state to desynchronise.

### FR-3 Editing operations
Edit any field; reorder (drag or renumber); insert shot(s) anywhere (neighbours' continuity contracts re-derived automatically via the Continuity Engine); delete with dependency warning; split/merge shots; duplicate as variant.

### FR-4 Frame generation workflow
Per shot: generate start frame (image) → review → optionally generate end frame → generate video between frames (where the chosen model supports frame conditioning) → attach result as a candidate version. Frames and videos are asset versions on the shot, never floating files.

### FR-5 Version comparison
Side-by-side (and A/B overlay for frames) comparison of any two versions of a shot, with generation settings diff visible. One click promotes a version to `active`.

### FR-6 Approval workflow
Approve/reject per shot with optional comment; bulk approve; approval required states are configurable per project (e.g., agency: client approval gate before video generation). Approval history is immutable.

### FR-7 Selective regeneration
Regenerate a single shot (frame or video) with optionally adjusted instructions/references; the Continuity Engine re-checks dependents automatically. Rejected versions are retained, not deleted.

### FR-8 Export
Shot list export (CSV/PDF call-sheet style), animatic export (frames + durations + scratch audio → simple timeline video), and EDL-style export for downstream editors.

## 4. User workflows

**W1 — Plan → board:** approved plan arrives → engine generates the shot list draft (from the plan's shot list) with placeholders → user opens board view → reviews/edits shot by shot → locks the shot list → pre-flight continuity check → generation begins per shot.

**W2 — Fix one shot:** shot 17's video has the wrong mood → user opens shot 17 → "regenerate with guidance" ("colder grade, slower push-in") → new candidate version appears → user A/B compares → promotes candidate → dependents (18's start contract) re-validated → done. Nothing else regenerated.

**W3 — Agency review:** producer shares the board with the client (read/comment role) → client approves 26 shots, rejects 3 with comments → rejected shots return to `planned` with comments attached → team regenerates exactly those 3.

**W4 — Restructure:** user drags shot 9 to position 4 → engine re-derives contracts for affected neighbours → continuity report updates → warnings surfaced before any generation happens.

## 5. Data structures

```yaml
Shot:        { id, project_id, scene_ref, shot_number, duration_s, narrative_purpose, characters[], location_ref, props[], action, camera:{position, movement, angle, lens_intent}, shot_type, lighting, composition, start_frame_ref, end_frame_ref, audio_requirements[], generation:{model, settings, policy}, dependencies[], status, active_version_ref, locked }
ShotVersion: { id, shot_ref, kind(frame_start/frame_end/video), asset_ref, generation_settings, references_used[], evaluation_ref, approval:{state, by, comment, at}, parent_version_ref, created_at }
Storyboard:  { id, project_id, scene_order[], shot_order[], total_runtime_s, version }
ApprovalPolicy: { project_id, gates:[{stage, approver_role, required}] }
```

## 6. Dependencies

- **Creative Director Engine** — supplies the approved shot list draft; plan edits trigger impact analysis here.
- **Scene & Continuity Engine** — contracts on every shot; re-derivation on structural edits; pre-flight gate before generation.
- **Cinema Engine** — controlled vocabulary for camera/shot-type/lighting fields; compiles shot records into per-model instructions.
- **Generation Orchestrator** — executes per-shot generation jobs with references assembled by the Continuity Engine.
- **Asset Library** — frames/videos stored as versioned assets linked to shots.

## 7. API requirements

```
GET    /api/projects/:id/storyboard                 # full board (shots + order + runtime)
POST   /api/projects/:id/shots                      # create shot (position param)
PATCH  /api/shots/:id                               # edit fields
POST   /api/shots/:id:move                          # reorder → triggers contract re-derivation
DELETE /api/shots/:id                               # delete (dependency report in response)
POST   /api/shots/:id:split | :merge | :duplicate
POST   /api/shots/:id/versions:generate             # frame/video generation job
POST   /api/shots/:id/versions/:vid:promote         # set active version
POST   /api/shots/:id/versions/:vid:approve | :reject   # with comment
GET    /api/shots/:id/versions:compare?a=..&b=..    # settings + asset diff
GET    /api/projects/:id/storyboard/export?fmt=csv|pdf|animatic|edl
```

## 8. Model requirements

| Task | Model class | Notes |
|---|---|---|
| Shot list drafting from plan | Mid-tier LLM (structured output) | Intelligence task |
| Shot instruction compilation | Deterministic code + templates | Cinema Engine compiler; no model |
| Frame generation | Image models via router | User-visible model choice + policy |
| Video generation | Video models via router | Frame-conditioned where supported |
| Animatic assembly | Deterministic (ffmpeg) | No model |

## 9. Technical implementation approach

- **Shots as the single source of truth:** every view, export and generation job derives from shot records; no derived state is authoritative.
- **Event-driven integrity:** structural operations (move/insert/delete/split/merge) emit events consumed by the Continuity Engine for contract re-derivation; the two systems are loosely coupled through events, not shared tables.
- **Generation isolation:** each shot's generation job carries a frozen snapshot of its inputs (settings + references + contract version) — reproducible and immune to mid-flight edits.
- **Optimistic UI with real job handles:** generation jobs are queued; the board shows live status via progress events; jobs survive page reloads (server-side job state).
- **Approval as data:** gates are policy records, so a solo creator (no gates) and an agency (client gate pre-video) run the same code.

## 10. Failure handling

| Failure | Behaviour |
|---|---|
| Generation job fails (provider error) | Shot version marked failed with provider error surfaced; credits refunded per ledger policy; retry with same/fallback model per routing policy |
| Mid-generation structural edit | Running jobs complete against their frozen snapshot; affected shots flagged `stale` for review — never silently invalidated |
| Dependency cycle (user creates one via edits) | Move/split validation rejects with explanation |
| Export with missing assets | Export completes with explicit placeholders + manifest of gaps (never a broken silent export) |
| Concurrent edits by collaborators | Field-level versioning; conflict UI on save |

## 11. Acceptance criteria

1. A 30-shot storyboard round-trips through every structural operation (insert/move/delete/split/merge) with continuity contracts re-derived and no orphaned records (integration tests).
2. Regenerating one shot touches exactly one shot's versions and triggers re-validation of only its dependents (end-to-end test with mocked providers).
3. Version comparison shows two versions with a correct settings diff; promotion switches the active version atomically.
4. Approval gates block video generation until satisfied (policy test), and approvals are immutable.
5. CSV/PDF/animatic exports match the current board state (snapshot tests).

## 12. Improvement opportunities over existing products (≥3)

1. **The only shot-level data model that drives generation.** LTX boards are visuals; Higgsfield has drafts; we make the shot a first-class record (camera, lighting, contract, dependencies, versions) that generation actually consumes — enabling everything below.
2. **True selective regeneration with dependency awareness.** Competitors force full-regenerate or post-hoc patching; our contract graph means replacing shot 7 costs shot 7 — measurable cost and time savings.
3. **Approval workflow inside the generation tool.** Boords-grade approval (comments, gates, immutable history) fused with frontier generation — today agencies must stitch two tools and manual handoffs.
4. **Real production exports** (shot list CSV, call-sheet PDF, animatic, EDL) from the same data — bridging AI generation and professional post pipelines that competitors ignore.

---

## 13. Implementation Deep-Dive (v2 — 2026-11-10)

*Added in the correction phase. Focus: **professional visual workspace, editable shots, sequencing, alternate frames, selective regeneration**.*

### 13.1 How it works technically

**Free structural editing before any spend (the LTX lesson, improved).** LTX lets users restructure scenes/shots free before generation (F-0033) — we adopt that and remove its fragility (their @-mention binding). The storyboard is a structured document:

- `sequences → scenes → shots`, each shot: `shot_type, duration_s, camera intent, motion intent, state_in/out, character_bindings[], location_ref, prompt_slots, status`.
- All structural operations — **merge, split, add beat, reorder (drag), duplicate, delete** — are pure data operations on q.intel-free paths: zero credits, instant, undoable (operation log per storyboard).
- Reordering is sequence-position arithmetic with fractional indexing (`position` REAL between neighbours) so drag-reorder is O(1) writes, not a renumber pass.

**The workspace UI.** Canvas-grade board (React + Zustand per stack decision): scenes as swim-lanes, shots as cards with frame thumbnails, drag between/within lanes, multi-select bulk ops, keyboard-first editing, per-shot status badges (`draft / framed / generating / needs_review / accepted`), and a filmstrip timeline view with running-time total. Every card exposes the shot's cost estimate inline (from the pinned registry snapshot) — cost is visible where the decision is made.

**Frame generation & alternate frames.** Per shot, the user requests: primary frame, or primary + N alternates (N≤3). Each is a separate image-generation job with the same compiled prompt and different seeds (where native seed control exists) — all cost-previewed as one batch before execution. Alternates are stored as `frame_candidates` under the shot; choosing one promotes it to `selected_frame`, demoting but never deleting the others. This gives the "alternate frames" requirement without regeneration roulette.

**Selective regeneration.** Regeneration is **surgical**: per shot, the user picks what changes — `seed_only | prompt_clause | reference_set | model_route`. Only the affected parameters change; the compiled prompt diff is shown before the (cost-previewed) job is submitted. Retake-style partial fixes (F-0033's "Retake reduces regenerations") map to `prompt_clause` with the rest frozen. Editing a shot's structure marks exactly the downstream dependents stale via the project DAG (ADR-0008) — a wardrobe edit invalidates that character's frames in affected shots, nothing else.

**Sequencing & hand-off to video.** Selected frames become: (a) T2V prompt anchors, (b) I2V start frames, or (c) keyframe pins (first/last/multi where native — e.g. Ray3.2 16-keyframe rows, F-0032), resolved per the Cinema Engine's capability translation. The hand-off is a data transform, not a re-upload: asset IDs flow into video job specs.

### 13.2 Data requirements

| Data | Source | Storage |
|---|---|---|
| Storyboard structure | planner + user edits | `sequences/scenes/shots`, fractional `position` |
| Frame candidates | image generation | R2 + `frame_candidates` per shot |
| Operation log | UI actions | `storyboard_operations` (undo + audit) |
| Compiled prompts & diffs | prompt assembler | `shots.compiled_prompt`, job snapshots |
| DAG dependency edges | planner | project DAG tables (ADR-0008) |

### 13.3 AI models used

| Task | Model class | Route | Honesty note |
|---|---|---|---|
| Script → scene/shot structuring | LLM text | Groq free | Schema-validated; user edits always win |
| Shot prompt compilation | none (slot-fill) | worker | Deterministic from structured fields |
| Frame generation | image models | router (fal flux-2 / Nano Banana 2 class) | Paid; batch cost preview |
| Alternate seeds | same model | router | Same prompt, varied seed where native |

### 13.4 Limitations (stated honestly)

1. **Board performance budget.** 40+ shots × 4 candidates = 160 thumbnails; the UI virtualises rendering and lazy-loads R2 signed URLs. Beyond ~500 shots per project we paginate by sequence — a stated constraint, not an accident.
2. **Structural AI parse is draft-quality.** The initial script→shots parse is a starting draft (like LTX's); its value is a correct *structure* to edit, not final shot craft. We measure and display parse-edit distance internally to improve prompts, but never block editing on parse quality.
3. **Selective regeneration can't guarantee localised change.** Image models may shift unconstrained regions on any regenerate; alternates + the comparison view exist precisely because of this. We promise the *input* diff, not the output diff.
4. **Real-time collaboration is post-MVP.** The operation log is designed for OT/CRDT upgrade, but MVP is single-editor with optimistic locking (Higgsfield Canvas's Figma-style live collab, F-0026, is explicitly out of scope).
