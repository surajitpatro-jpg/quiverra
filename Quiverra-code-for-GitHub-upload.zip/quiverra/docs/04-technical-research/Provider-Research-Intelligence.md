# Provider Research — Intelligence (LLM / Reasoning)

**Version:** 2.0 · **Status:** Evidence-based · **Last verified:** 2026-11-10
**Feeds:** Orchestration-Engine.md (registry seed), API-Cost-Analysis.md, Security.md (data-policy flags)
**Evidence base:** F-0017..F-0020, F-0039, F-0044. Freshness rule applies to all quota/pricing numbers — re-verify at integration time.

---

## 1. Role in the platform

Intelligence providers power everything except pixel/audio generation: brief analysis, creative concepts, visual direction, scriptwriting, storyboard structuring, shot planning, continuity evaluation, brand-rule checking, workflow reasoning. This is the **structurally free layer** of the platform — generation is always paid, intelligence can be run at $0 marginal cost during development and early operation, and the router's spend policies (`free_only` / `free_preferred` / `paid_authorised`) exist to keep it that way.

Hard rule (user-mandated): **when free quota is exhausted the system must not silently switch to a paid model.** It either uses a paid model the workspace has explicitly authorised, or pauses and informs the user.

## 2. Provider assessments

### 2.1 Google Gemini API (LLM side)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Public REST + SDKs; per-API-key access via AI Studio | F-0017 |
| Model capabilities | Free tier restricted to **Flash-class** models; Pro requires billing. Multimodal (text+image in) makes Flash viable for visual-reference analysis | F-0017 |
| Pricing | Flash-class pay-as-you-go; Batch API = 50 % price, separate limits | F-0039 |
| Free quotas | Flash-only free tier; exact RPM/RPD numbers conflict between sources → **treat as dev/test grade, fetch live values at config time** | F-0017, F-0039 |
| Commercial terms | Limits are **per project, not per key**; dimensions RPM/TPM/RPD; RPD resets midnight Pacific; paid tiers T1/T2/T3 with monthly billing caps $250/$2,000/$20k+ and rolling 10-min spend limits $10/$50/$200; **$300 Cloud welcome credit NOT usable since March 2026**; new accounts Prepay $5 min | F-0039 |
| Privacy | **Paid (billing-enabled project): no training on prompts/responses; free tier: content used to improve products, human reviewers; EEA/CH/UK get paid terms everywhere; grounding logs kept 30 days** | F-0044 |
| Rate limits | No published static table — live values in AI Studio only ⇒ quota manager must treat limits as **runtime-fetched data** | F-0039 |
| Failure behaviour | **Failed 400/500 requests still consume quota** (validate before send); HTTP 402 = prepay balance empty | F-0039 |
| Registry posture | `data_policy: trains_on_free_tier` flag; confidential workspaces route away from free-tier Gemini | F-0044 |

### 2.2 Groq

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Public REST, OpenAI-compatible | F-0018 |
| Model capabilities | Llama/Mixtral-class open models; fast inference suited to interactive steps (concept chat, storyboard edit loops) | F-0018 |
| Pricing | Paid tier raises limits; per-model pricing | F-0018 |
| Free quotas | **All listed models usable on free tier** with per-model RPM/RPD/TPM limits; org-level usage caps | F-0018 |
| Commercial terms | Limits per model and change over time — fetch the live table at config time | F-0018 |
| Privacy | To be verified against groq.com terms at integration (flagged **U** — do not assume) | — |
| Rate limits | Per-model RPM/RPD/TPM, published in docs rate-limits page | F-0018 |
| Failure behaviour | Standard 429 with retry-after; no billing on free tier | F-0018 |
| Registry posture | Primary `free_only` workhorse for text intelligence | F-0018 |

### 2.3 Cloudflare Workers AI

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | REST + Workers binding | F-0019 |
| Model capabilities | Llama/Mistral-class LLMs, Whisper (audio), image models — one vendor covers three of our four provider categories | F-0019 |
| Pricing | $5/mo base + per-Neuron overage | F-0019 |
| Free quotas | **10,000 Neurons/day**, resets daily — a burst buffer, not steady-state capacity | F-0019 |
| Commercial terms | Neuron accounting differs per model | F-0019 |
| Privacy | Cloudflare enterprise posture; verify model-specific terms at integration (**PV**) | — |
| Rate limits | Daily Neuron ceiling is the operative limit | F-0019 |
| Failure behaviour | Standard HTTP errors; over-allocation = paid overage or 429 depending on config | F-0019 |
| Registry posture | Secondary free buffer + Whisper for STT | F-0019 |

### 2.4 OpenRouter (aggregator)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Single OpenAI-compatible API over many upstream models | F-0020 |
| Model capabilities | Rotating `:free` roster across many model families | F-0020 |
| Pricing | Pass-through + small fee; paid models available under one key | F-0020 |
| Free quotas | `:free` models: **20 RPM, 50 requests/day**, raised to 1,000/day after $10 lifetime credit purchase | F-0020 |
| Commercial terms | Roster rotates — registry must **re-resolve `:free` models** rather than pin them | F-0020 |
| Privacy | **Free models may log/train on prompts per upstream provider policies ⇒ per-model `data_policy` flag required; confidential workspaces excluded from `:free` roster** | F-0020 |
| Rate limits | 20 RPM cap on free; paid per upstream | F-0020 |
| Failure behaviour | Upstream-dependent; aggregator normalises errors | F-0020 |
| Registry posture | Free-tier diversity source; never for confidential data | F-0020 |

## 3. Paid intelligence options (registry-ready, not development dependencies)

The development plan deliberately uses free tiers for intelligence. The registry schema must still admit paid LLM rows (Anthropic Claude, OpenAI, Gemini Pro) from day one, because (a) some quality-sensitive steps (final script polish, brand compliance scoring) may justify paid models under `paid_authorised`, and (b) Higgsfield's Supercomputer already routes across Claude/Gemini for reasoning (F-0028) — premium intelligence is a proven product pattern. No paid LLM key is required for MVP development; this is recorded as an explicit decision requiring user approval (see final report §7).

## 4. Development-quota budget (intelligence layer)

| Step in MVP pipeline | Est. calls per project | Free source of record |
|---|---|---|
| Brief analysis + concepts | 5–15 | Groq free |
| Visual direction + reference analysis | 5–10 | Gemini Flash free (non-confidential) / Groq |
| Script | 3–8 | Groq free |
| Storyboard structuring | 5–15 | Groq free |
| Shot planning | 10–30 | Groq free |
| Continuity / brand checks | 10–40 | Groq free |
| **Total per full project** | **≈ 40–120 calls** | Within Groq per-model RPD + OpenRouter 50/day + CF 10k Neurons/day combined |

Budget is a planning estimate (**H**) — instrument real consumption from the first build and feed it back into the Cost Estimator.

## 5. Data-policy routing rules (binding)

1. Registry rows carry `data_policy ∈ {no_training, trains_by_default, opt_out_available, unknown}`.
2. Workspace carries `confidential: boolean` (Security.md). Confidential workspaces may only route to `no_training` rows (paid Gemini project, Groq pending verification, enterprise arrangements).
3. Free-tier Gemini and OpenRouter `:free` are **`trains_by_default`** — excluded from confidential routing, eligible for general development traffic.
4. ElevenLabs (audio) is `trains_by_default` on self-serve with prospective opt-out — the platform must apply the opt-out at account setup (F-0045).

## 6. Open items

- Groq privacy/training terms — **U**, verify before confidential routing.
- Gemini free-tier exact RPM/RPD — sources conflict; read live values in AI Studio at integration.
- OpenRouter `:free` roster snapshot at integration time; build the re-resolution job regardless.
