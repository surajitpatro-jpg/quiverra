# Provider Research — Audio (TTS / STT / Music)

**Version:** 2.0 · **Status:** Evidence-based · **Last verified:** 2026-11-10
**Feeds:** Model-Capability-Matrix.md, Orchestration-Engine.md, API-Cost-Analysis.md
**Evidence base:** F-0019, F-0023, F-0040, F-0045. Freshness rule applies; one rate conflict remains open (§2.1).

---

## 1. Role in the platform

Audio enters the MVP pipeline at three points: (a) **voiceover TTS** from the script stage, (b) **STT** for user-supplied reference material, and (c) **music** for storyboard animatics and final assembly. Audio is cheap relative to video but has the most complex **per-plan concurrency** structure and the sharpest **data-use terms** found in the research (F-0045).

## 2. Provider assessments

### 2.1 ElevenLabs

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | REST + WebSocket; request history dashboard | F-0023, F-0040 |
| Model capabilities | TTS (Multilingual v2/v3, Flash v2.5, eleven_v3), STT, music, Text-to-Dialogue, Voice Changer | F-0023, F-0040 |
| Pricing | TTS $0.04–0.05/1k chars Flash/Turbo-class, $0.08–0.10/1k Multilingual v2/v3 (**conflict persists — confirm at integration**); STT $0.22/h; music $0.15/min | F-0023, F-0040 |
| Free quotas | **Free plan 10k credits/mo, API access, NON-commercial + attribution required** | F-0023 |
| Commercial terms | Starter $6/30k cr (commercial license, instant voice clone); Creator $22/121k (professional clone); Pro $99/600k; Scale $299/1.8M; Business $990/6M; paid credits roll ≤2 months capped at 2× monthly quota; free credits do not roll | F-0023 |
| Privacy / data use | **Trains on self-serve data (Free→Business incl. API) BY DEFAULT**; in-app opt-out prospective only; Enterprise not trained on by default; **Zero Retention Mode** (enterprise) per-request `enable_logging=false` on TTS/Dialogue/S2S/STT/music endpoints; DPA: enterprise content deleted ≤30 days post-termination; self-serve deletable after 180 days inactivity; third-party audit flags **perpetual, irrevocable, sub-licensable licence over user content**; SOC 2 Type II / ISO 27001 / PCI DSS L1 | F-0045 |
| Rate limits / concurrency | Per plan × model family — Multilingual v2: Free 2 / Starter 3 / Creator 5 / Pro 10 / Scale+ 15; **Flash: double**; STT 8–60; over-limit queues ~+50 ms then 429; headers `current-concurrent-requests` / `maximum-concurrent-requests`; per-request caps: eleven_v3 5,000 chars, Multilingual v2 10,000, Flash v2.5 40,000 | F-0040 |
| Failure behaviour | **WebSocket metering counts only active generation time**; Text-to-Dialogue metered as sessions (Free 14 → Scale 105); Turbo deprecated → Flash | F-0040 |

**Mandatory platform actions (recorded in Security.md §secrets matrix and the runbook):**
1. At account setup, disable "Improve the models for everyone" (Terms & privacy → Data use) — opt-out is prospective, so it must happen **before** the first API call carrying user scripts.
2. Registry `data_policy: trains_by_default (opt_out_available)` on all ElevenLabs rows; confidential workspaces flagged accordingly until enterprise/ZRM is arranged.
3. The perpetual-licence clause (F-0045) is logged as a commercial-terms risk for voice-clone features; voice cloning of real persons is out of MVP scope regardless (consent/legal surface).

### 2.2 Cloudflare Workers AI (audio)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | REST / Workers binding | F-0019 |
| Model capabilities | **Whisper-class STT**; no frontier TTS | F-0019 |
| Pricing | 10,000 Neurons/day free; $5/mo + per-Neuron paid | F-0019 |
| Privacy | Cloudflare posture; verify model card terms at integration (PV) | — |
| Registry posture | **Free STT workhorse**; TTS remains ElevenLabs-routed | F-0019 |

## 3. Concurrency-aware worker design (from F-0040)

The audio adapter must be **self-tuning** rather than statically configured:

1. Read `current-concurrent-requests` / `maximum-concurrent-requests` response headers on every call.
2. Maintain a per-model-family semaphore initialised to the plan's documented concurrency, adjusted down when 429s appear and up when headroom is reported.
3. Split script text to respect per-request character caps (eleven_v3 5,000 / Multilingual v2 10,000 / Flash 40,000) at the **shot level** — never mid-sentence; this is a Workflow Intelligence responsibility with provider caps as registry data.
4. Prefer WebSocket for long voiceover sessions (metered on active generation only) and REST for single-shot lines.

## 4. Cost envelope (MVP planning, H)

| Item | Route | Unit | Typical scene (60 s voiceover ≈ 900 chars) |
|---|---|---|---|
| Voiceover TTS | ElevenLabs Flash | $0.04–0.05/1k chars | ≈ $0.04 |
| Voiceover TTS (premium) | ElevenLabs Multilingual v3 | $0.08–0.10/1k chars | ≈ $0.08 |
| STT of user reference audio | Workers AI Whisper | free Neurons | $0 |
| Music bed (animatic) | ElevenLabs music | $0.15/min | $0.15/min |

A full 10-scene project voiceover is ≈ $0.40–0.80 — noise next to video costs, but logged in the ledger like everything else.

## 5. Open items

- **TTS rate conflict** ($0.04 vs $0.05 per 1k Flash; $0.08 vs $0.10 Multilingual) — resolve against elevenlabs.io/pricing/api at integration; registry stores whatever is read that day with `evidence_id`.
- Workers AI Whisper model card + data terms — **PV**.
- Hindi/Indian-language TTS quality on ElevenLabs v3 vs alternatives — hands-on benchmark once keys exist (KI-05); relevant to the user's known multi-language interest.
