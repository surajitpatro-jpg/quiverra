# Provider Research — Image Generation

**Version:** 2.0 · **Status:** Evidence-based · **Last verified:** 2026-11-10
**Feeds:** Model-Capability-Matrix.md (registry seed), Orchestration-Engine.md, API-Cost-Analysis.md
**Evidence base:** F-0021, F-0022, F-0036, F-0037, F-0039, F-0042, F-0043. Freshness rule applies to all pricing — re-verify at integration time via provider pricing APIs where they exist.

---

## 1. Role in the platform

Image generation is the first **paid** stage of the MVP pipeline (storyboard frames, character sheets, style frames, brand/product imagery). Image cost is small per unit ($0.003–$0.08/image on researched routes) but high-volume — a 40-shot storyboard with 2 alternates per shot is ~120 images. The router exists largely to keep this stage cheap without hiding model choice from the user.

## 2. Provider assessments

### 2.1 fal.ai (image)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Public REST + `fal-client` SDKs; `subscribe()` (server-side requeue) vs `run()` | F-0036 |
| Model capabilities / pricing (spot) | FLUX.1 [schnell] **$0.003/MP** · FLUX.1 [dev] $0.025/MP · flux-2 flash $0.005/MP · flux-2 turbo $0.008/MP · **Nano Banana 2 $0.08/image (1K)** · Seedream 5.0 Lite $0.035/image | F-0021 |
| Free quotas | None permanent; occasional coupon credits (1wk–1yr expiry) | F-0021, F-0036 |
| Commercial terms | Prepaid credits, **365-day expiry**; per-output billing (per image / per MP); pricing API to read rates from code ⇒ registry cost refresh can be automated | F-0021, F-0036 |
| Privacy | Payloads retained **90 days default**; per-request `X-Fal-Store-IO: 0`; CDN lifecycle header; full ZDR via account team | F-0042 |
| Rate limits / concurrency | Account concurrency **2 at signup → up to 40** by trailing-4-week paid invoices; only IN_PROGRESS counts; 429 type `concurrent_requests_limit` + `X-Fal-needs-retry: 1` | F-0036 |
| Reference image support | Model-dependent (Nano Banana 2 and flux-2 family accept image inputs; per-model input schema lives in the registry as capability data) | F-0021 (PV on per-model detail) |
| Failure behaviour | **5xx never billed; HTTP 422 MAY be billed** (GPU time spent) ⇒ pre-submit input validation; auto-retries on 503/504/connection; cold starts not billed | F-0036 |

### 2.2 Replicate (image)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Public REST + SDKs; version hashes pin exact model implementations | F-0022, F-0037 |
| Model capabilities / pricing (spot) | Official models output-based: **flux-schnell $3/1,000 images**, flux-1.1-pro $0.04/image; curated free collection incl. FLUX, Imagen 4, upscalers | F-0022 |
| Free quotas | **No permanent free tier** — limited free runs on the curated collection + $10 referral credit | F-0022 |
| Commercial terms | Cloudflare acquired Replicate (closed 2025-12-01); new accounts prepaid since 2025-07-16 (1-year validity, non-refundable); H100 $5.49/h for private deployments | F-0022 |
| Privacy | **API predictions: all inputs/outputs/files/logs auto-removed after 1 hour**; web predictions kept indefinitely; manual delete supported | F-0043 |
| Rate limits | Prediction creation **600 req/min**; other endpoints 3,000/min; 429 resets ~30 s; granted-credit accounts 1 rps / 6 rpm | F-0037 |
| Reference image support | Model-dependent (per-model schema in registry) | F-0022 (PV) |
| Failure behaviour | Failed runs on public/official models **unbilled**; private deployments billed for instance time; **defensive throttling as balance → $0** (keep >$20, auto-reload) | F-0037 |

### 2.3 Google Gemini image models

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Via Gemini API, per-project limits | F-0039 |
| Model capabilities | Image generation models available; **image models have NO free quota** | F-0039 |
| Pricing | Per-image / token billing per model page (freshness rule) | F-0039 |
| Free quotas | **None for image** — image generation is always paid on this route | F-0039 |
| Commercial terms | Prepay $5 min for new accounts; T1/T2/T3 caps; Batch API 50 % (image support per model) | F-0039 |
| Privacy | Paid project ⇒ no training (F-0044); image endpoints included in paid-services terms | F-0044 |
| Rate limits | Per project; IPM dimension for image; live values in AI Studio only | F-0039 |
| Reference image support | Model-dependent | PV |
| Failure behaviour | Failed 400/500 still consume quota ⇒ validate before send | F-0039 |

## 3. Reference-image support (design input for Character/Brand engines)

Explicit multi-reference conditioning is a differentiator competitors charge for (Luma Uni-1: 9 role-labelled references, F-0032; Higgsfield Cinema Studio: up to 50 references in v4.0, F-0027). On the API side, reference support is **per-model, not per-provider**, and changes fast. Therefore:

- The registry stores `reference_images: {max: int, roles: […], honesty: native|reference_conditioned|unsupported}` per model version — never assumed at provider level.
- MVP seeds: Nano Banana 2 (fal) for reference-conditioned frames; flux family for cheap non-referenced frames; character-sheet generation routed to whichever registered model currently supports multi-reference with acceptable honesty class.
- Any model whose reference support is **prompt-approximated** must be labelled so in the UI (honesty contract, ADR-0009).

## 4. Cost envelope (MVP planning, H)

| Scenario | Route | Unit cost | 120-image storyboard batch |
|---|---|---|---|
| Cheapest viable frames | FLUX.1 [schnell] via fal | $0.003/MP | ≈ $0.36 |
| Default quality frames | flux-2 flash via fal | $0.005/MP | ≈ $0.60 |
| Reference-conditioned frames | Nano Banana 2 via fal | $0.08/img | ≈ $9.60 |
| Premium single images | flux-1.1-pro via Replicate | $0.04/img | ≈ $4.80 |

The estimator quotes per-shot cost **before** generation (beating Higgsfield's cost-preview pattern, F-0028) and the ledger records actuals against estimates.

## 5. Open items

- Per-model reference-input schemas for fal flux-2 family — **PV**, read each model page at registry seed time (fal exposes machine-readable schemas).
- Replicate curated free-collection roster — verify at integration; do not hard-code.
- Gemini image model pricing — read live page at integration.
