# Model Capability Matrix

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Living document (registry seed data)
**Purpose:** the initial, evidence-backed content of the Model Capability Registry (ADR-0009). Every row cites its Evidence-Index finding. Rates are **as-verified 2026-11-10** and subject to the freshness rule — the registry maintenance loop re-verifies weekly.
**Honesty classes:** `native` = model API exposes the control directly · `prompt_approximated` = achievable via prompting only · `reference_conditioned` = requires reference media input · `unsupported` = do not claim.

---

## 1. LLM / intelligence models

| Provider | Model | Modality | Key capabilities (class) | Free tier (verified terms) | Paid pricing (as verified) | Data policy flag | Evidence |
|---|---|---|---|---|---|---|---|
| Groq | llama-3.3-70b-versatile | text | reasoning(native), json(native), tools(native), fast_inference(native) | All models free, per-model RPM/RPD/TPM table; org caps | Raised-limit paid tier | train_on_prompts: false (per Groq docs) | F-0018 |
| Groq | llama-3.1-8b-instant | text | classification(native), extraction(native) | same as above | same | false | F-0018 |
| Cloudflare Workers AI | Llama/Mistral-class (catalog) | text | chat(native), embeddings(native) | 10,000 Neurons/day shared allocation | $5/mo base + per-Neuron | provider default; verify per model | F-0019 |
| Cloudflare Workers AI | Whisper-class | audio→text | stt(native) | within Neurons allocation | per-Neuron | provider default | F-0019 |
| OpenRouter | rotating `:free` roster | text | varies per model — registry must re-resolve weekly | 20 RPM; 50 RPD free; 1,000 RPD after $10 lifetime top-up | per-model pass-through pricing | **train_on_prompts: varies — flag every free row; exclude from confidential workspaces** | F-0020 |
| Google | Gemini Flash (2.x-class) | text/vlm | reasoning(native), vlm(native), long_context(native) | Free tier post-Apr-2026 is Flash-only; exact RPD/RPM sources conflict (PV) | per-token | Google API terms | F-0017 |

**Routing consequences:**
- Free LLM capacity is real but *volatile* (rosters rotate, quotas conflict between sources). The registry never hardcodes a `:free` model name; it re-resolves.
- Groq is the primary free workhorse (speed + clear limits); Cloudflare is the daily-reset buffer; OpenRouter is overflow; Gemini Flash is dev/test-grade until its quota numbers are re-verified against the official page (F-0017 caveat).

## 2. Image generation models (via fal.ai unless noted)

| Model | Pricing (verified) | Unit | Notes | Evidence |
|---|---|---|---|---|
| FLUX.1 [schnell] | $0.003 | per MP | cheapest verified image option | F-0021 |
| fal-ai/flux-2/flash | $0.005 | per MP | | F-0021 |
| fal-ai/flux-2/turbo | $0.008 | per MP | | F-0021 |
| FLUX.1 [dev] | $0.025 | per MP | | F-0021 |
| Seedream 5.0 Lite | $0.035 | per image | | F-0021 |
| Recraft V4 style | $0.035 ($0.10 pro) | per image | style-locked outputs — brand-relevant | F-0021 |
| Nano Banana 2 | $0.08 | per image (1K) | | F-0021 |
| GPT Image 2 (medium) | ~$0.02 (~$1.00/MP effective) | per image | | F-0021 |
| Qwen image | $0.02 | per MP | cheapest per-MP via fal in one review | F-0021 |
| Replicate: flux-schnell | $3.00 | per 1,000 images | output-based official model | F-0022 |
| Replicate: flux-1.1-pro | $0.04 | per image | | F-0022 |

## 3. Video generation models

| Provider | Model/tier | Pricing (verified) | Unit | Notes | Evidence |
|---|---|---|---|---|---|
| fal | Wan 2.5 | $0.05 | /s | cheapest verified video | F-0021 |
| fal | Kling 2.5 Turbo Pro | $0.07 | /s | | F-0021 |
| fal | Kling 3.0 Pro | $0.112 (no audio) | /s | app-side: 12cr/s w/audio, 8cr/s without (F-0011) | F-0021 |
| fal | Veo 3.1 | $0.20 no-audio / $0.40 w-audio | /s (1080p) | aggregator markup vs direct Gemini | F-0021 |
| Google Gemini API | Veo 3.1 Lite | $0.05 (720p) / $0.08 (1080p) | /s | audio included; successful gens only | F-0024 |
| Google Gemini API | Veo 3.1 Fast | $0.10 (720p) / $0.12 (1080p) / $0.30 (4K) | /s | | F-0024 |
| Google Gemini API | Veo 3.1 Standard | $0.40 (720p/1080p) / $0.60 (4K) | /s | scene extension, last-frame control = native | F-0024 |
| Google Gemini API | Gemini Omni Flash (`gemini-omni-1.1-flash`) | ~$0.10 effective @720p | token-billed (5,792 tok/s @ $17.50/M) | Google's recommended default video model (GA 2026-08-27); Veo prompts do not carry over | F-0024 |
| Runway | Gen-4.5 | $0.12 | /s (API) | no persistent memory (F-0010) | F-0010 |
| Runway | Aleph 2.0 | $0.28 | /s | video editing | F-0010 |
| Pika | API | from ~$0.04 | /s | aggregator relaunch | F-0013 |
| BytePlus | Seedance 2.5 | $0.231 (720p) / $0.569 (1080p) | /s | Mini at $0.08/s; enterprise discount ~$0.03/s (to Oct 2026) | F-0024 |
| (removed) | Sora 2 | API shut down 2026-09-24 | — | do not route; retained as deprecation precedent | F-0024 |

## 4. Audio / voice

| Provider | Model | Pricing | Unit | Free tier | Evidence |
|---|---|---|---|---|---|
| ElevenLabs | Flash/Turbo, v3 Conversational | $0.05 (one source: $0.04 — conflict noted) | /1k chars | 10k credits/mo **non-commercial + attribution ⇒ internal-only routing** | F-0023 |
| ElevenLabs | Multilingual v2 / Eleven v3 | $0.10 (conflict: $0.08) | /1k chars | — | F-0023 |
| ElevenLabs | Scribe v2 STT | $0.22 | /hour | — | F-0023 |
| ElevenLabs | Music | $0.15 | /min | — | F-0023 |
| Cloudflare | Whisper-class | per-Neuron | — | within 10K/day | F-0019 |

## 5. Capability-honesty examples (registry semantics)

These rows show how the classification enum (ADR-0006) applies to real models — the differentiator no competitor exposes (F-0016):

| Requested control | Kling 3.0 (via fal) | Veo 3.1 Standard (Gemini) | Runway Gen-4.5 |
|---|---|---|---|
| Text→video | native | native | native |
| Image→video | native | native | native |
| Motion path control | native (Motion Brush, F-0011) | prompt_approximated | prompt_approximated |
| Last-frame control | unsupported | native (F-0024) | unsupported |
| Scene extension | prompt_approximated | native (F-0024) | prompt_approximated |
| Character identity hold | reference_conditioned (Elements, F-0011) | reference_conditioned | reference_conditioned |
| Native audio | native (Kling w/audio tier) | native (included) | varies |

## 6. Registry maintenance requirements (operational)

1. Weekly re-verification job: fal pricing API (F-0021), provider pricing pages for the rest; diff → new registry versions → Evidence-Index append.
2. Deprecation watch: Google's Veo→Omni-Flash repositioning (F-0024) and Sora's API shutdown prove models die/rebrand within months; every registry row carries `valid_to` discipline and the compiler warns workflows pinned to near-EOL rows.
3. Conflict protocol: when sources disagree (Gemini RPD, F-0017; ElevenLabs rates, F-0023), both values are recorded with `confidence: PV`, and the router uses the **conservative** value until the official page settles it.
4. Aggregator-vs-direct check: fal marks up direct APIs (F-0021); for high-volume models the cost analysis (API-Cost-Analysis.md) decides direct-integration breakpoints.
