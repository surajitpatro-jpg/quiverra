# Provider Research — Video Generation

**Version:** 2.0 · **Status:** Evidence-based · **Last verified:** 2026-11-10
**Feeds:** Model-Capability-Matrix.md, Orchestration-Engine.md, Cinema-Intelligence-Engine.md, API-Cost-Analysis.md
**Evidence base:** F-0011, F-0021, F-0022, F-0024, F-0030..F-0032, F-0034, F-0036..F-0038, F-0041. Freshness rule applies to all pricing.

---

## 1. Role in the platform

Video generation is the **most expensive and most failure-prone** stage (industry norm: completed-but-defective output is always charged, F-0034; Kling users report 40–60 % peak-hour failure). The Cinema Intelligence Engine's value proposition depends on knowing **which camera/motion controls are model-native vs prompt-approximated** — this document is the provider-side evidence base for that classification.

## 2. Provider assessments

### 2.1 fal.ai (video aggregation)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | `subscribe()` + webhook recommended | F-0036 |
| Model capabilities / pricing (spot) | Wan 2.5 **$0.05/s** · Kling 2.5 Turbo Pro $0.07/s · Kling 3.0 Pro **$0.112/s** (no audio) · Veo 3.1 $0.20/s no-audio / $0.40/s w-audio 1080p | F-0021 |
| Free quotas | None permanent | F-0021 |
| Commercial terms | Prepaid 365-day credits; per-second billing; pricing API readable from code | F-0021, F-0036 |
| Privacy | 90-day payload default; `X-Fal-Store-IO: 0`; ZDR via account team | F-0042 |
| Concurrency | 2 → 40 by purchase history; IN_QUEUE unlimited | F-0036 |
| Video controls | Per-model; capability registry rows carry honesty classes (see §3) | F-0021 |
| Failure behaviour | 5xx unbilled; 422 may be billed; auto-retry 503/504 | F-0036 |

### 2.2 Replicate (video)

- Same operational contract as image (§2.2 of Provider-Research-Image.md): 600 pred/min, 1-hour file deletion ⇒ **immediate R2 ingestion is a hard requirement**, failed public-model runs unbilled.
- **Price position: Replicate charges exactly 2× fal for identical Kling v3 ($0.168 vs $0.084/s)** ⇒ router cost tables must rank fal above Replicate for Kling; Replicate remains the fallback for catalog diversity. | F-0037, F-0038 |

### 2.3 Kling direct API

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | Official developer API, prepaid **unit packages** | F-0038 |
| Pricing | $0.14/unit list; trial 100 units $9.80 (30-day); 5,000 units $700 (180-day); 30 k+ $0.126/unit; Kling 3.0 ladder 0.6–1.2 units/s; 4K 3 units/s | F-0038 |
| Free quotas | Web app free tier 66 cr/day (24 h expiry, no commercial use) — **app-side, not API** | F-0011 |
| Commercial terms | Package-based concurrency 5–20 simultaneous tasks; prepaid expiry per package | F-0038 |
| Video controls | **Motion Control is I2V-only** (character image + reference video 2–5 s optimal; API: one character ref per request); orientation modes Matches Video / Matches Image; strength ↔ cfg_scale (PV); Motion Brush = painted vectors, cheaper | F-0031 |
| Failure behaviour | User-reported 40–60 % peak-hour failure, "99 % freeze" (user-reported, not official); only server failures auto-refund | F-0034 |
| Registry posture | Direct API becomes cost-competitive at ≥5 k unit packages; below that, fal aggregation wins on simplicity | F-0038 |

### 2.4 Runway (Dev API)

| Attribute | Detail | Evidence |
|---|---|---|
| API availability | docs.dev.runwayml.com; Gen-4.5 $0.12/s API | F-0010 |
| Notable | **Kling 4.0 live via Runway Dev (`kling_4` $0.157/s 720p, $0.235/s 1080p) before Kling's own API** — aggregator-first availability is a real pattern | F-0038 |
| Video controls (app-side evidence for capability modelling) | Camera Control panel pan/tilt/zoom/roll/dolly; first+last keyframes; Fix Seed; ≤3 @-references; Aleph edit takes only first 5 s; 4K upscale separate paid action; trim/retime free | F-0030 |
| Failure behaviour | Auto-refund on generation error; stuck gens auto-cancel 1–2 h | F-0030, F-0034 |

### 2.5 Google Veo / Gemini video

| Attribute | Detail | Evidence |
|---|---|---|
| Pricing | Veo 3.1 Lite $0.05/s 720p · $0.08/s 1080p; Fast $0.10–0.12/s; Standard $0.40–0.60/s; **bills successful generations only** | F-0024 |
| Positioning shift | Google now recommends **`gemini-omni-1.1-flash`** (GA 2026-08-27, ~$0.10/s effective 720p) as default video model; Veo reserved for scene extension / last-frame control / legacy | F-0024 |
| Free quotas | None for video | F-0024, F-0039 |
| Privacy | Paid-project terms (no training) apply | F-0044 |
| Failure behaviour | Successful-only billing is the fairest researched contract; consumer-plan refunds inconsistent | F-0034 |

## 3. Model-native control evidence (Cinema Engine input)

| Control | Native implementations (verified) | Honesty implication |
|---|---|---|
| Camera move (pan/tilt/zoom/roll/dolly) | Runway Camera Control panel (F-0030); LTX per-shot 3D camera (F-0033); Higgsfield DOP (F-0029) | Registry must distinguish `native` (dedicated API param) from `prompt_approximated` (text only) |
| Keyframes | Runway first+last (F-0030); Luma Ray3.2 up to **16 keyframes** (F-0032) | `keyframe_support: {positions, max_count}` per model |
| Motion transfer | Kling Motion Control I2V-only, two orientation modes (F-0031); Runway Act-Two (F-0030) | `motion_control: native` with constraint fields (needs reference video, I2V-only) |
| Motion strength | Luma Motion slider 1–9 decoupled from Structure (F-0032); Kling cfg_scale mapping (PV) | Continuous control ⇒ registry stores parameter range |
| Identity persistence | Runway Fix Seed (F-0030); Kling voice-bound Elements (F-0011) | `seed_control: native` vs `unsupported` |
| Extend/loop | Luma Ray3.14 Extend + loops, but **no character references, no EXR** (F-0032) | Capability rows are per-model-version, never per family |

This is the evidence spine of the Cinema Engine's "actual model-specific capabilities, not just prompt-based controls" requirement.

## 4. Self-hosted path (future, architecture-ready)

Open-weight video models are viable future registry rows (`provider: self`) with the same capability schema — **no design change needed** (ADR-0009):

| Model | License | Hardware | Economics | Evidence |
|---|---|---|---|---|
| Wan 2.2 | Apache 2.0 | 5B on 24 GB; A14B needs 80 GB (720p) | RunPod A100 $1.19–1.79/h | F-0041 |
| LTX-2.5 | Free <$10 M ARR | 32 GB FP8 min; A100/H100 rec.; native audio | measured ≈**$0.002/s vs $0.05+/s API** | F-0041 |
| HunyuanVideo 1.5 | Tencent (<100 M MAU) | 14 GB w/ offloading | RTX A6000 $0.33–0.59/h | F-0041 |

Break-even serverless↔pod at ~66 % utilisation; storage $0.07/GB/mo. Wan 2.5/2.6 and FLUX 3 Video are API-only — no public weights. Self-hosting is **post-MVP**, but every registry row written today must be writable for a self-hosted endpoint tomorrow.

## 5. Failure economics (routing policy input)

- Industry norm: **completed-but-bad output is charged everywhere researched** (F-0034) ⇒ the platform's acceptance-rate telemetry and pre-generation validation are the cost-control levers, not refunds.
- Server-error refund norms: fal 5xx unbilled; Replicate public-model failures unbilled; Veo bills successes only; Kling/Higgsfield/Runway auto-refund server errors.
- Router implication: per-provider `failure_billing_policy` is registry data; the Cost Estimator multiplies quoted price by the workspace's measured acceptance rate to show **expected cost per accepted clip**, not nominal price per attempt.

## 6. Open items

- Kling cfg_scale mapping — **PV**, confirm against official API params at integration.
- Kling 4.0 official API availability — monitor; currently Runway-Dev-only (F-0038).
- Gemini Omni Flash video quality vs Veo for storyboard shots — needs hands-on benchmark once keys exist (KI-05).
