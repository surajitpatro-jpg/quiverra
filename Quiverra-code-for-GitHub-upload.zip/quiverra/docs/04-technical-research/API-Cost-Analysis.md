# API Cost Analysis

**Version:** 1.0 · **Date:** 2026-11-10 · **Status:** Draft for gate review
**Basis:** Evidence F-0017..F-0024 (all rates as verified 2026-11-10, freshness rule applies). USD working currency; INR conversion at pricing time, not here (rates volatile — mark U until quoted).

---

## 1. The structural asymmetry

Verified provider economics create a hard asymmetry the whole business model must respect:

- **Intelligence is (nearly) free.** Groq (all models free within limits, F-0018), Cloudflare (10K Neurons/day, F-0019), OpenRouter (50–1000 free RPD, F-0020), Gemini Flash free tier (F-0017, PV). Our seven engines' text/VLM workload can run at ~$0 marginal cost within published terms.
- **Generation is never free at production quality.** Cheapest verified video: Wan 2.5 $0.05/s (F-0021). Cheapest verified images: FLUX.1 [schnell] $0.003/MP (F-0021). Voice: $0.05/1k chars paid, free tier non-commercial (F-0023).

**Conclusion:** give the intelligence layer away (it's our moat and costs us ~nothing), meter generation honestly (it's a pass-through with transparent margin), and never blend the two ledgers.

## 2. Unit-cost reference table (verified rates)

### 2.1 Per finished 8-second 1080p video clip (single successful generation)

| Route | Rate | Clip cost | Evidence |
|---|---|---|---|
| fal · Wan 2.5 (720p base) | $0.05/s | $0.40 | F-0021 |
| fal · Kling 2.5 Turbo Pro | $0.07/s | $0.56 | F-0021 |
| Gemini · Veo 3.1 Lite 1080p | $0.08/s | $0.64 | F-0024 |
| Gemini · Veo 3.1 Fast 1080p | $0.12/s | $0.96 | F-0024 |
| fal · Kling 3.0 Pro (no audio) | $0.112/s | $0.90 | F-0021 |
| Runway Gen-4.5 | $0.12/s | $0.96 | F-0010 |
| fal · Veo 3.1 w/audio 1080p | $0.40/s | $3.20 | F-0021 |
| Gemini · Veo 3.1 Standard 1080p | $0.40/s | $3.20 | F-0024 |

### 2.2 Per image (≈1MP output)

| Route | Cost | Evidence |
|---|---|---|
| fal · FLUX.1 [schnell] | $0.003 | F-0021 |
| fal · flux-2/flash | $0.005 | F-0021 |
| fal · Seedream 5.0 Lite | $0.035 | F-0021 |
| Replicate · flux-1.1-pro | $0.04 | F-0022 |
| fal · Nano Banana 2 | $0.08 | F-0021 |

### 2.3 Voice (per finished minute ≈ 1,000 chars)

| Route | Cost/min | Evidence |
|---|---|---|
| ElevenLabs Flash/Turbo | $0.05 | F-0023 |
| ElevenLabs Multilingual v2/v3 | $0.10 | F-0023 |

## 3. Retry-rate honesty (the number everyone hides)

Single-shot prices are marketing; **accepted-output prices are economics**. A 10-clip storyboard on Veo 3.1 Fast 1080p:

| Acceptance rate | Attempts per accepted clip | Real cost (10 clips) |
|---|---|---|
| 100% (fantasy) | 1 | $9.60 |
| 50% | 2 | $19.20 |
| 33% | 3 | $28.80 |

Worked example mirrors the benchlm methodology (F-0024): three attempts per kept clip is a planning placeholder, **not** a measurement — Phase 7 telemetry will publish our real acceptance-rate distributions per model, which becomes proprietary pricing intelligence (PM-adjacent asset). Cost Estimator ships with a configurable `retry_multiplier` per (model, task type), initialised at 2.0 and calibrated by our own run data.

## 4. Free-tier capacity budget (intelligence layer)

Conservative daily free capacity for platform-level intelligence tasks (planning, continuity checks, compliance checks, brief structuring):

| Provider | Verified free terms | Conservative usable/day (with 20% safety margin) | Evidence |
|---|---|---|---|
| Groq | per-model RPM/RPD table | model-dependent; assume thousands of short calls | F-0018 |
| Cloudflare | 10K Neurons/day | ~8K Neurons | F-0019 |
| OpenRouter | 50 RPD (1,000 after $10) | 40–800 calls | F-0020 |
| Gemini Flash | Flash-only free tier, quotas disputed | treated as dev/test only until re-verified | F-0017 |

MVP workload estimate (Hypothesis, to be validated in Phase 7): ~50–200 intelligence calls per active project-day, mostly <2K tokens ⇒ free capacity comfortably covers early hundreds of projects. This is why the moat is cheap to operate.

## 5. Customer-facing pricing logic (recommendation, not yet policy)

Subject to the billing/legal gate (payments stay dormant until defined):

1. **Credits = INR-denominated**, purchased via Razorpay/Cashfree; ledger in credits, costs converted at purchase-day rate with disclosed margin.
2. **Pass-through + disclosed margin** on generation (target 20–30% over provider cost), shown against the live registry price — "you pay what the model costs plus a visible platform fee" is itself a differentiator against opaque credit bundling (Higgsfield effective $0.50–$1.27 per finished video with no-rollover/90-day expiry, F-0007).
3. **Intelligence free, metered visibly:** show users the free-tier consumption their project used ("your planning used 4,312 free tokens today") — transparency as marketing.
4. **Expiry:** reject the industry hostile norm (F-0007) — recommend ≥12-month validity; schema supports whatever legal decides.
5. **Refund mirror:** customer refunds mirror provider billing semantics — unbillable failures (fal 5xx, Replicate public, F-0021/22) refund automatically; billable failures are disclosed with the provider's policy line.

## 6. Aggregator vs direct integration breakpoints

fal carries a markup over direct provider APIs (F-0021, aireiter comparison). Decision rule for the roadmap:

| Model family | Start with | Move to direct when… |
|---|---|---|
| Kling | fal | monthly Kling spend > ~$500 and direct Kling API terms verified cheaper after our retry rate |
| Veo / Omni Flash | Gemini API direct (already cheapest, F-0024) | — |
| Wan/Seedance | fal | if Seedance enterprise discount (~$0.03/s, F-0024) is attainable at our volume |
| Flux images | fal | volume >100K images/mo → compare Replicate/Together (F-0022) |
| ElevenLabs | direct plan | immediately (plan economics beat aggregator passthrough; concurrency needed anyway, F-0023) |

## 7. Cost risks register

| Risk | Evidence basis | Mitigation |
|---|---|---|
| Provider price rises (Kling +40% during 2026) | F-0011 | registry versioning; estimates pinned at snapshot; margin buffer |
| Model deprecation mid-quarter (Sora API, Veo repositioning) | F-0024 | deprecation watch; capability-equivalent re-routing table |
| Free-tier withdrawal/narrowing (Gemini precedent Apr 2026) | F-0017 | multi-provider free portfolio; never structurally dependent on one |
| Aggregator consolidation repricing (Cloudflare↔Replicate) | F-0022 | keep adapters separate; re-price on merger news |
| Retry-rate blowout on hard briefs | §3 | estimator retry multiplier + budget caps + acceptance telemetry |

## 8. Open financial decisions for the gate

1. Margin % on generation pass-through (recommendation: 25% launch, reviewed quarterly).
2. Whether intelligence stays free at scale or gets a fair-use cap per workspace (recommendation: soft cap + overflow to user-authorised paid).
3. Credit expiry policy (recommendation: 12 months, pending legal).
4. INR pricing page values — deferred until purchase-time FX quote (U per methodology).
