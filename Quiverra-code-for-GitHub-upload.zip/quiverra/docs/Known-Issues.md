# Known Issues & Open Limitations

**Last updated:** 2026-11-10

| # | Severity | Issue | Impact | Mitigation / status |
|---|---|---|---|---|
| KI-01 | Medium | git push/clone to github.com blocked in build environment | No direct GitHub synchronisation | User mirrors workspace to GitHub (ADR-0001) |
| KI-02 | Medium | Docker unavailable in build environment | Cannot build/test deployment images here | Deployment artefacts are authored and statically validated; user builds on VPS (Phase 7) |
| KI-03 | Low | Default Node is 20.20.2; REA needs ≥22.23.4 | REA needs per-session Node bootstrap (~1–3 min) | Documented bootstrap procedure (00-REA-Readiness.md §2.3) |
| KI-04 | Low | No persistent long-running processes between tool calls | Dev servers/workers can't stay alive | Verification via builds, tests, platform preview system |
| KI-05 | Medium | No AI provider API keys configured | Provider research is documentation-based only; no live benchmarking yet | User to supply keys later, server-side env vars only |
| KI-06 | Low | api.github.com rate-limited (unauthenticated) | Repo metadata lookups limited | Use codeload/raw endpoints; cache fetched material under `evidence/references/` |
| KI-07 | Low | REA `analyze-web-bundle` CLI contract **resolved 2026-11-10** (`--view` requires `--detail summary` and `--evidence_output`; complete mode needs no `--view`). Standing blocker: Chromium page-attach via CDP times out (`Page.enable` no response) — retried at 20s/60s/90s per remediation guidance; page loads fine (title retrievable via `/json`), so this is environment-level CDP WebSocket instability, not a REA defect | REA browser-based analysis path not viable in this sandbox; screenshots/bundle analysis deferred | Per ADR-0003: one evidence-based retry performed, then switched permanently to web fetch/search as the equivalent evidence path; all F-0025..F-0041 gathered that way. Re-attempt REA analysis only if the sandbox image changes |
