# Quiverra — AI Creative Production Operating System

> **Product name: Quiverra** (confirmed by the owner, 2026-11-10). The category
> descriptor remains the positioning line; working codename was "Baap of Higgsfield".

**Working codename:** Baap of Higgsfield
**Status:** Gate PASSED (2026-11-10) — planning + architecture approved with directions (ADR-0016..0021); Phase 6 implementation ready to start (W0–W1)
**Last updated:** 2026-11-10 (post-gate decision propagation)

---

## What this project is

A professional AI Creative Production Platform — an "operating system" for creative production that takes a user from an unstructured creative brief to a finished, professionally structured production (concepts, characters, scripts, storyboards, shots, images, video, audio), with proprietary intelligence layers on top of third-party AI generation providers.

Inspired by the capability class of Higgsfield AI, but differentiated by proprietary systems for creative direction, character persistence, cinematic control, scene continuity, brand intelligence and workflow automation — and by three honesty contracts no competitor offers: **plan-before-pay cost estimation**, **capability honesty** (model-native vs prompt-approximated controls, labelled), and **billing transparency** (double-entry ledger, no silent paid spend).

**Core philosophy:** third-party models provide generation; the platform owns the intelligence, structure, planning, controls, continuity, evaluation and production experience.

## Repository layout

```text
creative-platform/
├── README.md                     ← you are here
├── docs/
│   ├── 00-research-management/   ← methodology, evidence index (+ evidence excerpts), progress
│   ├── 01-competitive-research/  ← Higgsfield map, benchmark, feature comparison, gap analysis
│   ├── 02-proprietary-systems/   ← the seven intelligence system specifications (v0.2)
│   ├── 03-system-architecture/   ← overall, database (v2), API, orchestration, workflow,
│   │   │                           security, deployment + Credit-Ledger, Asset-Storage,
│   │   │                           Quota-Reservations (correction phase)
│   │   └── api/openapi.yaml      ← formal API contract (ADR-0015)
│   ├── 04-technical-research/    ← provider research ×4 (intelligence/image/video/audio),
│   │                               model capability matrix, API cost analysis
│   ├── 05-innovation-strategy/   ← innovation opportunities, differentiation, prioritisation
│   └── 06-product-planning/      ← PRD, MVP scope, roadmap, testing, journeys, acceptance
│                                   criteria, infrastructure costs (Phase 5)
├── diagrams/                     ← Mermaid architecture diagrams
└── application/                  ← production application source (Phase 6+, not started)
```

## Project management files

| File | Purpose |
|---|---|
| `docs/00-research-management/Research-Progress.md` | What has been done, phase by phase |
| `docs/00-research-management/Evidence-Index.md` | Every research finding (F-0001..F-0045), classified by confidence |
| `docs/00-research-management/evidence/` | Underlying source excerpts behind the findings |
| `docs/Implementation-Progress.md` | Development milestones and their test status |
| `docs/Architecture-Decisions.md` | ADR log — ADR-0001..0015 |
| `docs/Known-Issues.md` | Open limitations and unresolved problems |

## Resuming in a new session

1. Read this README.
2. Read `docs/00-research-management/Research-Progress.md` for the current position.
3. Read `docs/Known-Issues.md` before repeating any failed approach.
4. Continue from the next unchecked item in the active phase.

## Current position (2026-11-10, post-gate)

- Phases 0–5 complete; correction phase complete; **gate passed**. The user approved the MVP scope and roadmap with six directions, recorded as ADR-0016..0021: staged provider onboarding (Gemini, Groq, fal.ai, R2 first — Replicate/ElevenLabs/specialist video deferred), ₹0 paid-LLM budget (free-only; benchmark before any paid approval), deferred configurable commercial parameters (payments dormant), confidential-by-default privacy, and Supabase Mumbai (ap-south-1) with an honest residency register.
- **Phase 6 implementation is unblocked.** Per Development-Roadmap.md v1.1: start W0 (repo scaffold + CI) → W1 (DB foundation). Owner actions needed by W5/W13: create the four initial provider accounts (week 1), and the ElevenLabs account + data-use opt-out verification before any content is submitted.
- Docs updated post-gate: Security v1.1, Deployment v1.1 (residency register), Credit-Ledger §8 (configurable commercials), Roadmap v1.1 (staged W5, 13–17 weeks), PRD v1.1, MVP-Scope v1.1, Implementation-Progress §4 (gate record).

## Source of truth

**GitHub repository:** [`https://github.com/surajitpatro-jpg/quiverra.git`](https://github.com/surajitpatro-jpg/quiverra.git) (created by the project owner, 2026-11-10; supersedes the earlier `surajitpatro/platformai` repo).

The workspace at `/mnt/agents/output/creative-platform/` is the working source of truth because direct git push from the build environment is unavailable (see `docs/00-research-management/00-REA-Readiness.md`). The folder is structured to be dropped into the `quiverra` repository as-is.

**Mirroring procedure (run locally, at each phase boundary):**
```bash
git clone https://github.com/surajitpatro-jpg/quiverra.git
# download/copy the creative-platform folder contents into the repo root
cd quiverra && git add -A && git commit -m "Correction phase + Phase 5 sync" && git push
```
