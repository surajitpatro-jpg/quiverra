# Setup & Deployment Guide — W0/W1/W2

Quiverra — AI Creative Production Operating System, application monorepo.
Phase 6 status: **W0+W1 approved; W2 (auth & workspace onboarding) built and locally
verified — real-Supabase validation pending project credentials.**

## 2b. Supabase (W2)

Create the project at supabase.com — **region: Mumbai (ap-south-1)** (ADR-0021).
Then wire the environment:

| Where            | Variable                        | Source (Supabase dashboard)                                      |
| ---------------- | ------------------------------- | ---------------------------------------------------------------- |
| API `.env`       | `SUPABASE_URL`                  | Project Settings → API → Project URL                             |
| API `.env`       | `SUPABASE_SERVICE_ROLE_KEY`     | Project Settings → API → `service_role` (secret)                 |
| API `.env`       | `DATABASE_URL`                  | Project Settings → Database → connection string (session pooler) |
| Web `.env.local` | `NEXT_PUBLIC_SUPABASE_URL`      | Project URL                                                      |
| Web `.env.local` | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `anon` `public` key                                              |
| Web `.env.local` | `NEXT_PUBLIC_API_URL`           | `http://localhost:4000` in dev                                   |

Auth settings (Authentication → Sign In / Providers): Email provider ON,
"Confirm email" ON (verification is a W2 requirement). Site URL =
`http://localhost:3000` in dev; add `http://localhost:3000/auth/callback` to
Redirect URLs.

Migrations run with the same command against the Supabase connection string —
`0001`'s `auth.users` stub is `IF NOT EXISTS`, so it is a no-op where Supabase's
real `auth.users` exists.

**The service-role key is server-only.** It must never appear in the web bundle,
the repo, or docs. The web app uses only the anon key (RLS-protected by design).

## 1. Prerequisites

| Tool       | Version       | Notes                                   |
| ---------- | ------------- | --------------------------------------- |
| Node.js    | ≥ 20          | enforced via `engines` in package.json  |
| npm        | ≥ 10          | workspaces required                     |
| PostgreSQL | 15            | local dev, CI service, or Supabase      |
| Redis      | 7 (W2 onward) | quota reservations; not used by W1 code |

## 2. First-time setup

```bash
cd application
npm install
cp .env.example .env    # fill in real values — never commit .env
```

`.env` is validated at boot by `@platform/config` (Zod, fail-closed): the API will
not start with missing required secrets. `.env.example` documents every variable;
provider keys (Gemini/Groq/fal/Replicate/ElevenLabs) are optional until their
milestone and must stay server-side only (ADR-0017).

Dormant-by-default commercial flags (ADR-0018/0019):

- `PAYMENTS_ENABLED=false` — setting `true` in development throws at boot.
- `INTELLIGENCE_PAID_CEILING_INR=0` — paid-LLM ceiling is ₹0 until changed by approval.

## 3. Database

```bash
# create + migrate a dev database
createdb platform_dev
DATABASE_URL=postgres://postgres:postgres@localhost:5432/platform_dev \
  npm run db:migrate --workspace packages/db
```

Migrations are forward-only, applied in journal order:

1. `migrations/0000_w1_foundation.sql` — Drizzle-generated tables, enums, indexes,
   unique constraints and the asset `r2_key` prefix CHECK.
2. `migrations/0001_policies_and_functions.sql` — hand-written: auth stub, RLS +
   FORCE on all tenant tables, grants, audit triggers, ledger immutability,
   balanced-postings constraint trigger, system accounts, balance view,
   `app.provision_workspace()`, and the single write door `ledger.post()`.

Schema changes: edit `packages/db/src/schema.ts`, then
`npm run db:generate --workspace packages/db` and review the generated SQL before
committing. Custom SQL (policies, functions, triggers, views) is added as a new
hand-written migration — never edit an applied migration (Database-Architecture.md §9).

## 4. Running

```bash
npm run dev:api     # Fastify on :4000 — GET /healthz, GET /version
npm run dev:web     # Next.js on :3000
```

`GET /version` exposes the dormant commercial flags so a misconfigured deployment
is visible immediately (`paymentsEnabled: false`, `intelligencePaidCeilingInr: 0`).

## 5. Verification (what CI runs)

```bash
npm run lint
npm run typecheck
DATABASE_URL=postgres://postgres:postgres@localhost:5432/platform_w1_test \
  npm run test          # db suite creates a FRESH platform_w1_test each run
npm run build
```

The DB test suite (27 tests) drops/recreates the test database, runs all
migrations, then verifies: migration shape, RLS cross-tenant isolation (incl.
FORCE for table owners), asset prefix CHECK and workspace-scoped dedup, audit
trigger rows, and every ledger recipe plus a 400-operation randomised property
test asserting `available ≥ 0`, `reserved ≥ 0` and zero ledger drift.

CI (`.github/workflows/ci.yml`) runs gitleaks, then the same steps against a
`postgres:15` service on every push/PR.

## 6. Deployment (current stage)

No production deployment is enabled at W1. Target topology when approved
(Deployment.md): Vercel (web) + Render/Fly (api) + Supabase PostgreSQL
(**Mumbai / ap-south-1**, ADR-0021) + Upstash Redis + Cloudflare R2. Provider
credentials are provisioned per milestone and stored only in server-side
environment variables — never in the repo, docs, or frontend bundles.

## 7. Troubleshooting

- **npm warns about esbuild install scripts** — run
  `npm install-scripts approve esbuild` once; the sandbox/CI blocks postinstall
  scripts by default.
- **`password authentication failed`** — set the local postgres password or use
  peer auth; tests expect `postgres:postgres` by default (override via
  `DATABASE_URL`).
- **`ledger tables are append-only`** — expected: ledger corrections are reversing
  transactions via `ledger.post('adjustment' | …)`, never UPDATE/DELETE.
