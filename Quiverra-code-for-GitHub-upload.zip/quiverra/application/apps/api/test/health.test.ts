import { describe, expect, it } from "vitest";
import { buildServer } from "../src/server.js";

const env = {
  APP_ENV: "test" as const,
  PAYMENTS_ENABLED: "false" as const,
  INTELLIGENCE_PAID_CEILING_INR: 0,
  SUPABASE_URL: "https://example.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: "test-only",
  DATABASE_URL: "postgres://postgres:postgres@localhost:5432/platform_api_test",
  APP_URL: "http://localhost:3000",
};

describe("api skeleton (W0)", () => {
  it("healthz responds ok", async () => {
    const app = buildServer(env);
    const res = await app.inject({ method: "GET", url: "/healthz" });
    expect(res.statusCode).toBe(200);
    expect(res.json()).toEqual({ status: "ok" });
    await app.close();
  });

  it("version exposes the ₹0 paid-LLM ceiling and dormant payments (ADR-0018/0019)", async () => {
    const app = buildServer(env);
    const res = await app.inject({ method: "GET", url: "/version" });
    const body = res.json();
    expect(body.paymentsEnabled).toBe(false);
    expect(body.intelligencePaidCeilingInr).toBe(0);
    await app.close();
  });
});
