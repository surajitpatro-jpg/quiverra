import { beforeAll, describe, expect, it } from "vitest";
import { buildServer } from "../src/server.js";
import { TenantDb } from "../src/db.js";
import type { VerifyToken } from "../src/auth.js";

/**
 * W2 API tests: real Fastify routes + real migrated PostgreSQL + real RLS.
 * Only the Supabase token verifier is stubbed (it is validated separately
 * against the real Supabase project — see W2 validation report).
 */
const DATABASE_URL =
  process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/platform_api_test";

export const users = {
  a: { id: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", email: "a@test.dev" },
  b: { id: "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb", email: "b@test.dev" },
  c: { id: "cccccccc-cccc-cccc-cccc-cccccccccccc", email: "c@test.dev" },
} as const;

const verifyToken: VerifyToken = async (token) => {
  if (token === "tok-a") return { ...users.a };
  if (token === "tok-b") return { ...users.b };
  if (token === "tok-c") return { ...users.c };
  return null;
};

const env = {
  APP_ENV: "test" as const,
  PAYMENTS_ENABLED: "false" as const,
  INTELLIGENCE_PAID_CEILING_INR: 0,
  SUPABASE_URL: "https://example.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: "test-only",
  DATABASE_URL,
  APP_URL: "http://localhost:3000",
};

function makeApp() {
  const db = TenantDb.connect(DATABASE_URL);
  return buildServer(env, { verifyToken, db });
}

function auth(token: string) {
  return { authorization: `Bearer ${token}` };
}

describe("W2 — authentication & workspace onboarding (API + RLS)", () => {
  let app: ReturnType<typeof makeApp>;
  let wsId = "";
  let inviteToken = "";

  beforeAll(async () => {
    app = makeApp();
    await app.ready();
    return async () => {
      await app.close();
    };
  }, 30_000);

  it("rejects unauthenticated requests", async () => {
    expect((await app.inject({ method: "GET", url: "/me" })).statusCode).toBe(401);
    expect(
      (await app.inject({ method: "GET", url: "/me", headers: auth("bogus") })).statusCode,
    ).toBe(401);
  });

  it("provisions a workspace; creator becomes owner and sees it listed", async () => {
    const created = await app.inject({
      method: "POST",
      url: "/workspaces",
      headers: auth("tok-a"),
      payload: { name: "Alpha" },
    });
    expect(created.statusCode).toBe(201);
    wsId = created.json().id;
    expect(created.json().role).toBe("owner");

    const me = await app.inject({ method: "GET", url: "/me", headers: auth("tok-a") });
    expect(me.json().workspaces.map((w: { name: string }) => w.name)).toContain("Alpha");
  });

  it("denies a non-member any access (API-level cross-tenant check)", async () => {
    const res = await app.inject({
      method: "GET",
      url: `/workspaces/${wsId}/members`,
      headers: auth("tok-b"),
    });
    expect(res.statusCode).toBe(403);
    expect(res.json().error.code).toBe("not_member");

    const audit = await app.inject({
      method: "GET",
      url: `/workspaces/${wsId}/audit`,
      headers: auth("tok-b"),
    });
    expect(audit.statusCode).toBe(403);
  });

  it("owner invites B as editor; invitation is listed", async () => {
    const res = await app.inject({
      method: "POST",
      url: `/workspaces/${wsId}/invitations`,
      headers: auth("tok-a"),
      payload: { email: "b@test.dev", role: "editor" },
    });
    expect(res.statusCode).toBe(201);
    inviteToken = res.json().token;
    expect(res.json().email).toBe("b@test.dev");

    const list = await app.inject({
      method: "GET",
      url: `/workspaces/${wsId}/invitations`,
      headers: auth("tok-a"),
    });
    expect(list.json().invitations[0].status).toBe("pending");
  });

  it("rejects acceptance by the wrong email address", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/invitations/accept",
      headers: auth("tok-c"),
      payload: { token: inviteToken },
    });
    expect(res.statusCode).toBe(403);
    expect(res.json().error.code).toBe("email_mismatch");
  });

  it("B accepts; becomes a member; member list shows both profiles", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/invitations/accept",
      headers: auth("tok-b"),
      payload: { token: inviteToken },
    });
    expect(res.statusCode).toBe(200);
    expect(res.json().workspace.name).toBe("Alpha");
    expect(res.json().role).toBe("editor");

    const members = await app.inject({
      method: "GET",
      url: `/workspaces/${wsId}/members`,
      headers: auth("tok-b"),
    });
    const emails = members
      .json()
      .members.map((m: { email: string }) => m.email)
      .sort();
    expect(emails).toEqual(["a@test.dev", "b@test.dev"]);

    // B's workspace listing now includes Alpha (member-read policies).
    const me = await app.inject({ method: "GET", url: "/me", headers: auth("tok-b") });
    expect(me.json().workspaces.map((w: { name: string }) => w.name)).toContain("Alpha");
  });

  it("editors cannot invite (role enforcement)", async () => {
    const res = await app.inject({
      method: "POST",
      url: `/workspaces/${wsId}/invitations`,
      headers: auth("tok-b"),
      payload: { email: "c@test.dev", role: "viewer" },
    });
    expect(res.statusCode).toBe(403);
    expect(res.json().error.code).toBe("insufficient_role");
  });

  it("re-inviting an existing member conflicts", async () => {
    const res = await app.inject({
      method: "POST",
      url: `/workspaces/${wsId}/invitations`,
      headers: auth("tok-a"),
      payload: { email: "b@test.dev", role: "viewer" },
    });
    expect(res.statusCode).toBe(409);
  });

  it("revoked invitations cannot be accepted", async () => {
    const invite = await app.inject({
      method: "POST",
      url: `/workspaces/${wsId}/invitations`,
      headers: auth("tok-a"),
      payload: { email: "c@test.dev", role: "viewer" },
    });
    const { id, token } = invite.json();
    const revoke = await app.inject({
      method: "POST",
      url: `/workspaces/${wsId}/invitations/${id}/revoke`,
      headers: auth("tok-a"),
    });
    expect(revoke.statusCode).toBe(200);
    const accept = await app.inject({
      method: "POST",
      url: "/invitations/accept",
      headers: auth("tok-c"),
      payload: { token },
    });
    expect(accept.statusCode).toBe(410);
  });

  it("audit log records the lifecycle; readable by director+, not editors", async () => {
    const denied = await app.inject({
      method: "GET",
      url: `/workspaces/${wsId}/audit`,
      headers: auth("tok-b"),
    });
    expect(denied.statusCode).toBe(403);

    const res = await app.inject({
      method: "GET",
      url: `/workspaces/${wsId}/audit`,
      headers: auth("tok-a"),
    });
    expect(res.statusCode).toBe(200);
    const entries = res.json().entries;
    const tables = entries.map((e: { entity_table: string; action: string }) => e.entity_table);
    expect(tables).toContain("invitations");
    expect(tables).toContain("memberships");
    expect(tables).toContain("workspaces");
    // Actor attribution present on user-initiated actions.
    const membershipInsert = entries.find(
      (e: { entity_table: string; action: string }) =>
        e.entity_table === "memberships" && e.action === "insert",
    );
    expect(membershipInsert.actor_email).toBe("b@test.dev");
  });
});
