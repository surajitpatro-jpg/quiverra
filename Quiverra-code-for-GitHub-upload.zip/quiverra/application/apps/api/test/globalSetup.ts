import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";
import postgres from "postgres";

/**
 * API integration tests run against a real migrated database (same discipline
 * as packages/db — the RLS layer under test is the actual migration set).
 */
const ADMIN =
  process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/platform_api_test";

export default async function setup() {
  const url = new URL(ADMIN);
  const dbName = url.pathname.slice(1);
  const root = postgres(ADMIN.replace(`/${dbName}`, "/postgres"), { max: 1, prepare: false });
  await root.unsafe(`DROP DATABASE IF EXISTS ${dbName} WITH (FORCE)`);
  await root.unsafe(`CREATE DATABASE ${dbName}`);
  await root.end();

  const client = postgres(ADMIN, { max: 1, prepare: false });
  await client.unsafe(`CREATE EXTENSION IF NOT EXISTS pgcrypto`);
  await migrate(drizzle(client), {
    migrationsFolder: new URL("../../../packages/db/migrations", import.meta.url).pathname,
  });
  await client.end();
  console.log(`[globalSetup] migrated fresh database ${dbName}`);
}
