import type { Q, TenantDb } from "./db.js";

export const ROLES = ["owner", "director", "editor", "viewer"] as const;
export type Role = (typeof ROLES)[number];

const RANK: Record<Role, number> = { owner: 3, director: 2, editor: 1, viewer: 0 };

export function roleAtLeast(role: Role, minimum: Role): boolean {
  return RANK[role] >= RANK[minimum];
}

export async function membershipRole(
  db: TenantDb,
  userId: string,
  workspaceId: string,
): Promise<Role | null> {
  const rows = await db.service(
    (q: Q) =>
      q`SELECT role FROM memberships WHERE workspace_id = ${workspaceId} AND user_id = ${userId}`,
  );
  return (rows[0]?.role as Role | undefined) ?? null;
}

/** Idempotent profile provisioning on first authenticated contact. Service context. */
export async function ensureProfile(
  db: TenantDb,
  user: { id: string; email: string },
): Promise<void> {
  await db.service(
    (q: Q) => q`
      INSERT INTO auth.users (id, email) VALUES (${user.id}, ${user.email})
      ON CONFLICT (id) DO NOTHING`,
  );
  await db.service(
    (q: Q) => q`
      INSERT INTO profiles (id, email) VALUES (${user.id}, ${user.email})
      ON CONFLICT (id) DO NOTHING`,
  );
}
