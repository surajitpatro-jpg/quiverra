import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import type { AuthUser } from "./auth.js";
import type { TenantDb } from "./db.js";
import { ensureProfile, membershipRole, ROLES, roleAtLeast, type Role } from "./membership.js";

/** Shared request context attached by the auth preHandler. */
declare module "fastify" {
  interface FastifyRequest {
    user: AuthUser;
  }
}

export interface RouteDeps {
  db: TenantDb;
}

function fail(reply: FastifyReply, status: number, code: string, message: string) {
  return reply.status(status).send({ error: { code, message } });
}

async function requireMembership(
  req: FastifyRequest,
  reply: FastifyReply,
  db: TenantDb,
  workspaceId: string,
  minimum: Role,
): Promise<Role | null> {
  const role = await membershipRole(db, req.user.id, workspaceId);
  if (!role) {
    await fail(reply, 403, "not_member", "You are not a member of this workspace.");
    return null;
  }
  if (!roleAtLeast(role, minimum)) {
    await fail(reply, 403, "insufficient_role", `This action requires the '${minimum}' role.`);
    return null;
  }
  return role;
}

const createSchema = z.object({ name: z.string().trim().min(1).max(120) });
const inviteSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  role: z.enum(ROLES).default("viewer"),
});
const acceptSchema = z.object({ token: z.string().trim().min(16).max(128) });

/** W2 routes: workspaces, memberships, invitations, audit. */
export function registerWorkspaceRoutes(app: FastifyInstance, deps: RouteDeps): void {
  const { db } = deps;

  // ---- Current user -------------------------------------------------------
  app.get("/me", async (req) => {
    const workspaces = await db.asUser(
      req.user.id,
      (q) => q`
        SELECT w.id, w.name, m.role, w.created_at
        FROM memberships m JOIN workspaces w ON w.id = m.workspace_id
        ORDER BY w.created_at`,
    );
    return { user: req.user, workspaces };
  });

  // ---- Workspace creation (provisioning function, single door) ------------
  app.post("/workspaces", async (req, reply) => {
    const body = createSchema.safeParse(req.body);
    if (!body.success) return fail(reply, 422, "invalid_body", "A workspace name is required.");
    const wsId = await db.asUser(req.user.id, async (q) => {
      const [row] =
        await q`SELECT app.provision_workspace(${req.user.id}, ${body.data.name}) AS id`;
      if (!row) throw new Error("provisioning returned no id");
      return row.id as string;
    });
    return reply.status(201).send({ id: wsId, name: body.data.name, role: "owner" });
  });

  // ---- Members -------------------------------------------------------------
  app.get("/workspaces/:id/members", async (req, reply) => {
    const { id } = req.params as { id: string };
    const role = await requireMembership(req, reply, db, id, "viewer");
    if (!role) return;
    const members = await db.asMember(
      req.user.id,
      id,
      (q) => q`
        SELECT m.user_id, p.email, p.display_name, m.role, m.created_at
        FROM memberships m JOIN profiles p ON p.id = m.user_id
        WHERE m.workspace_id = ${id}
        ORDER BY m.created_at`,
    );
    return { members };
  });

  // ---- Invitations ----------------------------------------------------------
  app.get("/workspaces/:id/invitations", async (req, reply) => {
    const { id } = req.params as { id: string };
    const role = await requireMembership(req, reply, db, id, "director");
    if (!role) return;
    const invitations = await db.asMember(
      req.user.id,
      id,
      (q) => q`
        SELECT id, email, role, status, expires_at, created_at
        FROM invitations WHERE workspace_id = ${id}
        ORDER BY created_at DESC`,
    );
    return { invitations };
  });

  app.post("/workspaces/:id/invitations", async (req, reply) => {
    const { id } = req.params as { id: string };
    const role = await requireMembership(req, reply, db, id, "director");
    if (!role) return;
    const body = inviteSchema.safeParse(req.body);
    if (!body.success)
      return fail(reply, 422, "invalid_body", "A valid email and role are required.");
    // Inviting an existing member is a no-op conflict.
    const existing = await db.service(
      (q) => q`
        SELECT 1 FROM memberships m JOIN profiles p ON p.id = m.user_id
        WHERE m.workspace_id = ${id} AND lower(p.email) = ${body.data.email}`,
    );
    if (existing.length > 0)
      return fail(reply, 409, "already_member", "That user is already a member.");
    const token = randomBytes(24).toString("hex");
    const [inv] = await db.asMember(
      req.user.id,
      id,
      (q) => q`
        INSERT INTO invitations (workspace_id, email, role, token, invited_by, expires_at)
        VALUES (${id}, ${body.data.email}, ${body.data.role}, ${token}, ${req.user.id}, now() + interval '7 days')
        RETURNING id, email, role, expires_at`,
    );
    // NOTE: delivery is share-link for now; transactional email arrives with the
    // notifications milestone. The token is returned to the inviter only.
    if (!inv) throw new Error("invitation insert returned no row");
    return reply.status(201).send({ ...inv, token });
  });

  app.post("/workspaces/:id/invitations/:invitationId/revoke", async (req, reply) => {
    const { id, invitationId } = req.params as { id: string; invitationId: string };
    const role = await requireMembership(req, reply, db, id, "director");
    if (!role) return;
    const updated = await db.asMember(
      req.user.id,
      id,
      (q) => q`
        UPDATE invitations SET status = 'revoked'
        WHERE id = ${invitationId} AND workspace_id = ${id} AND status = 'pending'
        RETURNING id`,
    );
    if (updated.length === 0)
      return fail(reply, 404, "not_found", "No pending invitation with that id.");
    return { id: invitationId, status: "revoked" };
  });

  app.post("/invitations/accept", async (req, reply) => {
    const body = acceptSchema.safeParse(req.body);
    if (!body.success)
      return fail(reply, 422, "invalid_body", "A valid invitation token is required.");
    // Token lookup is privileged; every subsequent write runs under RLS as the invitee.
    const [inv] = await db.service(
      (q) => q`SELECT * FROM invitations WHERE token = ${body.data.token}`,
    );
    if (!inv) return fail(reply, 404, "not_found", "Invitation not found.");
    if (inv.status === "revoked")
      return fail(reply, 410, "revoked", "This invitation was revoked.");
    if (inv.status === "accepted")
      return fail(reply, 409, "already_accepted", "This invitation was already used.");
    if (new Date(inv.expires_at as string) < new Date())
      return fail(reply, 410, "expired", "This invitation has expired.");
    if ((inv.email as string).toLowerCase() !== req.user.email.toLowerCase())
      return fail(
        reply,
        403,
        "email_mismatch",
        "This invitation was issued to a different email address.",
      );

    const result = await db.asMember(req.user.id, inv.workspace_id as string, async (q) => {
      await q`
        INSERT INTO memberships (workspace_id, user_id, role)
        VALUES (${inv.workspace_id}, ${req.user.id}, ${inv.role})
        ON CONFLICT DO NOTHING`;
      await q`UPDATE invitations SET status = 'accepted' WHERE id = ${inv.id}`;
      const [ws] = await q`SELECT id, name FROM workspaces WHERE id = ${inv.workspace_id}`;
      if (!ws) throw new Error("workspace missing after invitation accept");
      return ws;
    });
    return { workspace: result, role: inv.role };
  });

  // ---- Audit log (read-only, director+) -------------------------------------
  app.get("/workspaces/:id/audit", async (req, reply) => {
    const { id } = req.params as { id: string };
    const role = await requireMembership(req, reply, db, id, "director");
    if (!role) return;
    const entries = await db.asMember(
      req.user.id,
      id,
      (q) => q`
        SELECT a.id, a.actor_id, p.email AS actor_email, a.action, a.entity_table,
               a.entity_id, a.before, a.after, a.created_at
        FROM audit_log a LEFT JOIN profiles p ON p.id = a.actor_id
        WHERE a.workspace_id = ${id}
        ORDER BY a.id DESC LIMIT 100`,
    );
    return { entries };
  });
}

export { ensureProfile };
