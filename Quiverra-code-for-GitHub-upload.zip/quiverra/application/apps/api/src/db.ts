import postgres from "postgres";

/**
 * Tenant-aware database access (Database-Architecture.md §8, Security.md §5).
 *
 * TRUST ANCHOR: the `service` context bypasses RLS and may be used ONLY to
 * establish identity and membership. All tenant data access runs through
 * `asUser` / `asMember`, which execute as the `authenticated` role with the
 * same JWT-claim GUCs RLS evaluates in production. Callers MUST verify
 * membership (via `service`) before entering `asMember` — the workspace claim
 * is authoritative only because the API validated it first.
 */
export type Q = postgres.Sql;

export class TenantDb {
  constructor(private readonly sql: postgres.Sql) {}

  static connect(url: string): TenantDb {
    return new TenantDb(postgres(url, { max: 10, prepare: false }));
  }

  async close(): Promise<void> {
    await this.sql.end();
  }

  /** Privileged context — identity/membership establishment and provisioning only. */
  service<T>(fn: (q: Q) => Promise<T>): Promise<T> {
    return fn(this.sql);
  }

  /** Authenticated, no workspace claim (e.g. workspace listing — member-read policies). */
  asUser<T>(userId: string, fn: (q: Q) => Promise<T>): Promise<T> {
    return this.claims(userId, null, fn);
  }

  /** Authenticated with a validated workspace claim. Membership MUST be verified first. */
  asMember<T>(userId: string, workspaceId: string, fn: (q: Q) => Promise<T>): Promise<T> {
    return this.claims(userId, workspaceId, fn);
  }

  private async claims<T>(
    userId: string,
    workspaceId: string | null,
    fn: (q: Q) => Promise<T>,
  ): Promise<T> {
    const claims = workspaceId ? { sub: userId, workspace_id: workspaceId } : { sub: userId };
    return this.sql.begin(async (tx) => {
      await tx.unsafe(`SET LOCAL ROLE authenticated`);
      await tx.unsafe(`SET LOCAL request.jwt.claims = '${JSON.stringify(claims)}'`);
      return fn(tx as unknown as Q);
    }) as Promise<T>;
  }
}
