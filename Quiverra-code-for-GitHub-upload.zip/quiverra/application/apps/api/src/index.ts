import { loadServerEnv } from "@platform/config";
import { buildServer } from "./server.js";

// Boot fails closed on invalid environment (packages/config — Security.md §2).
const env = loadServerEnv();
const app = buildServer(env);

const port = Number(process.env.PORT ?? 4000);
await app.listen({ port, host: "0.0.0.0" });
