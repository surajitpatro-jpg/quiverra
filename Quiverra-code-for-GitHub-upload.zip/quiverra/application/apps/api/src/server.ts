import Fastify from "fastify";
import cors from "@fastify/cors";
import type { ServerEnv } from "@platform/config";
import { supabaseVerifier, type VerifyToken } from "./auth.js";
import { TenantDb } from "./db.js";
import { ensureProfile } from "./membership.js";
import { registerWorkspaceRoutes } from "./routes.js";

/**
 * Modular monolith API (ADR-0011, ADR-0023).
 * W0: probes + env validation. W2: Supabase-authenticated workspace onboarding
 * with real RLS enforcement on every tenant query (see db.ts trust anchor).
 */
export interface BuildOptions {
  /** Injected for tests; defaults to the real Supabase verifier in production. */
  verifyToken?: VerifyToken;
  /** Injected for tests; defaults to a live TenantDb from DATABASE_URL. */
  db?: TenantDb;
}

export function buildServer(
  env: Pick<
    ServerEnv,
    | "APP_ENV"
    | "PAYMENTS_ENABLED"
    | "INTELLIGENCE_PAID_CEILING_INR"
    | "SUPABASE_URL"
    | "SUPABASE_SERVICE_ROLE_KEY"
    | "DATABASE_URL"
    | "APP_URL"
  >,
  opts: BuildOptions = {},
) {
  const app = Fastify({
    logger: { level: env.APP_ENV === "production" ? "info" : "debug" },
    trustProxy: true,
  });

  app.register(cors, { origin: env.APP_URL, credentials: true });

  const db = opts.db ?? TenantDb.connect(env.DATABASE_URL);
  const verify =
    opts.verifyToken ?? supabaseVerifier(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

  app.addHook("onClose", async () => {
    await db.close();
  });

  // ---- Probes ---------------------------------------------------------------
  app.get("/healthz", async () => ({ status: "ok" }));
  app.get("/version", async () => ({
    name: "quiverra-api",
    phase: "6-W2",
    env: env.APP_ENV,
    paymentsEnabled: env.PAYMENTS_ENABLED === "true",
    intelligencePaidCeilingInr: env.INTELLIGENCE_PAID_CEILING_INR,
  }));

  // ---- Authentication (all routes below) -------------------------------------
  const secured = app.register(async (scope) => {
    scope.addHook("preHandler", async (req, reply) => {
      const header = req.headers.authorization;
      if (!header?.startsWith("Bearer ")) {
        return reply
          .status(401)
          .send({ error: { code: "unauthenticated", message: "Bearer token required." } });
      }
      const user = await verify(header.slice("Bearer ".length).trim());
      if (!user) {
        return reply
          .status(401)
          .send({ error: { code: "unauthenticated", message: "Invalid or expired token." } });
      }
      req.user = user;
      // First-contact profile provisioning (FK target for workspaces.created_by).
      await ensureProfile(db, user);
    });
    registerWorkspaceRoutes(scope, { db });
  });
  void secured;

  return app;
}
