/**
 * Token verification (Security.md §2). Calls Supabase Auth's /auth/v1/user
 * endpoint directly with the SERVER-ONLY service-role key as apikey — no
 * realtime client, no session persistence, server-side only.
 * Tests inject a stub so route/RLS behaviour is exercised locally; the
 * verifier itself is validated against the real Supabase project (W2 gate).
 */
export interface AuthUser {
  id: string;
  email: string;
}

export type VerifyToken = (token: string) => Promise<AuthUser | null>;

export function supabaseVerifier(supabaseUrl: string, serviceRoleKey: string): VerifyToken {
  const endpoint = `${supabaseUrl.replace(/\/$/, "")}/auth/v1/user`;
  return async (token) => {
    try {
      const res = await fetch(endpoint, {
        headers: { authorization: `Bearer ${token}`, apikey: serviceRoleKey },
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) return null;
      const data = (await res.json()) as { id?: string; email?: string };
      if (!data.id || !data.email) return null;
      return { id: data.id, email: data.email };
    } catch {
      return null; // network/timeout → treat as unauthenticated, never throw open
    }
  };
}
