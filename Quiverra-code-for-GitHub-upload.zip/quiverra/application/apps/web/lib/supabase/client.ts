import { createBrowserClient } from "@supabase/ssr";

/**
 * Browser Supabase client — public anon key ONLY (Security.md §2).
 * The service-role key never exists in this process.
 */
export function supabaseBrowser() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL ?? "http://localhost:54321",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "build-time-placeholder",
  );
}
