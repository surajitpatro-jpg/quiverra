import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Quiverra",
  description:
    "Quiverra — the AI Creative Production Operating System. Brief to finished production, with plan-before-pay and capability honesty.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
