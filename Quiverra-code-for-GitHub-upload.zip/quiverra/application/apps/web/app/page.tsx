import Link from "next/link";

export default function Home() {
  return (
    <main className="shell">
      <h1>Quiverra</h1>
      <p className="muted">
        The AI Creative Production Operating System — brief to finished production, with
        plan-before-pay, capability honesty, and privacy as the default.
      </p>
      <div className="card">
        <p>
          <Link href="/login">Sign in</Link> or <Link href="/signup">create an account</Link> to
          open your workspaces.
        </p>
      </div>
      <p className="muted small">
        Privacy is the default · No silent paid spend (₹0 ceiling) · Payments dormant
      </p>
    </main>
  );
}
