"use client";

import { useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "../../../lib/supabase/client";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error } = await supabaseBrowser().auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/auth/callback` },
    });
    setBusy(false);
    if (error) {
      setError(error.message);
      return;
    }
    setDone(true);
  }

  if (done) {
    return (
      <main className="shell">
        <h1>Verify your email</h1>
        <div className="card">
          <p>
            We sent a verification link to <strong>{email}</strong>. Open it to activate your
            account, then sign in.
          </p>
          <p className="muted">
            Nothing to do here — this step proves ownership of the address (W2 requirement).
          </p>
        </div>
        <p className="muted">
          <Link href="/login">Back to sign in</Link>
        </p>
      </main>
    );
  }

  return (
    <main className="shell">
      <h1>Create account</h1>
      <form onSubmit={onSubmit} className="card form">
        <label>
          Email
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>
          Password (min 8 characters)
          <input
            type="password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        {error ? <p className="error">{error}</p> : null}
        <button type="submit" disabled={busy}>
          {busy ? "Creating…" : "Create account"}
        </button>
      </form>
      <p className="muted">
        <Link href="/login">Already have an account?</Link>
      </p>
    </main>
  );
}
