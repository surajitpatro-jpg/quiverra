"use client";

import { useState } from "react";
import Link from "next/link";
import { supabaseBrowser } from "../../../lib/supabase/client";

export default function RecoverPage() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await supabaseBrowser().auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/callback?next=/reset`,
    });
    if (error) {
      setError(error.message);
      return;
    }
    setDone(true);
  }

  return (
    <main className="shell">
      <h1>Reset password</h1>
      {done ? (
        <div className="card">
          <p>
            If an account exists for <strong>{email}</strong>, a recovery link is on its way.
          </p>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="card form">
          <label>
            Email
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          {error ? <p className="error">{error}</p> : null}
          <button type="submit">Send recovery link</button>
        </form>
      )}
      <p className="muted">
        <Link href="/login">Back to sign in</Link>
      </p>
    </main>
  );
}
