"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "../../../lib/api";

/** Accept an invitation by share link: /invitations?token=… */
function AcceptInvitation() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [status, setStatus] = useState<"idle" | "working" | "done" | "error">("idle");
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const token = searchParams.get("token");
    if (!token) return;
    setStatus("working");
    api<{ workspace: { id: string; name: string }; role: string }>("/invitations/accept", {
      method: "POST",
      body: JSON.stringify({ token }),
    })
      .then((res) => {
        setStatus("done");
        setMessage(`You joined “${res.workspace.name}” as ${res.role}.`);
        setTimeout(() => router.push(`/workspaces/${res.workspace.id}`), 1200);
      })
      .catch((e) => {
        setStatus("error");
        setMessage(e instanceof Error ? e.message : "Could not accept invitation");
      });
  }, [searchParams, router]);

  return (
    <>
      <h1>Invitations</h1>
      {status === "idle" ? (
        <p className="muted">Open an invitation link to accept it here.</p>
      ) : status === "working" ? (
        <p className="muted">Accepting your invitation…</p>
      ) : (
        <div className="card">
          <p className={status === "error" ? "error" : "notice"}>{message}</p>
        </div>
      )}
    </>
  );
}

export default function InvitationsPage() {
  return (
    <Suspense
      fallback={
        <>
          <h1>Invitations</h1>
          <p className="muted">Loading…</p>
        </>
      }
    >
      <AcceptInvitation />
    </Suspense>
  );
}
