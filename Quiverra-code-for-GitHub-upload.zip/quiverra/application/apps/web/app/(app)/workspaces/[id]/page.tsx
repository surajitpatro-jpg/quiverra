"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "../../../../lib/api";

interface Member {
  user_id: string;
  email: string;
  display_name: string | null;
  role: string;
}
interface Invitation {
  id: string;
  email: string;
  role: string;
  status: string;
  expires_at: string;
}
interface AuditEntry {
  id: number;
  actor_email: string | null;
  action: string;
  entity_table: string;
  created_at: string;
}

export default function WorkspacePage({ params }: { params: Promise<{ id: string }> }) {
  const [wsId, setWsId] = useState<string | null>(null);
  const [members, setMembers] = useState<Member[] | null>(null);
  const [invitations, setInvitations] = useState<Invitation[] | null>(null);
  const [audit, setAudit] = useState<AuditEntry[] | null>(null);
  const [canManage, setCanManage] = useState(false);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("viewer");
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    params.then((p) => setWsId(p.id));
  }, [params]);

  const load = useCallback(async (id: string) => {
    try {
      const m = await api<{ members: Member[] }>(`/workspaces/${id}/members`);
      setMembers(m.members);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load members");
    }
    try {
      const inv = await api<{ invitations: Invitation[] }>(`/workspaces/${id}/invitations`);
      setInvitations(inv.invitations);
      const a = await api<{ entries: AuditEntry[] }>(`/workspaces/${id}/audit`);
      setAudit(a.entries);
      setCanManage(true);
    } catch {
      // viewer/editor — management endpoints are director+; hide those panels.
      setCanManage(false);
    }
  }, []);

  useEffect(() => {
    if (wsId) void load(wsId);
  }, [wsId, load]);

  async function invite(e: React.FormEvent) {
    e.preventDefault();
    if (!wsId) return;
    setNotice(null);
    setError(null);
    try {
      const inv = await api<{ token: string }>(`/workspaces/${wsId}/invitations`, {
        method: "POST",
        body: JSON.stringify({ email, role }),
      });
      setNotice(
        `Invitation created. Share this link: ${window.location.origin}/invitations?token=${inv.token}`,
      );
      setEmail("");
      await load(wsId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to invite");
    }
  }

  async function revoke(invitationId: string) {
    if (!wsId) return;
    await api(`/workspaces/${wsId}/invitations/${invitationId}/revoke`, { method: "POST" });
    await load(wsId);
  }

  return (
    <>
      <h1>Workspace</h1>
      <p className="muted mono">{wsId}</p>
      {error ? <p className="error">{error}</p> : null}
      {notice ? <p className="notice">{notice}</p> : null}

      <section className="card">
        <h2>Members</h2>
        {members === null ? (
          <p className="muted">Loading…</p>
        ) : (
          <ul className="list">
            {members.map((m) => (
              <li key={m.user_id}>
                <span>{m.display_name ?? m.email}</span>
                <span className="badge">{m.role}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {canManage ? (
        <>
          <section className="card">
            <h2>Invite a member</h2>
            <form onSubmit={invite} className="form inline-form">
              <input
                type="email"
                placeholder="teammate@example.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <select value={role} onChange={(e) => setRole(e.target.value)}>
                <option value="viewer">viewer</option>
                <option value="editor">editor</option>
                <option value="director">director</option>
                <option value="owner">owner</option>
              </select>
              <button type="submit">Invite</button>
            </form>
            {invitations && invitations.length > 0 ? (
              <ul className="list">
                {invitations.map((i) => (
                  <li key={i.id}>
                    <span>
                      {i.email} <span className="badge">{i.role}</span>{" "}
                      <span className="muted">{i.status}</span>
                    </span>
                    {i.status === "pending" ? (
                      <button className="link-btn" onClick={() => revoke(i.id)}>
                        Revoke
                      </button>
                    ) : null}
                  </li>
                ))}
              </ul>
            ) : null}
          </section>

          <section className="card">
            <h2>Audit log</h2>
            {audit === null ? (
              <p className="muted">Loading…</p>
            ) : audit.length === 0 ? (
              <p className="muted">No activity yet.</p>
            ) : (
              <table className="table">
                <thead>
                  <tr>
                    <th>When</th>
                    <th>Actor</th>
                    <th>Action</th>
                    <th>Entity</th>
                  </tr>
                </thead>
                <tbody>
                  {audit.map((a) => (
                    <tr key={a.id}>
                      <td>{new Date(a.created_at).toLocaleString()}</td>
                      <td>{a.actor_email ?? "system"}</td>
                      <td>{a.action}</td>
                      <td>{a.entity_table}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        </>
      ) : null}
    </>
  );
}
