"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "../../../lib/api";

interface Workspace {
  id: string;
  name: string;
  role: string;
  created_at: string;
}

export default function WorkspacesPage() {
  const router = useRouter();
  const [workspaces, setWorkspaces] = useState<Workspace[] | null>(null);
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<{ workspaces: Workspace[] }>("/me")
      .then((res) => setWorkspaces(res.workspaces))
      .catch((e) => setError(e.message));
  }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const ws = await api<{ id: string }>("/workspaces", {
        method: "POST",
        body: JSON.stringify({ name }),
      });
      router.push(`/workspaces/${ws.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create workspace");
      setBusy(false);
    }
  }

  return (
    <>
      <h1>Workspaces</h1>
      <p className="muted">
        Every workspace is private by default, isolated at the database level (RLS), and
        confidential unless you change it (ADR-0020).
      </p>

      <form onSubmit={create} className="card form inline-form">
        <input
          placeholder="New workspace name"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button type="submit" disabled={busy}>
          {busy ? "Creating…" : "Create workspace"}
        </button>
      </form>
      {error ? <p className="error">{error}</p> : null}

      {workspaces === null ? (
        <p className="muted">Loading…</p>
      ) : workspaces.length === 0 ? (
        <p className="muted">No workspaces yet — create your first above.</p>
      ) : (
        <ul className="list">
          {workspaces.map((ws) => (
            <li key={ws.id}>
              <Link href={`/workspaces/${ws.id}`}>
                <strong>{ws.name}</strong>
              </Link>
              <span className="badge">{ws.role}</span>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
