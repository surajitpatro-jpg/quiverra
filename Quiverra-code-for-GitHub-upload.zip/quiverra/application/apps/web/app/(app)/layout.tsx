"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { supabaseBrowser } from "../../lib/supabase/client";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();

  async function signOut() {
    await supabaseBrowser().auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <>
      <header className="topbar">
        <Link href="/workspaces" className="brand">
          Quiverra
        </Link>
        <nav>
          <Link href="/invitations">Invitations</Link>
          <button onClick={signOut} className="link-btn">
            Sign out
          </button>
        </nav>
      </header>
      <main className="shell-wide">{children}</main>
    </>
  );
}
