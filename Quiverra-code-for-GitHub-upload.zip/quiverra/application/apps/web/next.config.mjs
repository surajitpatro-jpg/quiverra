/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Server-only env stays server-side; the browser bundle receives NEXT_PUBLIC_* only.
  poweredByHeader: false,
};

export default nextConfig;
