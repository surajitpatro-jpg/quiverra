import { z } from "zod";

/**
 * Environment validation (Security.md §2, ADR-0017/0018/0019).
 * Every process validates its environment at boot and refuses to start on
 * invalid config — fail-closed, matching the platform's error philosophy.
 *
 * Rules encoded here:
 * - Secrets are server-side only; the web app must use envPublic (never the full schema).
 * - PAYMENTS_ENABLED defaults false and may only be true when APP_ENV is not
 *   development AND a deliberate operator flag is set (ADR-0019).
 * - INTELLIGENCE_PAID_CEILING_INR defaults 0 (ADR-0018).
 */

const serverSchema = z.object({
  APP_ENV: z.enum(["development", "staging", "production", "test"]),
  DATABASE_URL: z.string().url().or(z.string().startsWith("postgres")),
  // Deferred infrastructure — optional until its milestone (ADR-0017):
  // REDIS_URL → W5 quota windows; R2_* → W6 asset storage.
  REDIS_URL: z.string().startsWith("redis").optional(),
  R2_ACCOUNT_ID: z.string().min(1).optional(),
  R2_ACCESS_KEY_ID: z.string().min(1).optional(),
  R2_SECRET_ACCESS_KEY: z.string().min(1).optional(),
  R2_BUCKET: z.string().min(1).optional(),
  R2_ENDPOINT: z.string().url().optional(),
  // W2: Supabase auth. The service-role key is SERVER-ONLY — never ship to the browser.
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  APP_URL: z.string().url().default("http://localhost:3000"),
  GEMINI_API_KEY: z.string().min(1).optional(),
  GROQ_API_KEY: z.string().min(1).optional(),
  FAL_KEY: z.string().min(1).optional(),
  // Deferred providers (ADR-0017) — optional by design; absence is valid.
  REPLICATE_API_TOKEN: z.string().min(1).optional(),
  ELEVENLABS_API_KEY: z.string().min(1).optional(),
  ELEVENLABS_OPTOUT_VERIFIED: z
    .enum(["true", "false"])
    .default("false")
    .describe("Hard gate: ElevenLabs client refuses to build unless 'true' (ADR-0017/F-0045)"),
  INTELLIGENCE_PAID_CEILING_INR: z.coerce.number().int().min(0).default(0),
  PAYMENTS_ENABLED: z.enum(["true", "false"]).default("false"),
});

const publicSchema = z.object({
  NEXT_PUBLIC_APP_ENV: z.enum(["development", "staging", "production", "test"]),
  NEXT_PUBLIC_SUPABASE_URL: z.string().url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  NEXT_PUBLIC_API_URL: z.string().url().default("http://localhost:4000"),
});

export type ServerEnv = z.infer<typeof serverSchema>;
export type PublicEnv = z.infer<typeof publicSchema>;

function formatIssues(issues: z.ZodIssue[]): string {
  return issues.map((i) => `  - ${i.path.join(".")}: ${i.message}`).join("\n");
}

/** Validate the full server environment. Throws with a readable message on failure. */
export function loadServerEnv(source: NodeJS.ProcessEnv = process.env): ServerEnv {
  const parsed = serverSchema.safeParse(source);
  if (!parsed.success) {
    throw new Error(`Invalid server environment:\n${formatIssues(parsed.error.issues)}`);
  }
  if (parsed.data.PAYMENTS_ENABLED === "true" && parsed.data.APP_ENV === "development") {
    throw new Error("PAYMENTS_ENABLED=true is not allowed in development (ADR-0019).");
  }
  return parsed.data;
}

/** Validate the public (browser-safe) environment. Only non-secret values. */
export function loadPublicEnv(source: NodeJS.ProcessEnv = process.env): PublicEnv {
  const parsed = publicSchema.safeParse(source);
  if (!parsed.success) {
    throw new Error(`Invalid public environment:\n${formatIssues(parsed.error.issues)}`);
  }
  return parsed.data;
}
