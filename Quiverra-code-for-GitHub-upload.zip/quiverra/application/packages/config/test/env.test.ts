import { describe, expect, it } from "vitest";
import { loadServerEnv } from "../src/index.js";

const base = {
  APP_ENV: "test",
  DATABASE_URL: "postgres://postgres:postgres@localhost:5432/platform_test",
  SUPABASE_URL: "https://example.supabase.co",
  SUPABASE_SERVICE_ROLE_KEY: "x",
};

describe("loadServerEnv", () => {
  it("defaults paid-LLM ceiling to 0 and payments to false (ADR-0018/0019)", () => {
    const env = loadServerEnv(base);
    expect(env.INTELLIGENCE_PAID_CEILING_INR).toBe(0);
    expect(env.PAYMENTS_ENABLED).toBe("false");
    expect(env.ELEVENLABS_OPTOUT_VERIFIED).toBe("false");
  });

  it("rejects payments in development", () => {
    expect(() =>
      loadServerEnv({ ...base, APP_ENV: "development", PAYMENTS_ENABLED: "true" }),
    ).toThrow(/ADR-0019/);
  });

  it("fails closed on missing required secrets", () => {
    const { SUPABASE_SERVICE_ROLE_KEY, ...incomplete } = base;
    void SUPABASE_SERVICE_ROLE_KEY;
    expect(() => loadServerEnv(incomplete)).toThrow(/SUPABASE_SERVICE_ROLE_KEY/);
    const { DATABASE_URL, ...noDb } = base;
    void DATABASE_URL;
    expect(() => loadServerEnv(noDb)).toThrow(/DATABASE_URL/);
  });

  it("deferred infrastructure is optional until its milestone (ADR-0017)", () => {
    const env = loadServerEnv(base);
    expect(env.REDIS_URL).toBeUndefined();
    expect(env.R2_SECRET_ACCESS_KEY).toBeUndefined();
  });
});
