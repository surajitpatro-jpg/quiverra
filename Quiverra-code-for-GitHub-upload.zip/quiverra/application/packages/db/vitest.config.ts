import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    globalSetup: ["./test/globalSetup.ts"],
    // DB tests share one database and mutate ledger state in a deliberate order —
    // run files sequentially.
    fileParallelism: false,
    testTimeout: 30_000,
  },
});
