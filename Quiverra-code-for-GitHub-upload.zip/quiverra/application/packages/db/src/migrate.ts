import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";
import postgres from "postgres";

/**
 * Forward-only migration runner (Database-Architecture.md §9).
 * Usage: DATABASE_URL=... npm run db:migrate --workspace packages/db
 */
const url = process.env.DATABASE_URL;
if (!url) {
  throw new Error("DATABASE_URL is required");
}

const client = postgres(url, { max: 1 });
const db = drizzle(client);

await migrate(db, { migrationsFolder: new URL("../migrations", import.meta.url).pathname });
await client.end();
console.log("migrations applied");
