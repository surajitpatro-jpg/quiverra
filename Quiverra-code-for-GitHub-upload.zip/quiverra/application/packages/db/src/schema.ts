import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  check,
  customType,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  unique,
  uuid,
} from "drizzle-orm/pg-core";

/** bytea column (drizzle-orm 0.36 has no built-in bytea helper). */
const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

/**
 * W1 — Database foundation schema (Database-Architecture.md v2, Credit-Ledger.md §4,
 * Asset-Storage.md §2). Custom SQL (RLS, triggers, functions, views, grants) lives in
 * migrations/0001_policies_and_functions.sql — Drizzle tracks tables/enums/indexes here.
 */

// ---------- Enums ----------
export const workspaceRole = pgEnum("workspace_role", ["owner", "director", "editor", "viewer"]);
export const spendPolicy = pgEnum("spend_policy", [
  "free_only",
  "free_preferred",
  "paid_authorised",
]);
export const projectStage = pgEnum("project_stage", [
  "brief",
  "concepts",
  "visual_direction",
  "characters",
  "script",
  "storyboard",
  "shot_planning",
  "image_generation",
  "video_generation",
  "complete",
]);
export const assetClass = pgEnum("asset_class", [
  "upload",
  "reference",
  "frame",
  "video",
  "audio",
  "composite",
  "export",
]);
export const assetStatus = pgEnum("asset_status", ["active", "quarantined", "deleted"]);
export const currencyDomain = pgEnum("currency_domain", ["CREDIT", "USD_MICRO"]);
export const postingDirection = pgEnum("posting_direction", ["debit", "credit"]);
export const ledgerTxKind = pgEnum("ledger_tx_kind", [
  "issuance",
  "purchase",
  "reservation",
  "release",
  "settlement",
  "recognition",
  "goodwill",
  "expiry",
  "breakage",
  "provider_prepay",
  "provider_cost",
  "refund_cash",
  "adjustment",
]);

export const invitationStatus = pgEnum("invitation_status", [
  "pending",
  "accepted",
  "revoked",
  "expired",
]);

// ---------- Identity & tenancy ----------
export const profiles = pgTable("profiles", {
  id: uuid("id").primaryKey(), // = auth.users.id (Supabase); stub provided locally
  email: text("email").notNull(),
  displayName: text("display_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workspaces = pgTable("workspaces", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  // ADR-0020: confidential is ON by default — privacy is the default posture.
  confidential: boolean("confidential").notNull().default(true),
  spendPolicy: spendPolicy("spend_policy").notNull().default("free_only"),
  // Hard cap enforced at reservation time (ADR-0014). NULL = no cap while payments dormant.
  monthlyCapCredits: bigint("monthly_cap_credits", { mode: "bigint" }),
  createdBy: uuid("created_by")
    .notNull()
    .references(() => profiles.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const memberships = pgTable(
  "memberships",
  {
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    role: workspaceRole("role").notNull().default("editor"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("memberships_pk").on(t.workspaceId, t.userId)],
);

// ---------- Invitations (W2) ----------
// One pending invite per (workspace, email) — partial unique index in 0003 custom SQL.
export const invitations = pgTable(
  "invitations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    email: text("email").notNull(),
    role: workspaceRole("role").notNull().default("viewer"),
    token: text("token").notNull().unique(), // random, single-use, expires
    invitedBy: uuid("invited_by")
      .notNull()
      .references(() => profiles.id),
    status: invitationStatus("status").notNull().default("pending"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("invitations_workspace_idx").on(t.workspaceId)],
);

// ---------- Creative spine ----------
export const projects = pgTable(
  "projects",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    stage: projectStage("stage").notNull().default("brief"),
    createdBy: uuid("created_by")
      .notNull()
      .references(() => profiles.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("projects_ws_created").on(t.workspaceId, t.createdAt.desc())],
);

export const creativeBriefs = pgTable(
  "creative_briefs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    version: integer("version").notNull(),
    text: text("text").notNull(),
    attachments: jsonb("attachments").notNull().default([]),
    constraints: jsonb("constraints").notNull().default({}),
    createdBy: uuid("created_by")
      .notNull()
      .references(() => profiles.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("briefs_project_version").on(t.projectId, t.version)],
);

// ---------- Assets (Asset-Storage.md §2: workspace-scoped, no cross-tenant dedup) ----------
export const assets = pgTable(
  "assets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    contentHash: bytea("content_hash").notNull(),
    assetClass: assetClass("asset_class").notNull(),
    r2Key: text("r2_key").notNull().unique(),
    bytes: bigint("bytes", { mode: "bigint" }).notNull(),
    mime: text("mime").notNull(),
    status: assetStatus("status").notNull().default("quarantined"), // ClamAV gate (ADR-0013)
    createdBy: uuid("created_by")
      .notNull()
      .references(() => profiles.id),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    // Dedup scope = workspace only (ADR-0013). Cross-tenant sharing is structurally impossible.
    unique("assets_ws_hash_class").on(t.workspaceId, t.contentHash, t.assetClass),
    index("assets_ws_class").on(t.workspaceId, t.assetClass),
    check(
      "assets_r2_key_workspace_prefixed",
      sql`${t.r2Key} LIKE ('ws_' || ${t.workspaceId}::text || '/%')`,
    ),
  ],
);

// ---------- Credit ledger (Credit-Ledger.md §4 — double-entry, balanced, append-only) ----------
export const ledgerAccounts = pgTable("ledger_accounts", {
  code: text("code").primaryKey(),
  type: text("type", {
    enum: ["asset", "liability", "revenue", "expense", "equity"],
  }).notNull(),
  normalBalance: postingDirection("normal_balance").notNull(),
  domain: currencyDomain("domain").notNull(),
  workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const ledgerTransactions = pgTable(
  "ledger_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    linkGroup: uuid("link_group"),
    domain: currencyDomain("domain").notNull(),
    kind: ledgerTxKind("kind").notNull(),
    workspaceId: uuid("workspace_id").references(() => workspaces.id),
    jobId: uuid("job_id"), // FK added when jobs table lands (W7)
    idempotencyKey: text("idempotency_key").notNull().unique(),
    usdBasisMicroPerCredit: bigint("usd_basis_micro_per_credit", { mode: "bigint" }),
    reason: text("reason"),
    operatorId: uuid("operator_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("ledger_tx_ws_created").on(t.workspaceId, t.createdAt.desc()),
    check(
      "ledger_adjustment_requires_reason_operator",
      sql`${t.kind} <> 'adjustment' OR (${t.reason} IS NOT NULL AND ${t.operatorId} IS NOT NULL)`,
    ),
  ],
);

export const ledgerPostings = pgTable(
  "ledger_postings",
  {
    id: bigint("id", { mode: "bigint" }).primaryKey().generatedAlwaysAsIdentity(),
    transactionId: uuid("transaction_id")
      .notNull()
      .references(() => ledgerTransactions.id),
    accountCode: text("account_code")
      .notNull()
      .references(() => ledgerAccounts.code),
    direction: postingDirection("direction").notNull(),
    amount: bigint("amount", { mode: "bigint" }).notNull(),
  },
  (t) => [
    index("postings_account").on(t.accountCode),
    check("postings_amount_positive", sql`${t.amount} > 0`),
  ],
);

// ---------- Audit log (W1 requirement) ----------
export const auditLog = pgTable(
  "audit_log",
  {
    id: bigint("id", { mode: "bigint" }).primaryKey().generatedAlwaysAsIdentity(),
    workspaceId: uuid("workspace_id"),
    actorId: uuid("actor_id"),
    action: text("action").notNull(), // insert | update | delete
    entityTable: text("entity_table").notNull(),
    entityId: text("entity_id"),
    before: jsonb("before"),
    after: jsonb("after"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("audit_ws_created").on(t.workspaceId, t.createdAt.desc())],
);
