-- 0008_grants_memberships_insert.sql
-- W2 fix: invitation acceptance inserts a membership row under the invitee's
-- validated claim. INSERT on memberships follows the same trust model as
-- projects (0001): the row must satisfy WITH CHECK (workspace_id = claim), and
-- the claim is only set by the API after privileged verification. No
-- UPDATE/DELETE grant — role changes and removals stay service-side flows.
GRANT INSERT ON memberships TO authenticated;
