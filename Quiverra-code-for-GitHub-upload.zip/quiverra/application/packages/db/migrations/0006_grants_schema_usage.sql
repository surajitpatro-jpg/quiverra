-- 0006_grants_schema_usage.sql
-- W2 fix: EXECUTE on a function is not enough — the role also needs USAGE on
-- the containing schema, or calls fail with "permission denied for schema app".
-- Found by the first API-level test under the real `authenticated` role
-- (packages/db tests had only exercised these doors as superuser).
GRANT USAGE ON SCHEMA app TO authenticated;
--> statement-breakpoint
GRANT USAGE ON SCHEMA ledger TO authenticated;
