-- 0001_policies_and_functions.sql
-- Custom SQL on top of the Drizzle-generated tables (Database-Architecture.md §8/§9,
-- Credit-Ledger.md §4–§5, Security.md). Hand-written by design: RLS, functions,
-- triggers, views and grants are migration-managed SQL, never ORM push mode.
--
-- ============================================================================
-- 0. Local-dev stub for Supabase's auth.users (no-op on Supabase, where it exists)
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS auth;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS auth.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text
);
--> statement-breakpoint
ALTER TABLE profiles
  ADD CONSTRAINT profiles_id_auth_users_fk
  FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;
--> statement-breakpoint

-- ============================================================================
-- 1. Roles (Supabase provides `authenticated`; created here for local parity)
-- ============================================================================
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    CREATE ROLE authenticated NOLOGIN;
  END IF;
END $$;
--> statement-breakpoint

-- ============================================================================
-- 2. Tenant context: current_workspace() from the JWT claim (set per request)
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS app;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION app.current_workspace() RETURNS uuid AS $$
  SELECT NULLIF(
    current_setting('request.jwt.claims', true)::jsonb ->> 'workspace_id', ''
  )::uuid;
$$ LANGUAGE sql STABLE;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION app.current_user() RETURNS uuid AS $$
  SELECT NULLIF(
    current_setting('request.jwt.claims', true)::jsonb ->> 'sub', ''
  )::uuid;
$$ LANGUAGE sql STABLE;
--> statement-breakpoint

-- ============================================================================
-- 3. RLS — tenant isolation on every tenant table (FORCE applies to owner too)
-- ============================================================================
ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE workspaces FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation ON workspaces
  USING (id = app.current_workspace())
  WITH CHECK (id = app.current_workspace());
--> statement-breakpoint

ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE memberships FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation ON memberships
  USING (workspace_id = app.current_workspace())
  WITH CHECK (workspace_id = app.current_workspace());
--> statement-breakpoint

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE projects FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation ON projects
  USING (workspace_id = app.current_workspace())
  WITH CHECK (workspace_id = app.current_workspace());
--> statement-breakpoint

ALTER TABLE creative_briefs ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE creative_briefs FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation ON creative_briefs
  USING (workspace_id = app.current_workspace())
  WITH CHECK (workspace_id = app.current_workspace());
--> statement-breakpoint

ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE assets FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation ON assets
  USING (workspace_id = app.current_workspace())
  WITH CHECK (workspace_id = app.current_workspace());
--> statement-breakpoint

ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE audit_log FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation_select ON audit_log
  FOR SELECT USING (workspace_id = app.current_workspace());
--> statement-breakpoint

-- Profiles: a user sees only their own row (not workspace-scoped).
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE profiles FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY own_profile ON profiles
  USING (id = app.current_user())
  WITH CHECK (id = app.current_user());
--> statement-breakpoint

-- Ledger: SELECT own transactions only; NO insert/update/delete policies.
-- All writes flow through ledger.post() (SECURITY DEFINER) — one door (Credit-Ledger §5).
ALTER TABLE ledger_transactions ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE ledger_transactions FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY ledger_read_own ON ledger_transactions
  FOR SELECT USING (workspace_id = app.current_workspace());
--> statement-breakpoint
ALTER TABLE ledger_postings ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE ledger_postings FORCE ROW LEVEL SECURITY;  -- no policies: deny all direct access
--> statement-breakpoint
ALTER TABLE ledger_accounts ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE ledger_accounts FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY ledger_accounts_read ON ledger_accounts
  FOR SELECT USING (workspace_id IS NULL OR workspace_id = app.current_workspace());
--> statement-breakpoint

-- ============================================================================
-- 4. Grants to the application role
-- ============================================================================
GRANT SELECT, UPDATE ON workspaces TO authenticated;
--> statement-breakpoint
GRANT SELECT ON memberships TO authenticated;
--> statement-breakpoint
GRANT SELECT, INSERT, UPDATE, DELETE ON projects, creative_briefs TO authenticated;
--> statement-breakpoint
GRANT SELECT, INSERT, UPDATE ON assets TO authenticated;  -- delete via service (ref-count rule)
--> statement-breakpoint
GRANT SELECT ON audit_log TO authenticated;
--> statement-breakpoint
GRANT SELECT, UPDATE ON profiles TO authenticated;
--> statement-breakpoint
GRANT SELECT ON ledger_transactions TO authenticated;
--> statement-breakpoint
GRANT SELECT ON ledger_accounts TO authenticated;
--> statement-breakpoint

-- ============================================================================
-- 5. Audit logging (W1 requirement) — generic trigger on sensitive tables
-- (ledger_postings: intentionally no grant — deny all direct access)
-- ============================================================================
CREATE OR REPLACE FUNCTION app.audit_trigger() RETURNS trigger AS $$
DECLARE
  ws uuid;
  actor uuid;
  ent text;
BEGIN
  actor := app.current_user();
  IF TG_OP = 'DELETE' THEN
    IF TG_TABLE_NAME = 'workspaces' THEN ws := OLD.id;
    ELSE ws := (to_jsonb(OLD) ->> 'workspace_id')::uuid; END IF;
    ent := COALESCE(to_jsonb(OLD) ->> 'id', to_jsonb(OLD) ->> 'workspace_id');
    INSERT INTO audit_log (workspace_id, actor_id, action, entity_table, entity_id, before)
    VALUES (ws, actor, 'delete', TG_TABLE_NAME, ent, to_jsonb(OLD));
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    IF TG_TABLE_NAME = 'workspaces' THEN ws := NEW.id;
    ELSE ws := (to_jsonb(NEW) ->> 'workspace_id')::uuid; END IF;
    ent := COALESCE(to_jsonb(NEW) ->> 'id', to_jsonb(NEW) ->> 'workspace_id');
    INSERT INTO audit_log (workspace_id, actor_id, action, entity_table, entity_id, before, after)
    VALUES (ws, actor, 'update', TG_TABLE_NAME, ent, to_jsonb(OLD), to_jsonb(NEW));
    RETURN NEW;
  ELSE
    IF TG_TABLE_NAME = 'workspaces' THEN ws := NEW.id;
    ELSE ws := (to_jsonb(NEW) ->> 'workspace_id')::uuid; END IF;
    ent := COALESCE(to_jsonb(NEW) ->> 'id', to_jsonb(NEW) ->> 'workspace_id');
    INSERT INTO audit_log (workspace_id, actor_id, action, entity_table, entity_id, after)
    VALUES (ws, actor, 'insert', TG_TABLE_NAME, ent, to_jsonb(NEW));
    RETURN NEW;
  END IF;
END $$ LANGUAGE plpgsql SECURITY DEFINER;
--> statement-breakpoint
CREATE TRIGGER audit_workspaces AFTER INSERT OR UPDATE OR DELETE ON workspaces
  FOR EACH ROW EXECUTE FUNCTION app.audit_trigger();
--> statement-breakpoint
CREATE TRIGGER audit_memberships AFTER INSERT OR UPDATE OR DELETE ON memberships
  FOR EACH ROW EXECUTE FUNCTION app.audit_trigger();
--> statement-breakpoint
CREATE TRIGGER audit_projects AFTER INSERT OR UPDATE OR DELETE ON projects
  FOR EACH ROW EXECUTE FUNCTION app.audit_trigger();
--> statement-breakpoint
CREATE TRIGGER audit_assets AFTER INSERT OR UPDATE OR DELETE ON assets
  FOR EACH ROW EXECUTE FUNCTION app.audit_trigger();
--> statement-breakpoint

-- ============================================================================
-- 6. Ledger immutability — no updates/deletes ever (corrections are reversals)
-- ============================================================================
CREATE OR REPLACE FUNCTION app.reject_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'ledger tables are append-only; use a reversing transaction';
END $$ LANGUAGE plpgsql;
--> statement-breakpoint
CREATE TRIGGER ledger_tx_immutable BEFORE UPDATE OR DELETE ON ledger_transactions
  FOR EACH ROW EXECUTE FUNCTION app.reject_mutation();
--> statement-breakpoint
CREATE TRIGGER ledger_postings_immutable BEFORE UPDATE OR DELETE ON ledger_postings
  FOR EACH ROW EXECUTE FUNCTION app.reject_mutation();
--> statement-breakpoint

-- ============================================================================
-- 7. Balanced-transaction enforcement (Credit-Ledger.md §4)
-- ============================================================================
CREATE OR REPLACE FUNCTION ledger_assert_balanced() RETURNS trigger AS $$
DECLARE deb bigint; cred bigint;
BEGIN
  SELECT COALESCE(SUM(amount) FILTER (WHERE direction = 'debit'), 0),
         COALESCE(SUM(amount) FILTER (WHERE direction = 'credit'), 0)
    INTO deb, cred
    FROM ledger_postings
   WHERE transaction_id = NEW.transaction_id;
  IF deb <> cred OR deb = 0 THEN
    RAISE EXCEPTION 'ledger transaction % unbalanced: debit=% credit=%',
      NEW.transaction_id, deb, cred;
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;
--> statement-breakpoint
CREATE CONSTRAINT TRIGGER ledger_balanced
  AFTER INSERT ON ledger_postings DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION ledger_assert_balanced();
--> statement-breakpoint

-- ============================================================================
-- 8. System accounts + derived balance view
-- ============================================================================
INSERT INTO ledger_accounts (code, type, normal_balance, domain) VALUES
  ('liability:credits_issued:sys',        'liability', 'credit', 'CREDIT'),
  ('asset:cash:sys',                      'asset',     'debit',  'USD_MICRO'),
  ('liability:deferred_revenue_usd:sys',  'liability', 'credit', 'USD_MICRO'),
  ('revenue:generation:sys',              'revenue',   'credit', 'USD_MICRO'),
  ('revenue:breakage:sys',                'revenue',   'credit', 'USD_MICRO'),
  ('expense:provider_cost:sys',           'expense',   'debit',  'USD_MICRO'),
  ('expense:refunds:sys',                 'expense',   'debit',  'USD_MICRO'),
  ('equity:adjustments:sys',              'equity',    'debit',  'USD_MICRO')
ON CONFLICT (code) DO NOTHING;
--> statement-breakpoint

-- Balances are derived, never stored (Credit-Ledger.md §4).
-- Filtered to the caller's workspace; owner-privileged read over postings by design.
CREATE VIEW v_workspace_credit_balances AS
  SELECT a.workspace_id,
         SUM(CASE WHEN a.code LIKE 'asset:credits_available:%'
                  THEN CASE WHEN p.direction = 'debit' THEN p.amount ELSE -p.amount END
                  ELSE 0 END) AS available,
         SUM(CASE WHEN a.code LIKE 'asset:credits_reserved:%'
                  THEN CASE WHEN p.direction = 'debit' THEN p.amount ELSE -p.amount END
                  ELSE 0 END) AS reserved
    FROM ledger_accounts a
    JOIN ledger_postings p ON p.account_code = a.code
   WHERE a.workspace_id IS NOT NULL
     AND a.workspace_id = app.current_workspace()
     AND a.domain = 'CREDIT'
   GROUP BY a.workspace_id;
--> statement-breakpoint
GRANT SELECT ON v_workspace_credit_balances TO authenticated;
--> statement-breakpoint

-- ============================================================================
-- 9. Workspace provisioning (creates workspace + owner membership + ledger accounts)
-- ============================================================================
CREATE OR REPLACE FUNCTION app.provision_workspace(p_owner uuid, p_name text)
RETURNS uuid AS $$
DECLARE ws uuid;
BEGIN
  INSERT INTO workspaces (name, created_by) VALUES (p_name, p_owner) RETURNING id INTO ws;
  INSERT INTO memberships (workspace_id, user_id, role) VALUES (ws, p_owner, 'owner');
  INSERT INTO ledger_accounts (code, type, normal_balance, domain, workspace_id) VALUES
    ('asset:credits_available:ws_' || ws::text, 'asset', 'debit', 'CREDIT', ws),
    ('asset:credits_reserved:ws_'  || ws::text, 'asset', 'debit', 'CREDIT', ws);
  RETURN ws;
END $$ LANGUAGE plpgsql SECURITY DEFINER;
--> statement-breakpoint

-- ============================================================================
-- 10. ledger.post() — the single write door (Credit-Ledger.md §5)
-- ============================================================================
CREATE SCHEMA IF NOT EXISTS ledger;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION ledger.post(
  p_recipe          text,
  p_workspace       uuid,
  p_amount          bigint,
  p_idempotency_key text,
  p_job             uuid DEFAULT NULL,
  p_reason          text DEFAULT NULL,
  p_operator        uuid DEFAULT NULL,
  p_usd_basis       bigint DEFAULT NULL,   -- micro-USD per credit (R1/R4-linked recognition)
  p_provider        text DEFAULT NULL,     -- provider_prepay / provider_cost
  p_adjust_account  text DEFAULT NULL,     -- adjustment target account
  p_adjust_direction text DEFAULT NULL     -- 'debit' | 'credit'
) RETURNS uuid AS $$
DECLARE
  tx_id uuid;
  existing uuid;
  link uuid := gen_random_uuid();
  avail bigint;
  acct_avail text := 'asset:credits_available:ws_' || p_workspace::text;
  acct_resv  text := 'asset:credits_reserved:ws_'  || p_workspace::text;
  prepaid text := 'asset:provider_prepaid:' || COALESCE(p_provider, '');
  usd_amount bigint;
BEGIN
  -- Idempotency: replays return the existing transaction (ADR-0008; ledger §4)
  SELECT id INTO existing FROM ledger_transactions WHERE idempotency_key = p_idempotency_key;
  IF FOUND THEN RETURN existing; END IF;

  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'amount must be positive';
  END IF;

  -- Serialise reservation attempts per workspace (ledger §5 step 3)
  IF p_recipe = 'reserve' THEN
    PERFORM pg_advisory_xact_lock(hashtext(p_workspace::text));
    SELECT COALESCE(SUM(CASE WHEN p.direction = 'debit' THEN p.amount ELSE -p.amount END), 0)
      INTO avail
      FROM ledger_postings p JOIN ledger_accounts a ON a.code = p.account_code
     WHERE a.code = acct_avail;
    IF avail < p_amount THEN
      RAISE EXCEPTION 'INSUFFICIENT_CREDITS: available=% requested=%', avail, p_amount;
    END IF;
  END IF;

  IF p_recipe IN ('issuance_dev') THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
    VALUES (link, 'CREDIT', 'issuance', p_workspace, p_job, p_idempotency_key, p_usd_basis)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, acct_avail, 'debit', p_amount),
      (tx_id, 'liability:credits_issued:sys', 'credit', p_amount);

  ELSIF p_recipe = 'purchase' THEN
    IF p_usd_basis IS NULL THEN RAISE EXCEPTION 'purchase requires usd_basis'; END IF;
    usd_amount := p_amount * p_usd_basis;
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
    VALUES (link, 'USD_MICRO', 'purchase', p_workspace, p_job, p_idempotency_key || ':usd', p_usd_basis)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, 'asset:cash:sys', 'debit', usd_amount),
      (tx_id, 'liability:deferred_revenue_usd:sys', 'credit', usd_amount);
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
    VALUES (link, 'CREDIT', 'issuance', p_workspace, p_job, p_idempotency_key, p_usd_basis)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, acct_avail, 'debit', p_amount),
      (tx_id, 'liability:credits_issued:sys', 'credit', p_amount);

  ELSIF p_recipe = 'reserve' THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key)
    VALUES (link, 'CREDIT', 'reservation', p_workspace, p_job, p_idempotency_key)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, acct_resv, 'debit', p_amount),
      (tx_id, acct_avail, 'credit', p_amount);

  ELSIF p_recipe = 'release' THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key)
    VALUES (link, 'CREDIT', 'release', p_workspace, p_job, p_idempotency_key)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, acct_avail, 'debit', p_amount),
      (tx_id, acct_resv, 'credit', p_amount);

  ELSIF p_recipe = 'settle' THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
    VALUES (link, 'CREDIT', 'settlement', p_workspace, p_job, p_idempotency_key, p_usd_basis)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, 'liability:credits_issued:sys', 'debit', p_amount),
      (tx_id, acct_resv, 'credit', p_amount);
    IF p_usd_basis IS NOT NULL THEN
      usd_amount := p_amount * p_usd_basis;
      INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
      VALUES (link, 'USD_MICRO', 'recognition', p_workspace, p_job, p_idempotency_key || ':recognition', p_usd_basis)
      RETURNING id INTO tx_id;
      INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
        (tx_id, 'liability:deferred_revenue_usd:sys', 'debit', usd_amount),
        (tx_id, 'revenue:generation:sys', 'credit', usd_amount);
    END IF;

  ELSIF p_recipe = 'goodwill' THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, reason, operator_id)
    VALUES (link, 'CREDIT', 'goodwill', p_workspace, p_job, p_idempotency_key, p_reason, p_operator)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, acct_avail, 'debit', p_amount),
      (tx_id, 'liability:credits_issued:sys', 'credit', p_amount);

  ELSIF p_recipe = 'expiry' THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
    VALUES (link, 'CREDIT', 'expiry', p_workspace, p_job, p_idempotency_key, p_usd_basis)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, 'liability:credits_issued:sys', 'debit', p_amount),
      (tx_id, acct_avail, 'credit', p_amount);
    IF p_usd_basis IS NOT NULL THEN
      usd_amount := p_amount * p_usd_basis;
      INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, usd_basis_micro_per_credit)
      VALUES (link, 'USD_MICRO', 'breakage', p_workspace, p_job, p_idempotency_key || ':breakage', p_usd_basis)
      RETURNING id INTO tx_id;
      INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
        (tx_id, 'liability:deferred_revenue_usd:sys', 'debit', usd_amount),
        (tx_id, 'revenue:breakage:sys', 'credit', usd_amount);
    END IF;

  ELSIF p_recipe = 'provider_prepay' THEN
    IF p_provider IS NULL THEN RAISE EXCEPTION 'provider_prepay requires provider'; END IF;
    INSERT INTO ledger_accounts (code, type, normal_balance, domain)
    VALUES (prepaid, 'asset', 'debit', 'USD_MICRO') ON CONFLICT (code) DO NOTHING;
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key)
    VALUES (link, 'USD_MICRO', 'provider_prepay', p_workspace, p_job, p_idempotency_key)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, prepaid, 'debit', p_amount),
      (tx_id, 'asset:cash:sys', 'credit', p_amount);

  ELSIF p_recipe = 'provider_cost' THEN
    IF p_provider IS NULL THEN RAISE EXCEPTION 'provider_cost requires provider'; END IF;
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key)
    VALUES (link, 'USD_MICRO', 'provider_cost', p_workspace, p_job, p_idempotency_key)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, 'expense:provider_cost:sys', 'debit', p_amount),
      (tx_id, prepaid, 'credit', p_amount);

  ELSIF p_recipe = 'refund_cash' THEN
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, reason, operator_id)
    VALUES (link, 'USD_MICRO', 'refund_cash', p_workspace, p_job, p_idempotency_key, p_reason, p_operator)
    RETURNING id INTO tx_id;
    INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
      (tx_id, 'expense:refunds:sys', 'debit', p_amount),
      (tx_id, 'asset:cash:sys', 'credit', p_amount);

  ELSIF p_recipe = 'adjustment' THEN
    IF p_reason IS NULL OR p_operator IS NULL OR p_adjust_account IS NULL
       OR p_adjust_direction NOT IN ('debit', 'credit') THEN
      RAISE EXCEPTION 'adjustment requires reason, operator, account and direction';
    END IF;
    INSERT INTO ledger_transactions (link_group, domain, kind, workspace_id, job_id, idempotency_key, reason, operator_id)
    VALUES (link, 'USD_MICRO', 'adjustment', p_workspace, p_job, p_idempotency_key, p_reason, p_operator)
    RETURNING id INTO tx_id;
    IF p_adjust_direction = 'debit' THEN
      INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
        (tx_id, p_adjust_account, 'debit', p_amount),
        (tx_id, 'equity:adjustments:sys', 'credit', p_amount);
    ELSE
      INSERT INTO ledger_postings (transaction_id, account_code, direction, amount) VALUES
        (tx_id, p_adjust_account, 'credit', p_amount),
        (tx_id, 'equity:adjustments:sys', 'debit', p_amount);
    END IF;

  ELSE
    RAISE EXCEPTION 'unknown recipe: %', p_recipe;
  END IF;

  RETURN tx_id;
END $$ LANGUAGE plpgsql SECURITY DEFINER;
--> statement-breakpoint
REVOKE ALL ON FUNCTION ledger.post(text, uuid, bigint, text, uuid, text, uuid, bigint, text, text, text) FROM PUBLIC;
--> statement-breakpoint
GRANT EXECUTE ON FUNCTION ledger.post(text, uuid, bigint, text, uuid, text, uuid, bigint, text, text, text) TO authenticated;
--> statement-breakpoint
REVOKE ALL ON FUNCTION app.provision_workspace(uuid, text) FROM PUBLIC;
--> statement-breakpoint
GRANT EXECUTE ON FUNCTION app.provision_workspace(uuid, text) TO authenticated;
