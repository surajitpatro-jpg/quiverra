-- 0007_balance_trigger_definer.sql
-- W2 fix: the deferred balance-check trigger fires at COMMIT in the CALLER's
-- security context. As SECURITY INVOKER it fails with "permission denied for
-- table ledger_postings" whenever ledger.post() runs under the authenticated
-- role (the normal API path). The balance check is a system invariant and must
-- run with the function owner's privileges; postings stay deny-all for callers.
ALTER FUNCTION ledger_assert_balanced() SECURITY DEFINER;
