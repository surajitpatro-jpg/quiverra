-- 0005_workspace_profiles.sql
-- W2: member listing needs teammate emails. Profiles stay private by default;
-- visible only where the viewer shares a workspace with the profile owner.
CREATE POLICY workspace_profiles ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM memberships mine
      JOIN memberships theirs ON theirs.workspace_id = mine.workspace_id
      WHERE mine.user_id = app.current_user()
        AND theirs.user_id = profiles.id
    )
  );
