-- 0003_invitation_policies_and_hardening.sql
-- W2: RLS/grants/audit for invitations + SECURITY DEFINER search_path hardening.
-- search_path is pinned on every SECURITY DEFINER function so a caller cannot
-- influence object resolution (classic definer-hijack vector).

-- ============================================================================
-- 1. Invitations: tenant isolation, grants, audit
-- ============================================================================
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
ALTER TABLE invitations FORCE ROW LEVEL SECURITY;
--> statement-breakpoint
CREATE POLICY tenant_isolation ON invitations
  USING (workspace_id = app.current_workspace())
  WITH CHECK (workspace_id = app.current_workspace());
--> statement-breakpoint
GRANT SELECT, INSERT, UPDATE ON invitations TO authenticated;  -- no delete: revoke instead
--> statement-breakpoint
CREATE TRIGGER audit_invitations AFTER INSERT OR UPDATE OR DELETE ON invitations
  FOR EACH ROW EXECUTE FUNCTION app.audit_trigger();
--> statement-breakpoint

-- One pending invitation per (workspace, email). Re-invite after revoke/accept is allowed.
CREATE UNIQUE INDEX invitations_one_pending_per_email
  ON invitations (workspace_id, lower(email))
  WHERE status = 'pending';
--> statement-breakpoint

-- ============================================================================
-- 2. SECURITY DEFINER hardening (Security.md §5; W2 security review)
-- Pin search_path so object resolution cannot be hijacked by a caller's path.
-- pg_catalog first (built-ins), then the schemas the functions actually use.
-- ============================================================================
ALTER FUNCTION app.audit_trigger() SET search_path = pg_catalog, public, app;
--> statement-breakpoint
ALTER FUNCTION app.provision_workspace(uuid, text) SET search_path = pg_catalog, public, app;
--> statement-breakpoint
ALTER FUNCTION ledger.post(text, uuid, bigint, text, uuid, text, uuid, bigint, text, text, text)
  SET search_path = pg_catalog, public, app, ledger;
--> statement-breakpoint
-- Invoker trigger functions: pinned too, so behaviour is identical regardless of caller.
ALTER FUNCTION ledger_assert_balanced() SET search_path = pg_catalog, public;
--> statement-breakpoint
ALTER FUNCTION app.reject_mutation() SET search_path = pg_catalog, public;
