-- 0004_member_read_policies.sql
-- W2: workspace listing requires reading memberships/workspace names across
-- workspaces BEFORE a workspace claim exists. Data tables remain claim-scoped;
-- these SELECT-only additions expose nothing beyond the caller's own memberships
-- and the names of workspaces they belong to.

-- A user can read their OWN membership rows across all workspaces.
CREATE POLICY own_memberships ON memberships
  FOR SELECT USING (user_id = app.current_user());
--> statement-breakpoint

-- A user can read workspace rows they are a member of (name/settings for the
-- switcher). Write access stays with tenant_isolation (claim-scoped).
CREATE POLICY member_read ON workspaces
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM memberships m
      WHERE m.workspace_id = workspaces.id
        AND m.user_id = app.current_user()
    )
  );
