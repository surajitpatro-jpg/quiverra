import { describe, expect, it } from "vitest";
import { admin } from "./helpers.js";
import { fx, useFixtures } from "./fixtures.js";

useFixtures();

describe("audit logging (W1 requirement)", () => {
  it("workspace creation produced an insert audit row", async () => {
    const sql = admin();
    const rows = await sql`
      SELECT action, entity_table FROM audit_log
      WHERE entity_table = 'workspaces' AND action = 'insert' AND workspace_id = ${fx.wsA}`;
    expect(rows.length).toBe(1);
    await sql.end();
  });

  it("workspace update is audited with before/after snapshots", async () => {
    const sql = admin();
    await sql`UPDATE workspaces SET spend_policy = 'free_preferred' WHERE id = ${fx.wsA}`;
    const rows = await sql`
      SELECT action, before, after FROM audit_log
      WHERE entity_table = 'workspaces' AND action = 'update' AND workspace_id = ${fx.wsA}
      ORDER BY id DESC LIMIT 1`;
    expect(rows.length).toBe(1);
    expect((rows[0]!.before as { spend_policy: string }).spend_policy).toBe("free_only");
    expect((rows[0]!.after as { spend_policy: string }).spend_policy).toBe("free_preferred");
    // restore
    await sql`UPDATE workspaces SET spend_policy = 'free_only' WHERE id = ${fx.wsA}`;
    await sql.end();
  });

  it("membership changes are audited", async () => {
    const sql = admin();
    const rows = await sql`
      SELECT count(*)::int AS c FROM audit_log
      WHERE entity_table = 'memberships' AND workspace_id = ${fx.wsA}`;
    expect(rows[0]!.c).toBeGreaterThanOrEqual(2); // owner + shared member
    await sql.end();
  });
});
