import { beforeAll } from "vitest";
import { admin } from "./helpers.js";

/**
 * Shared fixture: two workspaces with one profile each, plus one shared profile
 * who is a member of BOTH (cross-tenant isolation probe).
 */
export const fx = {
  userA: "11111111-1111-1111-1111-111111111111",
  userB: "22222222-2222-2222-2222-222222222222",
  userX: "33333333-3333-3333-3333-333333333333", // member of both
  wsA: "",
  wsB: "",
};

let ready: Promise<void> | null = null;

async function ensureFixtures() {
  const sql = admin();
  await sql`INSERT INTO auth.users (id, email) VALUES
    (${fx.userA}, 'a@test.dev'), (${fx.userB}, 'b@test.dev'), (${fx.userX}, 'x@test.dev')
    ON CONFLICT (id) DO NOTHING`;
  await sql`INSERT INTO profiles (id, email) VALUES
    (${fx.userA}, 'a@test.dev'), (${fx.userB}, 'b@test.dev'), (${fx.userX}, 'x@test.dev')
    ON CONFLICT (id) DO NOTHING`;
  if (!fx.wsA) {
    const [a] = await sql`SELECT app.provision_workspace(${fx.userA}, 'Workspace A') AS id`;
    fx.wsA = a!.id as string;
  }
  if (!fx.wsB) {
    const [b] = await sql`SELECT app.provision_workspace(${fx.userB}, 'Workspace B') AS id`;
    fx.wsB = b!.id as string;
  }
  await sql`INSERT INTO memberships (workspace_id, user_id, role)
    VALUES (${fx.wsA}, ${fx.userX}, 'editor'), (${fx.wsB}, ${fx.userX}, 'viewer')
    ON CONFLICT DO NOTHING`;
  await sql.end();
}

export function useFixtures() {
  beforeAll(async () => {
    ready ??= ensureFixtures();
    await ready;
  }, 30_000);
}
