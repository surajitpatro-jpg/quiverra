import { describe, expect, it } from "vitest";
import { admin, asUser } from "./helpers.js";
import { fx, useFixtures } from "./fixtures.js";

useFixtures();

describe("RLS workspace isolation (Database-Architecture §8 test contract)", () => {
  it("user of workspace A sees only workspace A's projects", async () => {
    const sql = admin();
    await asUser(sql, fx.userA, fx.wsA, async (tx) => {
      await tx`INSERT INTO projects (workspace_id, title, created_by)
               VALUES (${fx.wsA}, 'A project', ${fx.userA})`;
    });
    await asUser(sql, fx.userB, fx.wsB, async (tx) => {
      await tx`INSERT INTO projects (workspace_id, title, created_by)
               VALUES (${fx.wsB}, 'B project', ${fx.userB})`;
    });

    const inA = await asUser(sql, fx.userA, fx.wsA, (tx) => tx`SELECT title FROM projects`);
    expect(inA.map((r) => r.title)).toEqual(["A project"]);

    const inB = await asUser(sql, fx.userB, fx.wsB, (tx) => tx`SELECT title FROM projects`);
    expect(inB.map((r) => r.title)).toEqual(["B project"]);
    await sql.end();
  });

  it("cross-workspace INSERT is rejected by WITH CHECK", async () => {
    const sql = admin();
    await expect(
      asUser(sql, fx.userA, fx.wsA, async (tx) => {
        await tx`INSERT INTO projects (workspace_id, title, created_by)
                 VALUES (${fx.wsB}, 'intrusion', ${fx.userA})`;
      }),
    ).rejects.toThrow(/row-level security|row violates/i);
    await sql.end();
  });

  it("shared member sees each workspace only in its own context", async () => {
    const sql = admin();
    const inA = await asUser(
      sql,
      fx.userX,
      fx.wsA,
      (tx) => tx`SELECT count(*)::int AS c FROM projects`,
    );
    expect(inA[0]!.c).toBe(1); // only A's project
    const inB = await asUser(
      sql,
      fx.userX,
      fx.wsB,
      (tx) => tx`SELECT count(*)::int AS c FROM projects`,
    );
    expect(inB[0]!.c).toBe(1); // only B's project
    await sql.end();
  });

  it("profiles: self + shared-workspace members only (0005)", async () => {
    const sql = admin();
    // userA shares workspace A with userX (member-read), so both are visible —
    // but never userB, who shares no workspace with userA.
    const rows = await asUser(
      sql,
      fx.userA,
      fx.wsA,
      (tx) => tx`SELECT DISTINCT id FROM profiles ORDER BY id`,
    );
    const ids = rows.map((r) => r.id);
    expect(ids).toContain(fx.userA);
    expect(ids).toContain(fx.userX);
    expect(ids).not.toContain(fx.userB);
    await sql.end();
  });

  it("ledger_postings have no direct access for authenticated", async () => {
    const sql = admin();
    await expect(
      asUser(sql, fx.userA, fx.wsA, (tx) => tx`SELECT count(*) FROM ledger_postings`),
    ).rejects.toThrow(/permission denied/i);
    await sql.end();
  });

  it("audit rows are readable only in their own workspace context", async () => {
    const sql = admin();
    const inA = await asUser(
      sql,
      fx.userA,
      fx.wsA,
      (tx) => tx`SELECT count(*)::int AS c FROM audit_log`,
    );
    const inB = await asUser(
      sql,
      fx.userB,
      fx.wsB,
      (tx) => tx`SELECT count(*)::int AS c FROM audit_log`,
    );
    expect(inA[0]!.c).toBeGreaterThan(0);
    expect(inB[0]!.c).toBeGreaterThan(0);
    // And no overlap: workspace A's audit rows must not leak into B's context
    const leaked = await asUser(
      sql,
      fx.userB,
      fx.wsB,
      (tx) => tx`SELECT count(*)::int AS c FROM audit_log WHERE workspace_id = ${fx.wsA}`,
    );
    expect(leaked[0]!.c).toBe(0);
    await sql.end();
  });
});
