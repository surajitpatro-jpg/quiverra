import postgres from "postgres";

export const ADMIN_URL =
  process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/platform_w1_test";

export function admin() {
  return postgres(ADMIN_URL, { max: 4, prepare: false });
}

/**
 * Run `fn` as the `authenticated` role with JWT claims set — the exact context
 * RLS policies evaluate in (Database-Architecture.md §8).
 */
export async function asUser<T>(
  sql: postgres.Sql,
  userId: string,
  workspaceId: string,
  fn: (sql: postgres.Sql) => Promise<T>,
): Promise<T> {
  return sql.begin(async (tx) => {
    await tx.unsafe(`SET LOCAL ROLE authenticated`);
    await tx.unsafe(
      `SET LOCAL request.jwt.claims = '${JSON.stringify({ sub: userId, workspace_id: workspaceId })}'`,
    );
    return fn(tx as unknown as postgres.Sql);
  }) as Promise<T>;
}

/** Deterministic PRNG for the ledger property test (seeded runs are reproducible). */
export function lcg(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 0xffffffff;
  };
}
