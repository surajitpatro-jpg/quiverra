import { describe, expect, it } from "vitest";
import { admin } from "./helpers.js";
import { fx, useFixtures } from "./fixtures.js";
import type postgres from "postgres";

/** asUser variant with NO workspace claim — the pre-selection context (W2). */
async function asUserNoWorkspace<T>(
  sql: postgres.Sql,
  userId: string,
  fn: (sql: postgres.Sql) => Promise<T>,
): Promise<T> {
  return sql.begin(async (tx) => {
    await tx.unsafe(`SET LOCAL ROLE authenticated`);
    await tx.unsafe(`SET LOCAL request.jwt.claims = '${JSON.stringify({ sub: userId })}'`);
    return fn(tx as unknown as postgres.Sql);
  }) as Promise<T>;
}

describe("member-read policies (W2) — workspace listing without a claim", () => {
  useFixtures();

  it("a user sees exactly the workspaces they belong to, nothing else", async () => {
    const sql = admin();
    await asUserNoWorkspace(sql, fx.userX, async (tx) => {
      // Fixture workspaces are provisioned per test file, hence DISTINCT.
      const ws = await tx`SELECT DISTINCT name FROM workspaces ORDER BY name`;
      expect(ws.map((r) => r.name)).toEqual(["Workspace A", "Workspace B"]);
      const ms = await tx`SELECT role FROM memberships`;
      expect(ms.every((r) => ["editor", "viewer"].includes(r.role as string))).toBe(true);
    });
    await asUserNoWorkspace(sql, fx.userA, async (tx) => {
      const ws = await tx`SELECT name FROM workspaces`;
      const names = ws.map((r) => r.name);
      expect(names).toContain("Workspace A");
      expect(names).not.toContain("Workspace B"); // not a member — must never appear
    });
    await sql.end();
  });

  it("data tables remain invisible without a workspace claim", async () => {
    const sql = admin();
    await asUserNoWorkspace(sql, fx.userX, async (tx) => {
      const p = await tx`SELECT count(*)::int AS c FROM projects`;
      const a = await tx`SELECT count(*)::int AS c FROM assets`;
      const i = await tx`SELECT count(*)::int AS c FROM invitations`;
      expect(p[0]!.c).toBe(0);
      expect(a[0]!.c).toBe(0);
      expect(i[0]!.c).toBe(0);
    });
    await sql.end();
  });

  it("write policies unchanged: cannot write without the workspace claim", async () => {
    const sql = admin();
    await expect(
      asUserNoWorkspace(sql, fx.userA, async (tx) => {
        await tx`INSERT INTO projects (workspace_id, title, created_by)
                 VALUES (${fx.wsA}, 'unauthorised', ${fx.userA})`;
      }),
    ).rejects.toThrow(/row-level security|row violates/i);
    await sql.end();
  });
});
