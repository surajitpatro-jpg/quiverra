import { describe, expect, it } from "vitest";
import { randomBytes } from "node:crypto";
import { admin, asUser } from "./helpers.js";
import { fx, useFixtures } from "./fixtures.js";

useFixtures();

describe("asset isolation & dedup (Asset-Storage.md §2, ADR-0013)", () => {
  it("rejects r2_key without the owning workspace prefix (DB CHECK)", async () => {
    const sql = admin();
    const hash = randomBytes(32);
    await expect(
      sql`INSERT INTO assets (workspace_id, content_hash, asset_class, r2_key, bytes, mime, created_by)
          VALUES (${fx.wsA}, ${hash}, 'upload', ${"ws_" + fx.wsB + "/upload/x/file.png"}, 10, 'image/png', ${fx.userA})`,
    ).rejects.toThrow(/assets_r2_key_workspace_prefixed/);
    await sql.end();
  });

  it("workspace-scoped dedup: same hash in same workspace+class conflicts, different workspace does not", async () => {
    const sql = admin();
    const hash = randomBytes(32);
    const keyA1 = `ws_${fx.wsA}/upload/${randomBytes(4).toString("hex")}/f.png`;
    const keyA2 = `ws_${fx.wsA}/upload/${randomBytes(4).toString("hex")}/f.png`;
    const keyB = `ws_${fx.wsB}/upload/${randomBytes(4).toString("hex")}/f.png`;

    await sql`INSERT INTO assets (workspace_id, content_hash, asset_class, r2_key, bytes, mime, created_by)
              VALUES (${fx.wsA}, ${hash}, 'upload', ${keyA1}, 10, 'image/png', ${fx.userA})`;
    // duplicate in same workspace+class → unique violation
    await expect(
      sql`INSERT INTO assets (workspace_id, content_hash, asset_class, r2_key, bytes, mime, created_by)
          VALUES (${fx.wsA}, ${hash}, 'upload', ${keyA2}, 10, 'image/png', ${fx.userA})`,
    ).rejects.toThrow(/assets_ws_hash_class/);
    // same bytes in ANOTHER workspace → stored separately by design (no cross-tenant dedup)
    await sql`INSERT INTO assets (workspace_id, content_hash, asset_class, r2_key, bytes, mime, created_by)
              VALUES (${fx.wsB}, ${hash}, 'upload', ${keyB}, 10, 'image/png', ${fx.userB})`;
    await sql.end();
  });

  it("assets are invisible across workspaces via RLS", async () => {
    const sql = admin();
    const inA = await asUser(sql, fx.userA, fx.wsA, (tx) => tx`SELECT r2_key FROM assets`);
    for (const r of inA) {
      expect(String(r.r2_key)).toMatch(new RegExp(`^ws_${fx.wsA}/`));
    }
    const inB = await asUser(sql, fx.userB, fx.wsB, (tx) => tx`SELECT r2_key FROM assets`);
    for (const r of inB) {
      expect(String(r.r2_key)).toMatch(new RegExp(`^ws_${fx.wsB}/`));
    }
    await sql.end();
  });
});
