import { describe, expect, it } from "vitest";
import postgres from "postgres";
import { ADMIN_URL, admin, asUser } from "./helpers.js";
import { fx, useFixtures } from "./fixtures.js";

/**
 * W2 security review (Security.md §5): SECURITY DEFINER hardening, execute
 * privileges, concurrent reservation behaviour, and invitation isolation.
 */
describe("security hardening — SECURITY DEFINER functions", () => {
  useFixtures();

  it("every definer function has a pinned search_path", async () => {
    const sql = admin();
    const rows = await sql`
      SELECT p.proname, p.prosecdef, COALESCE(p.proconfig::text, '') AS cfg
      FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname IN ('app', 'ledger') AND p.prosecdef`;
    const byName = Object.fromEntries(rows.map((r) => [r.proname, r.cfg]));
    for (const fn of ["audit_trigger", "provision_workspace", "post"]) {
      expect(byName[fn], `${fn} must exist and be SECURITY DEFINER`).toBeDefined();
      expect(byName[fn], `${fn} must pin search_path`).toContain("search_path=");
      expect(byName[fn]).toContain("pg_catalog");
    }
    await sql.end();
  });

  it("ledger.post is not executable by PUBLIC, only by authenticated", async () => {
    const sql = admin();
    const [row] = await sql`
      SELECT p.proacl::text AS acl,
             has_function_privilege(
               'authenticated',
               'ledger.post(text,uuid,bigint,text,uuid,text,uuid,bigint,text,text,text)',
               'EXECUTE') AS auth_can
      FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'ledger' AND p.proname = 'post'`;
    expect(row!.auth_can).toBe(true);
    // NULL proacl would mean default privileges (PUBLIC EXECUTE). After our REVOKE
    // it is explicit, and must not contain a PUBLIC grant (empty grantee before '=').
    expect(row!.acl).not.toBeNull();
    expect(row!.acl).not.toMatch(/\{=X\//);
    await sql.end();
  });

  it("definer doors are executable directly as the authenticated role (schema USAGE)", async () => {
    // Regression: 0001 granted EXECUTE but not schema USAGE; first caught by
    // API-level tests ("permission denied for schema app"). Fixed in 0006.
    const sql = admin();
    const wsId = await asUser(sql, fx.userA, fx.wsA, async (tx) => {
      const [row] =
        await tx`SELECT app.provision_workspace(${fx.userA}, 'Definer Door Probe') AS id`;
      return row!.id as string;
    });
    await asUser(sql, fx.userA, wsId, async (tx) => {
      await tx`SELECT ledger.post('issuance_dev', ${wsId}, ${5}, 't:hard:door', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
    });
    await sql.end();
  });

  it("rejects invalid input before touching the ledger", async () => {
    const sql = admin();
    await expect(
      sql`SELECT ledger.post('reserve', ${fx.wsA}, ${0}, 't:hard:zero', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`,
    ).rejects.toThrow(/amount must be positive/);
    await expect(
      sql`SELECT ledger.post('nonsense', ${fx.wsA}, ${1}, 't:hard:bad', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`,
    ).rejects.toThrow(/unknown recipe/);
    await sql.end();
  });

  it("concurrent reservations: exactly the affordable number succeed", async () => {
    // Fresh workspace so the assertion is independent of other suites.
    const setup = admin();
    const [ws] =
      await setup`SELECT app.provision_workspace(${fx.userA}, 'Concurrency Probe') AS id`;
    const wsId = ws!.id as string;
    await setup`SELECT ledger.post('issuance_dev', ${wsId}, ${150}, 't:hard:issue', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
    await setup.end();

    // 10 parallel reservations of 100 against 150 available: exactly 1 must win.
    const pool = postgres(ADMIN_URL, { max: 10, prepare: false });
    const results = await Promise.allSettled(
      Array.from(
        { length: 10 },
        (_, i) =>
          pool`SELECT ledger.post('reserve', ${wsId}, ${100}, ${`t:hard:conc:${i}`}, NULL, NULL, NULL, NULL, NULL, NULL, NULL)`,
      ),
    );
    const ok = results.filter((r) => r.status === "fulfilled").length;
    const insufficient = results.filter(
      (r) => r.status === "rejected" && String(r.reason).includes("INSUFFICIENT_CREDITS"),
    ).length;
    expect(ok).toBe(1);
    expect(insufficient).toBe(9);

    const [bal] = await pool`
      SELECT
        COALESCE(SUM(CASE WHEN a.code LIKE 'asset:credits_available:%'
                          THEN CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END END), 0)::bigint AS a,
        COALESCE(SUM(CASE WHEN a.code LIKE 'asset:credits_reserved:%'
                          THEN CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END END), 0)::bigint AS r
      FROM ledger_postings p JOIN ledger_accounts a ON a.code = p.account_code
      WHERE a.workspace_id = ${wsId}`;
    expect(BigInt(bal!.a)).toBe(50n);
    expect(BigInt(bal!.r)).toBe(100n);
    await pool.end();
  });
});

describe("invitations — RLS and uniqueness", () => {
  useFixtures();

  it("tenant isolation: invite visible in its workspace only", async () => {
    const sql = admin();
    await asUser(sql, fx.userA, fx.wsA, async (tx) => {
      await tx`INSERT INTO invitations (workspace_id, email, role, token, invited_by, expires_at)
               VALUES (${fx.wsA}, 'newhire@test.dev', 'editor', 'tok-inv-1', ${fx.userA}, now() + interval '7 days')`;
      const rows = await tx`SELECT email FROM invitations`;
      expect(rows.length).toBe(1);
    });
    // User B (own workspace claim) must not see workspace A's invite.
    await asUser(sql, fx.userB, fx.wsB, async (tx) => {
      const rows = await tx`SELECT count(*)::int AS c FROM invitations`;
      expect(rows[0]!.c).toBe(0);
    });
    // Shared member X with workspace B claim must not see it either.
    await asUser(sql, fx.userX, fx.wsB, async (tx) => {
      const rows = await tx`SELECT count(*)::int AS c FROM invitations`;
      expect(rows[0]!.c).toBe(0);
    });
    await sql.end();
  });

  it("WITH CHECK rejects inserting an invite into another workspace", async () => {
    const sql = admin();
    await expect(
      asUser(sql, fx.userB, fx.wsB, async (tx) => {
        await tx`INSERT INTO invitations (workspace_id, email, role, token, invited_by, expires_at)
                 VALUES (${fx.wsA}, 'sneaky@test.dev', 'viewer', 'tok-inv-2', ${fx.userB}, now() + interval '7 days')`;
      }),
    ).rejects.toThrow(/row-level security|row violates/i);
    await sql.end();
  });

  it("one pending invite per (workspace, email); re-invite after revoke allowed", async () => {
    const sql = admin();
    // Duplicate pending invite (case-insensitive email) — in its own transaction,
    // because a failed statement aborts the enclosing transaction.
    await expect(
      asUser(sql, fx.userA, fx.wsA, async (tx) => {
        await tx`INSERT INTO invitations (workspace_id, email, role, token, invited_by, expires_at)
                 VALUES (${fx.wsA}, 'NewHire@test.dev', 'viewer', 'tok-inv-3', ${fx.userA}, now() + interval '7 days')`;
      }),
    ).rejects.toThrow(/invitations_one_pending_per_email/);
    // Revoke, then re-invite the same address: allowed.
    await asUser(sql, fx.userA, fx.wsA, async (tx) => {
      await tx`UPDATE invitations SET status = 'revoked' WHERE token = 'tok-inv-1'`;
      await tx`INSERT INTO invitations (workspace_id, email, role, token, invited_by, expires_at)
               VALUES (${fx.wsA}, 'newhire@test.dev', 'director', 'tok-inv-4', ${fx.userA}, now() + interval '7 days')`;
    });
    // Case-insensitive email, different workspace: allowed.
    await asUser(sql, fx.userB, fx.wsB, async (tx) => {
      await tx`INSERT INTO invitations (workspace_id, email, role, token, invited_by, expires_at)
               VALUES (${fx.wsB}, 'newhire@test.dev', 'viewer', 'tok-inv-5', ${fx.userB}, now() + interval '7 days')`;
    });
    await sql.end();
  });

  it("invitation lifecycle is audit-logged", async () => {
    const sql = admin();
    const rows = await sql`
      SELECT action, entity_table FROM audit_log
      WHERE entity_table = 'invitations' ORDER BY id`;
    expect(rows.length).toBeGreaterThanOrEqual(3); // inserts + revoke update
    expect(rows.some((r) => r.action === "update")).toBe(true);
    await sql.end();
  });
});
