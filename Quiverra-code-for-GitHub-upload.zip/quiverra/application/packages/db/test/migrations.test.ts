import { describe, expect, it } from "vitest";
import { admin } from "./helpers.js";

describe("migrations", () => {
  it("creates the W1 foundation tables", async () => {
    const sql = admin();
    const rows = await sql`
      SELECT table_name FROM information_schema.tables
      WHERE table_schema = 'public' ORDER BY table_name`;
    const names = rows.map((r) => r.table_name);
    for (const t of [
      "profiles",
      "workspaces",
      "memberships",
      "projects",
      "creative_briefs",
      "assets",
      "ledger_accounts",
      "ledger_transactions",
      "ledger_postings",
      "audit_log",
    ]) {
      expect(names, `missing table ${t}`).toContain(t);
    }
    await sql.end();
  });

  it("enables and FORCES RLS on all public tables", async () => {
    const sql = admin();
    const rows = await sql`
      SELECT relname, relrowsecurity, relforcerowsecurity
      FROM pg_class WHERE relnamespace = 'public'::regnamespace AND relkind = 'r'
        AND relname <> 'drizzle_migrations'`;
    expect(rows.length).toBeGreaterThan(0);
    for (const r of rows) {
      expect(r.relrowsecurity, `RLS not enabled on ${r.relname}`).toBe(true);
      expect(r.relforcerowsecurity, `FORCE RLS missing on ${r.relname}`).toBe(true);
    }
    await sql.end();
  });

  it("seeds the system ledger accounts", async () => {
    const sql = admin();
    const rows = await sql`SELECT code FROM ledger_accounts WHERE workspace_id IS NULL`;
    expect(rows.length).toBeGreaterThanOrEqual(8);
    await sql.end();
  });
});
