import { describe, expect, it } from "vitest";
import { admin, asUser, lcg } from "./helpers.js";
import { fx, useFixtures } from "./fixtures.js";

useFixtures();

const BASIS = 10_000; // 1 credit = $0.01 in micro-USD

async function balances(sql: ReturnType<typeof admin>, ws: string) {
  const [row] = await sql`
    SELECT
      COALESCE(SUM(CASE WHEN a.code LIKE 'asset:credits_available:%'
                        THEN CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END END), 0)::bigint AS available,
      COALESCE(SUM(CASE WHEN a.code LIKE 'asset:credits_reserved:%'
                        THEN CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END END), 0)::bigint AS reserved
    FROM ledger_accounts a JOIN ledger_postings p ON p.account_code = a.code
    WHERE a.workspace_id = ${ws}`;
  return { available: BigInt(row!.available), reserved: BigInt(row!.reserved) };
}

async function globalDrift(sql: ReturnType<typeof admin>) {
  // invariant: liability:credits_issued == Σ(available) + Σ(reserved) across all workspaces
  const [row] = await sql`
    WITH liab AS (
      SELECT COALESCE(SUM(CASE WHEN p.direction='credit' THEN p.amount ELSE -p.amount END),0)::bigint AS b
      FROM ledger_postings p WHERE p.account_code = 'liability:credits_issued:sys'
    ), held AS (
      SELECT COALESCE(SUM(CASE WHEN p.direction='debit' THEN p.amount ELSE -p.amount END),0)::bigint AS b
      FROM ledger_postings p JOIN ledger_accounts a ON a.code = p.account_code
      WHERE a.workspace_id IS NOT NULL
    )
    SELECT (liab.b - held.b)::bigint AS drift FROM liab, held`;
  return BigInt(row!.drift);
}

describe("credit ledger — recipes & invariants (Credit-Ledger.md §3–§7)", () => {
  it("dev issuance credits the workspace (R1′, no USD counterpart while payments dormant)", async () => {
    const sql = admin();
    await sql`SELECT ledger.post('issuance_dev', ${fx.wsA}, 1000, 't:issue:1', NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL)`;
    const b = await balances(sql, fx.wsA);
    expect(b.available).toBe(1000n);
    expect(b.reserved).toBe(0n);
    expect(await globalDrift(sql)).toBe(0n);
    await sql.end();
  });

  it("idempotent replay returns the same transaction and posts once", async () => {
    const sql = admin();
    const [first] =
      await sql`SELECT ledger.post('issuance_dev', ${fx.wsA}, 500, 't:issue:2', NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL) AS id`;
    const [second] =
      await sql`SELECT ledger.post('issuance_dev', ${fx.wsA}, 500, 't:issue:2', NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL) AS id`;
    expect(second!.id).toBe(first!.id);
    const b = await balances(sql, fx.wsA);
    expect(b.available).toBe(1500n); // not 2000 — replay did not double-post
    await sql.end();
  });

  it("purchase posts balanced USD + CREDIT legs in one link group", async () => {
    const sql = admin();
    const [tx] =
      await sql`SELECT ledger.post('purchase', ${fx.wsA}, 250, 't:purchase:1', NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL) AS id`;
    const legs = await sql`
      SELECT domain, kind FROM ledger_transactions
      WHERE link_group = (SELECT link_group FROM ledger_transactions WHERE id = ${tx!.id})`;
    expect(legs.length).toBe(2);
    const cash = await sql`
      SELECT COALESCE(SUM(CASE WHEN direction='debit' THEN amount ELSE -amount END),0)::bigint AS b
      FROM ledger_postings WHERE account_code = 'asset:cash:sys'`;
    expect(BigInt(cash[0]!.b)).toBe(250n * BigInt(BASIS));
    await sql.end();
  });

  it("reservation moves available→reserved; over-reservation is rejected", async () => {
    const sql = admin();
    await sql`SELECT ledger.post('reserve', ${fx.wsA}, 400, 't:res:1', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
    let b = await balances(sql, fx.wsA);
    expect(b.available).toBe(1350n);
    expect(b.reserved).toBe(400n);
    await expect(
      sql`SELECT ledger.post('reserve', ${fx.wsA}, 999999, 't:res:overflow', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`,
    ).rejects.toThrow(/INSUFFICIENT_CREDITS/);
    b = await balances(sql, fx.wsA);
    expect(b.available).toBe(1350n); // unchanged after failed reserve
    await sql.end();
  });

  it("settlement consumes from reserved and recognises USD revenue at the stored basis", async () => {
    const sql = admin();
    await sql`SELECT ledger.post('settle', ${fx.wsA}, 380, 't:settle:1', NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL)`;
    const b = await balances(sql, fx.wsA);
    expect(b.reserved).toBe(20n);
    const [rev] = await sql`
      SELECT COALESCE(SUM(CASE WHEN direction='credit' THEN amount ELSE -amount END),0)::bigint AS b
      FROM ledger_postings WHERE account_code = 'revenue:generation:sys'`;
    expect(BigInt(rev!.b)).toBe(380n * BigInt(BASIS));
    expect(await globalDrift(sql)).toBe(0n);
    await sql.end();
  });

  it("release returns reserved credits untouched — server-error jobs are non-events", async () => {
    const sql = admin();
    const before = await balances(sql, fx.wsA);
    await sql`SELECT ledger.post('reserve', ${fx.wsA}, 20, 't:res:2', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
    await sql`SELECT ledger.post('release', ${fx.wsA}, 20, 't:rel:1', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
    const after = await balances(sql, fx.wsA);
    expect(after.available).toBe(before.available);
    expect(after.reserved).toBe(before.reserved);
    await sql.end();
  });

  it("provider prepay + cost track our side of the money", async () => {
    const sql = admin();
    await sql`SELECT ledger.post('provider_prepay', ${fx.wsA}, ${10_000_000}, 't:prepay:fal', NULL, NULL, NULL, NULL, 'fal', NULL, NULL)`;
    await sql`SELECT ledger.post('provider_cost', ${fx.wsA}, ${840_000}, 't:cost:1', NULL, NULL, NULL, NULL, 'fal', NULL, NULL)`;
    const [row] = await sql`
      SELECT COALESCE(SUM(CASE WHEN direction='debit' THEN amount ELSE -amount END),0)::bigint AS b
      FROM ledger_postings WHERE account_code = 'asset:provider_prepaid:fal'`;
    expect(BigInt(row!.b)).toBe(10_000_000n - 840_000n);
    await sql.end();
  });

  it("unbalanced direct postings are rejected at commit (constraint trigger)", async () => {
    const sql = admin();
    const acct = `asset:credits_available:ws_${fx.wsA}`;
    await expect(
      sql.begin(async (tx) => {
        const [txr] = await tx`
          INSERT INTO ledger_transactions (domain, kind, workspace_id, idempotency_key)
          VALUES ('CREDIT', 'issuance', ${fx.wsA}, 't:unbalanced') RETURNING id`;
        await tx`
          INSERT INTO ledger_postings (transaction_id, account_code, direction, amount)
          VALUES (${txr!.id}, ${acct}, 'debit', 5)`;
        // missing the balancing credit — must fail at COMMIT
      }),
    ).rejects.toThrow(/unbalanced/);
    await sql.end();
  });

  it("adjustments without reason+operator are rejected; with them they post", async () => {
    const sql = admin();
    await expect(
      sql`SELECT ledger.post('adjustment', ${fx.wsA}, 1, 't:adj:bad', NULL, NULL, NULL, NULL, NULL, NULL, NULL)`,
    ).rejects.toThrow(/adjustment requires/);
    await sql`SELECT ledger.post('adjustment', ${fx.wsA}, 1, 't:adj:ok', NULL, 'rounding fix', ${fx.userA}, NULL, NULL, 'expense:refunds:sys', 'debit')`;
    await sql.end();
  });

  it("ledger tables reject UPDATE and DELETE (immutability)", async () => {
    const sql = admin();
    await expect(
      sql`UPDATE ledger_transactions SET reason = 'x' WHERE idempotency_key = 't:issue:1'`,
    ).rejects.toThrow(/append-only/);
    await expect(sql`DELETE FROM ledger_postings`).rejects.toThrow(/append-only/);
    await sql.end();
  });

  it("authenticated users read their own balance view only", async () => {
    const sql = admin();
    const rowsA = await asUser(
      sql,
      fx.userA,
      fx.wsA,
      (tx) => tx`SELECT available, reserved FROM v_workspace_credit_balances`,
    );
    expect(rowsA.length).toBe(1);
    const rowsB = await asUser(
      sql,
      fx.userB,
      fx.wsB,
      (tx) => tx`SELECT count(*)::int AS c FROM v_workspace_credit_balances`,
    );
    expect(rowsB[0]!.c).toBe(0); // B has no ledger activity yet
    await sql.end();
  });
});

describe("credit ledger — property test (randomised recipe sequences)", () => {
  it("invariants hold after every operation: available≥0, reserved≥0, drift=0", async () => {
    const sql = admin();
    const rand = lcg(0xc0ffee);
    const model = { available: 1750n - 400n + 20n - 380n - 380n + 380n, reserved: 0n };
    // re-sync model to DB truth after the recipe tests above
    const actual = await balances(sql, fx.wsA);
    model.available = actual.available;
    model.reserved = actual.reserved;

    let seq = 0;
    for (let i = 0; i < 400; i++) {
      const r = rand();
      const key = `prop:${i}`;
      try {
        if (r < 0.25) {
          const amt = BigInt(1 + Math.floor(rand() * 100));
          await sql`SELECT ledger.post('issuance_dev', ${fx.wsA}, ${Number(amt)}, ${key}, NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL)`;
          model.available += amt;
        } else if (r < 0.5) {
          const amt = BigInt(1 + Math.floor(rand() * 50));
          if (amt <= model.available) {
            await sql`SELECT ledger.post('reserve', ${fx.wsA}, ${Number(amt)}, ${key}, NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
            model.available -= amt;
            model.reserved += amt;
          } else {
            await expect(
              sql`SELECT ledger.post('reserve', ${fx.wsA}, ${Number(amt)}, ${key}, NULL, NULL, NULL, NULL, NULL, NULL, NULL)`,
            ).rejects.toThrow(/INSUFFICIENT_CREDITS/);
          }
        } else if (r < 0.7) {
          const amt = BigInt(1 + Math.floor(rand() * 30));
          if (amt <= model.reserved) {
            await sql`SELECT ledger.post('settle', ${fx.wsA}, ${Number(amt)}, ${key}, NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL)`;
            model.reserved -= amt;
          }
        } else if (r < 0.85) {
          const amt = BigInt(1 + Math.floor(rand() * 30));
          if (amt <= model.reserved) {
            await sql`SELECT ledger.post('release', ${fx.wsA}, ${Number(amt)}, ${key}, NULL, NULL, NULL, NULL, NULL, NULL, NULL)`;
            model.reserved -= amt;
            model.available += amt;
          }
        } else {
          const amt = BigInt(1 + Math.floor(rand() * 20));
          if (amt <= model.available) {
            await sql`SELECT ledger.post('expiry', ${fx.wsA}, ${Number(amt)}, ${key}, NULL, NULL, NULL, ${BASIS}, NULL, NULL, NULL)`;
            model.available -= amt;
          }
        }
      } catch (e) {
        if (!(e instanceof Error && /INSUFFICIENT_CREDITS/.test(e.message))) throw e;
      }
      seq++;
      if (seq % 50 === 0) {
        const db = await balances(sql, fx.wsA);
        expect(db.available).toBe(model.available);
        expect(db.reserved).toBe(model.reserved);
        expect(db.available).toBeGreaterThanOrEqual(0n);
        expect(db.reserved).toBeGreaterThanOrEqual(0n);
        expect(await globalDrift(sql)).toBe(0n);
      }
    }
    // final assertion
    const db = await balances(sql, fx.wsA);
    expect(db.available).toBe(model.available);
    expect(db.reserved).toBe(model.reserved);
    expect(await globalDrift(sql)).toBe(0n);
    await sql.end();
  }, 120_000);
});
