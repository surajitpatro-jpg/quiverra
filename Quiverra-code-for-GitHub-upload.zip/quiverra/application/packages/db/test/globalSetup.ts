import { drizzle } from "drizzle-orm/postgres-js";
import { migrate } from "drizzle-orm/postgres-js/migrator";
import postgres from "postgres";

const ADMIN =
  process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/platform_w1_test";

/**
 * Fresh database + full migration run before the suite (Testing-Strategy §1 integration layer).
 * Creates the DB if missing, then applies migrations on top of a wiped public schema.
 */
export default async function setup() {
  const url = new URL(ADMIN);
  const dbName = url.pathname.slice(1);
  const rootUrl = ADMIN.replace(`/${dbName}`, "/postgres");

  const root = postgres(rootUrl, { max: 1, prepare: false });
  await root.unsafe(`DROP DATABASE IF EXISTS ${dbName} WITH (FORCE)`);
  await root.unsafe(`CREATE DATABASE ${dbName}`);
  await root.end();

  const client = postgres(ADMIN, { max: 1, prepare: false });
  await client.unsafe(`CREATE EXTENSION IF NOT EXISTS pgcrypto`);
  const db = drizzle(client);
  await migrate(db, { migrationsFolder: new URL("../migrations", import.meta.url).pathname });
  await client.end();
  console.log(`[globalSetup] migrated fresh database ${dbName}`);
}
