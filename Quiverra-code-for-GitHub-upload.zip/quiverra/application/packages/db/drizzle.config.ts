import { defineConfig } from "drizzle-kit";

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/schema.ts",
  out: "./migrations",
  dbCredentials: {
    // Local dev / CI scratch database. Real URLs come from env, never hardcoded secrets.
    url: process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/platform_dev",
  },
});
